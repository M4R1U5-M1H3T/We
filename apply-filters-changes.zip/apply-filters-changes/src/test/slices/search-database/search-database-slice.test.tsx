import type { ColumnDefinition, SearchRow } from '@/features';
import {
  fetchColumnDefinitionsThunk,
  fetchSearchResultsThunk,
  searchDatabaseReducer,
  searchReset,
  selectSearchPageStatus,
} from '@/slices';
import type { RootState } from '@/store/store';

const columns: ColumnDefinition[] = [{ name: 'id', displayName: 'ID' }];
const rows: SearchRow[] = [{ id: 1 }];
const searchArgs = { dataset: 'orders', filters: [] };

describe('searchDatabaseSlice reducer', () => {
  it('returns the initial state', () => {
    const state = searchDatabaseReducer(undefined, { type: '@@INIT' });

    expect(state).toEqual({
      searchType: null,
      results: { columns: [], rows: [] },
      selectedDataset: null,
      columnsStatus: 'idle',
      rowsStatus: 'idle',
      columnsError: null,
      rowsError: null,
    });
  });

  describe('fetchColumnDefinitionsThunk', () => {
    it('sets columnsStatus to loading and records searchType on pending', () => {
      const state = searchDatabaseReducer(undefined, fetchColumnDefinitionsThunk.pending('reqId', 'orders'));

      expect(state.columnsStatus).toBe('loading');
      expect(state.searchType).toBe('orders');
    });

    it('stores columns and selectedDataset on fulfilled', () => {
      const state = searchDatabaseReducer(undefined, fetchColumnDefinitionsThunk.fulfilled(columns, 'reqId', 'orders'));

      expect(state.columnsStatus).toBe('success');
      expect(state.results.columns).toEqual(columns);
      expect(state.selectedDataset).toBe('orders');
    });

    it('sets columnsError on rejected', () => {
      const action = fetchColumnDefinitionsThunk.rejected(new Error('columns boom'), 'reqId', 'orders');
      const state = searchDatabaseReducer(undefined, action);

      expect(state.columnsStatus).toBe('failed');
      expect(state.columnsError).toBe('columns boom');
    });

    it('falls back to the RTK-generated "Rejected" message when the thunk rejects without a manual error', () => {
      const action = fetchColumnDefinitionsThunk.rejected(null, 'reqId', 'orders');
      const state = searchDatabaseReducer(undefined, action);

      expect(state.columnsError).toBe('Rejected');
    });
  });

  describe('fetchSearchResultsThunk', () => {
    it('sets rowsStatus to loading and records searchType on pending', () => {
      const state = searchDatabaseReducer(undefined, fetchSearchResultsThunk.pending('reqId', searchArgs));

      expect(state.rowsStatus).toBe('loading');
      expect(state.searchType).toBe('orders');
    });

    it('stores rows and selectedDataset on fulfilled', () => {
      const state = searchDatabaseReducer(undefined, fetchSearchResultsThunk.fulfilled(rows, 'reqId', searchArgs));

      expect(state.rowsStatus).toBe('success');
      expect(state.results.rows).toEqual(rows);
      expect(state.selectedDataset).toBe('orders');
    });

    it('sets rowsError on rejected', () => {
      const action = fetchSearchResultsThunk.rejected(new Error('rows boom'), 'reqId', searchArgs);
      const state = searchDatabaseReducer(undefined, action);

      expect(state.rowsStatus).toBe('failed');
      expect(state.rowsError).toBe('rows boom');
    });
  });

  describe('searchReset', () => {
    it('clears statuses, errors and results back to idle', () => {
      const loaded = searchDatabaseReducer(
        searchDatabaseReducer(undefined, fetchColumnDefinitionsThunk.fulfilled(columns, 'reqId', 'orders')),
        fetchSearchResultsThunk.rejected(new Error('rows boom'), 'reqId', searchArgs)
      );

      const state = searchDatabaseReducer(loaded, searchReset());

      expect(state.columnsStatus).toBe('idle');
      expect(state.rowsStatus).toBe('idle');
      expect(state.columnsError).toBeNull();
      expect(state.rowsError).toBeNull();
      expect(state.results).toEqual({ columns: [], rows: [] });
    });

    it('does not clear searchType or selectedDataset', () => {
      const pending = searchDatabaseReducer(undefined, fetchColumnDefinitionsThunk.pending('reqId', 'orders'));
      const loaded = searchDatabaseReducer(pending, fetchColumnDefinitionsThunk.fulfilled(columns, 'reqId', 'orders'));
      const state = searchDatabaseReducer(loaded, searchReset());

      expect(state.searchType).toBe('orders');
      expect(state.selectedDataset).toBe('orders');
    });
  });
});

describe('selectSearchPageStatus', () => {
  const buildState = (columnsStatus: string, rowsStatus: string): RootState =>
    ({
      search: {
        searchType: null,
        results: { columns: [], rows: [] },
        selectedDataset: null,
        columnsStatus,
        rowsStatus,
        columnsError: null,
        rowsError: null,
      },
    }) as unknown as RootState;

  it('returns "idle" when both statuses are idle', () => {
    expect(selectSearchPageStatus(buildState('idle', 'idle'))).toBe('idle');
  });

  it('returns "loading" when either status is loading', () => {
    expect(selectSearchPageStatus(buildState('loading', 'idle'))).toBe('loading');
    expect(selectSearchPageStatus(buildState('success', 'loading'))).toBe('loading');
  });

  it('returns "failed" when either status is failed, even if the other is loading', () => {
    expect(selectSearchPageStatus(buildState('failed', 'idle'))).toBe('failed');
    expect(selectSearchPageStatus(buildState('loading', 'failed'))).toBe('failed');
  });

  it('returns "success" only when both statuses are success', () => {
    expect(selectSearchPageStatus(buildState('success', 'idle'))).toBe('idle');
    expect(selectSearchPageStatus(buildState('success', 'success'))).toBe('success');
  });
});
