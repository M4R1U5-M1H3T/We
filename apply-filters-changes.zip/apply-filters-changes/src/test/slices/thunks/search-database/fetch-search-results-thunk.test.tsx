import { jest } from '@jest/globals';

const mockAxiosPost = jest.fn<<T>() => Promise<{ data: T }>>();

jest.unstable_mockModule('axios', () => ({
  __esModule: true,
  default: {
    post: mockAxiosPost,
    isAxiosError: jest.fn(() => false),
  },
}));

const { fetchSearchResultsThunk } = await import('@/slices');

describe('fetchSearchResultsThunk', () => {
  beforeEach(() => {
    mockAxiosPost.mockReset();
  });

  it('dispatches fulfilled with database rows on successful API call', async () => {
    const mockRows = [{ id: 1, name: 'Item A' }];
    mockAxiosPost.mockResolvedValue({ data: mockRows });

    const dispatch = jest.fn();
    const filters = [{ key: 'region', operator: 'EQUAL', value: 'EMEA' }];
    const thunk = fetchSearchResultsThunk({ dataset: 'Orders', filters });

    const result = await thunk(dispatch as any, jest.fn() as any, undefined);

    expect(mockAxiosPost).toHaveBeenCalledWith('/api/database/orders/search', { filters });
    expect(result.type).toBe('search/fetchSearchResults/fulfilled');
    expect(result.payload).toEqual(mockRows);
  });

  it('dispatches rejected with wrapped error payload when API call fails', async () => {
    const apiError = new Error('Database Error');
    mockAxiosPost.mockRejectedValue(apiError);

    const dispatch = jest.fn();
    const thunk = fetchSearchResultsThunk({ dataset: 'Orders', filters: [] });

    const result = await thunk(dispatch as any, jest.fn() as any, undefined);

    expect(result.type).toBe('search/fetchSearchResults/rejected');
    expect(result.payload).toBeDefined();
  });
});
