import '@testing-library/jest-dom';

import { jest } from '@jest/globals';
import { configureStore } from '@reduxjs/toolkit';
import { act, render, screen, waitFor } from '@testing-library/react';
import { Provider } from 'react-redux';

import type { RootState } from '@/store/store';

const mockAxiosGet = jest.fn<<T>() => Promise<{ data: T | never[] }>>();
const mockAxiosPost = jest.fn<<T>() => Promise<{ data: T | never[] }>>();

jest.unstable_mockModule('axios', () => ({
  __esModule: true,
  default: {
    get: mockAxiosGet,
    post: mockAxiosPost,
    isAxiosError: jest.fn(() => false),
  },
}));

const { SearchDatabasePage } = await import('@/features');
const { databaseDatasetsReducer } = await import('@/slices');
const { searchDatabaseReducer } = await import('@/slices');
const { filtersReducer } = await import('@/slices');

const buildStore = (preloadedState?: Partial<RootState>) =>
  configureStore<RootState>({
    reducer: { search: searchDatabaseReducer, datasets: databaseDatasetsReducer, filters: filtersReducer },
    preloadedState: preloadedState as any,
  });

const renderPage = (preloadedState?: Parameters<typeof buildStore>[0]) => {
  const store = buildStore({
    datasets: { items: ['Orders', 'Customers'], status: 'success', error: null },
    ...preloadedState,
  });

  return {
    store,
    ...render(
      <Provider store={store}>
        <SearchDatabasePage />
      </Provider>
    ),
  };
};

beforeEach(() => {
  mockAxiosGet.mockReset();
  mockAxiosGet.mockResolvedValue({ data: [] });
  mockAxiosPost.mockReset();
  mockAxiosPost.mockResolvedValue({ data: [] });
});

describe('Snapshot tests', () => {
  it('matches snapshot in idle state', () => {
    const { container } = renderPage();
    expect(container).toMatchSnapshot();
  });

  it('matches snapshot in failed state', () => {
    const { container } = renderPage({
      search: {
        searchType: 'orders',
        selectedDataset: null,
        results: { columns: [], rows: [] },
        columnsStatus: 'failed',
        rowsStatus: 'idle',
        columnsError: 'Network error',
        rowsError: null,
      },
    });
    expect(container).toMatchSnapshot();
  });

  it('matches snapshot in success state', () => {
    const { container } = renderPage({
      search: {
        searchType: 'orders',
        selectedDataset: 'orders',
        results: {
          columns: [{ name: 'id', displayName: 'ID' }],
          rows: [{ id: 1 }],
        },
        columnsStatus: 'success',
        rowsStatus: 'success',
        columnsError: null,
        rowsError: null,
      },
    });
    expect(container).toMatchSnapshot();
  });
});

describe('Behaviour tests', () => {
  it('fetches the available datasets on mount', async () => {
    renderPage();

    await waitFor(() => expect(mockAxiosGet).toHaveBeenCalledWith('/api/database/datasets'));
  });

  it('shows the idle prompt before a search is run', () => {
    renderPage();
    expect(screen.getByText('Select a search type and click Search.')).toBeInTheDocument();
  });

  it('shows an error message when a request has failed', () => {
    renderPage({
      search: {
        searchType: 'orders',
        selectedDataset: null,
        results: { columns: [], rows: [] },
        columnsStatus: 'failed',
        rowsStatus: 'idle',
        columnsError: 'Network error',
        rowsError: null,
      },
    });

    expect(screen.getByText('Error: Network error')).toBeInTheDocument();
  });

  it('renders the results table when both requests succeed', () => {
    renderPage({
      search: {
        searchType: 'orders',
        selectedDataset: 'orders',
        results: {
          columns: [{ name: 'id', displayName: 'ID' }],
          rows: [{ id: 1 }],
        },
        columnsStatus: 'success',
        rowsStatus: 'success',
        columnsError: null,
        rowsError: null,
      },
    });

    expect(screen.getByText('Results')).toBeInTheDocument();
  });

  it('does not render the results table while idle', () => {
    renderPage();
    expect(screen.queryByText('Results')).not.toBeInTheDocument();
  });

  it('fetches columns and rows for the selected dataset when searching', async () => {
    renderPage();

    const button = document.querySelector('ds-button')!;

    await act(async () => {
      button.dispatchEvent(new Event('click', { bubbles: true }));
      await Promise.resolve();
    });

    await waitFor(() => {
      expect(mockAxiosGet).toHaveBeenCalledWith('/api/database/orders/columns');
      expect(mockAxiosPost).toHaveBeenCalledWith('/api/database/orders/search', { filters: [] });
    });
  });
});
