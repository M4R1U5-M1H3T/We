import type { FilterConfig } from '@/components/dynamic-form';

import type { DateRangeValue, FilterCriteria, SearchOperator } from './search-filter-types';

const DATE_RANGE_SEPARATOR = ',';

const FILTER_TYPE_OPERATORS: Record<string, SearchOperator> = {
  dropdown: 'EQUAL',
  text: 'LIKE',
  date_range: 'BETWEEN',
};

const buildDateRangeValue = (rawValue: string): DateRangeValue | null => {
  const [startDate, endDate] = rawValue.split(DATE_RANGE_SEPARATOR);

  if (!startDate || !endDate) {
    return null;
  }

  return { from: `${startDate}T00:00:00`, to: `${endDate}T23:59:59` };
};

/**
 * Converts the raw filter values collected by the DynamicForm into the
 * FilterCriteria[] shape expected by the `/api/database/{dataset}/search` endpoint.
 */
export const buildSearchFilters = (
  filterValues: Record<string, string>,
  filterConfig: FilterConfig | null
): FilterCriteria[] => {
  if (!filterConfig) {
    return [];
  }

  return Object.entries(filterValues).reduce<FilterCriteria[]>((criteria, [key, rawValue]) => {
    if (!rawValue) {
      return criteria;
    }

    const filterType = filterConfig.filters[key]?.type;
    const operator = FILTER_TYPE_OPERATORS[filterType] ?? 'EQUAL';

    if (operator === 'BETWEEN') {
      const value = buildDateRangeValue(rawValue);

      if (!value) {
        return criteria;
      }

      return [...criteria, { key, operator, value }];
    }

    return [...criteria, { key, operator, value: rawValue }];
  }, []);
};
