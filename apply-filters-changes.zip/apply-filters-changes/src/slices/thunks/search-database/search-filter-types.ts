export type SearchOperator = 'EQUAL' | 'LIKE' | 'BETWEEN';

export type DateRangeValue = {
  from: string;
  to: string;
};

export type FilterCriteria = {
  key: string;
  operator: SearchOperator;
  value: string | DateRangeValue;
};
