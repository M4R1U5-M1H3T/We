import axios from 'axios';

import type { ColumnDefinition, SearchRow } from '@/features';
import { handleThunkError } from '@/slices';
import { createAppAsyncThunkWithErrorPayload } from '@/store/hooks';

import type { FilterCriteria } from './search-filter-types';

export type SearchResultsArgs = {
  dataset: string;
  filters: FilterCriteria[];
};

export const fetchColumnDefinitionsThunk = createAppAsyncThunkWithErrorPayload<ColumnDefinition[], string>(
  'search/fetchColumnDefinitions',
  async (dataset, { rejectWithValue }) => {
    const normalizedDataset = dataset.toLowerCase();

    try {
      const response = await axios.get<ColumnDefinition[]>(`/api/database/${normalizedDataset}/columns`);

      return response.data;
    } catch (error) {
      return rejectWithValue(handleThunkError(error));
    }
  }
);

export const fetchSearchResultsThunk = createAppAsyncThunkWithErrorPayload<SearchRow[], SearchResultsArgs>(
  'search/fetchSearchResults',
  async ({ dataset, filters }, { rejectWithValue }) => {
    const normalizedDataset = dataset.toLowerCase();

    try {
      const response = await axios.post<SearchRow[]>(`/api/database/${normalizedDataset}/search`, { filters });

      return response.data;
    } catch (error) {
      return rejectWithValue(handleThunkError(error));
    }
  }
);
