import { Icon, Select, SelectOption } from '@/ds-components';

export interface DropdownFieldOption {
  label: string;
  value: string;
}

export interface DropdownFieldProps {
  data?: DropdownFieldOption[];
  value?: string;
  placeholder?: string;
  multiple?: boolean;
  clearable?: boolean;
  editable?: boolean;
  icon?: string;
  onChange?: (value: string) => void;
}

export const DropdownField = ({
  data = [],
  value,
  placeholder,
  multiple = false,
  clearable = true,
  editable = false,
  icon,
  onChange,
}: DropdownFieldProps) => {
  const handleChange = (event: Event) => {
    const target = event.target as HTMLElement & { value: string };
    onChange?.(target.value);
  };

  return (
    <Select
      multiple={multiple}
      value={value}
      placeholder={placeholder}
      clearable={clearable}
      editable={editable}
      onChange={handleChange}
    >
      {icon && <Icon slot="start" name={icon} />}
      {data.map(option => (
        <SelectOption key={option.value} value={option.value}>
          {option.label}
        </SelectOption>
      ))}
    </Select>
  );
};
