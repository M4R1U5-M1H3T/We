import './date-range-field.css';

import { DateInput } from '@/ds-components';

export interface DateRangeFieldProps {
  value?: string;
  placeholder?: string;
  multiple?: boolean;
  clearable?: boolean;
  editable?: boolean;
  onChange?: (value: string) => void;
}

const RANGE_SEPARATOR = ',';

const parseRange = (value?: string) => {
  const [startDate = '', endDate = ''] = value?.split(RANGE_SEPARATOR) ?? [];

  return { startDate, endDate };
};

export const DateRangeField = ({ value, clearable = true, onChange }: DateRangeFieldProps) => {
  const { startDate, endDate } = parseRange(value);

  const handleStartDateChange = (event: Event) => {
    const target = event.target as HTMLElement & { value: string };
    onChange?.(`${target.value}${RANGE_SEPARATOR}${endDate}`);
  };

  const handleEndDateChange = (event: Event) => {
    const target = event.target as HTMLElement & { value: string };
    onChange?.(`${startDate}${RANGE_SEPARATOR}${target.value}`);
  };

  return (
    <div className="filter-field-inputs">
      <DateInput value={startDate} placeholder="Start date" clearable={clearable} onChange={handleStartDateChange} />
      <DateInput value={endDate} placeholder="End date" clearable={clearable} onChange={handleEndDateChange} />
    </div>
  );
};
