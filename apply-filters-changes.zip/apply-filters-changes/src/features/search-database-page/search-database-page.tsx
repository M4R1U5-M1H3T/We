import './index.css';

import { useEffect } from 'react';

import { ResultsTable } from '@/components';
import { Card, CardContent } from '@/ds-components';
import { SearchDatabaseBar } from '@/features';
import {
  buildSearchFilters,
  fetchColumnDefinitionsThunk,
  fetchDatasetsThunk,
  fetchSearchResultsThunk,
  selectColumnsError,
  selectFiltersConfig,
  selectRowsError,
  selectSearchPageStatus,
  selectSearchResults,
  selectSearchType,
} from '@/slices';
import { useAppDispatch, useAppSelector } from '@/store/hooks';

export const SearchDatabasePage = () => {
  const dispatch = useAppDispatch();
  const searchType = useAppSelector(selectSearchType);
  const results = useAppSelector(selectSearchResults);
  const filterConfig = useAppSelector(selectFiltersConfig);
  const columnsError = useAppSelector(selectColumnsError);
  const rowsError = useAppSelector(selectRowsError);
  const pageStatus = useAppSelector(selectSearchPageStatus);
  const combinedError = columnsError || rowsError;

  useEffect(() => {
    dispatch(fetchDatasetsThunk());
  }, [dispatch]);

  const handleSearch = (selectedDataset: string, filters: Record<string, string> = {}) => {
    Promise.all([
      dispatch(fetchColumnDefinitionsThunk(selectedDataset)),
      dispatch(
        fetchSearchResultsThunk({
          dataset: selectedDataset,
          filters: buildSearchFilters(filters, filterConfig),
        })
      ),
    ]);
  };

  return (
    <div className="page">
      <h1>Search Database</h1>

      <Card appearance="contained" className="card">
        <CardContent>
          <SearchDatabaseBar onSearch={handleSearch} status={pageStatus} />
        </CardContent>
      </Card>

      <Card appearance="contained" className="card">
        <CardContent>
          {pageStatus === 'idle' && <p>Select a search type and click Search.</p>}
          {pageStatus === 'failed' && <p>Error: {combinedError}</p>}
          {pageStatus === 'success' && searchType && <ResultsTable results={results} />}
        </CardContent>
      </Card>
    </div>
  );
};
