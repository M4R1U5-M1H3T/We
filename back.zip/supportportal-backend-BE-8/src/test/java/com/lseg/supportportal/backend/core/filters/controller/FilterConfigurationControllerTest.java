package com.lseg.supportportal.backend.core.filters.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.stream.Stream;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lseg.supportportal.backend.core.filters.service.FilterConfigurationLoader;
import com.lseg.supportportal.backend.core.filters.service.FilterConfigurationMapper;
import com.lseg.supportportal.backend.core.filters.service.FilterConfigurationPathResolver;
import com.lseg.supportportal.backend.core.filters.service.FilterConfigurationService;
import com.lseg.supportportal.backend.core.filters.service.FilterDataProvider;
import com.lseg.supportportal.backend.core.filters.service.FilterJsonReader;
import com.lseg.supportportal.backend.core.security.SecurityConfig;

@WebMvcTest(FilterConfigurationController.class)
@Import({FilterConfigurationService.class, FilterDataProvider.class, FilterJsonReader.class, SecurityConfig.class,
         FilterConfigurationControllerTest.JacksonTestConfig.class, FilterConfigurationPathResolver.class, FilterConfigurationLoader.class,
         FilterConfigurationMapper.class})
class FilterConfigurationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @ParameterizedTest
    @MethodSource("provideFilterTestCases")
    void shouldFetchSchemaAndVerifyFilters(
            String filterKey, String expectedTitle, String expectedType, boolean expectedRequired, String expectedPlaceholder) throws Exception {

        mockMvc.perform(get("/api/database/filters/orders"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.filters['" + filterKey + "']").exists())
                .andExpect(jsonPath("$.filters['" + filterKey + "'].title").value(expectedTitle))
                .andExpect(jsonPath("$.filters['" + filterKey + "'].type").value(expectedType))
                .andExpect(jsonPath("$.filters['" + filterKey + "'].required").value(expectedRequired))
                .andExpect(jsonPath("$.filters['" + filterKey + "'].props.placeholder").value(expectedPlaceholder));
    }

    private static Stream<Arguments> provideFilterTestCases() {
        return Stream.of(
                Arguments.of("group", "Owner Group", "dropdown", false, "Select Group"),
                Arguments.of("reutersCode", "Product RIC Code", "text", false, "Enter Reuters Code"),
                Arguments.of("createdDate", "Creation Time", "date_range", false, "Select Date Range"),
                Arguments.of("account", "Account", "text", false, "Enter Account ID"), Arguments.of("side", "Side", "dropdown", false, "Select Side"),
                Arguments.of("tag", "Tag", "text", false, "Enter Tag")
        );
    }

    @TestConfiguration
    static class JacksonTestConfig {

        @Bean
        public ObjectMapper objectMapper() {
            return new ObjectMapper();
        }
    }
}
