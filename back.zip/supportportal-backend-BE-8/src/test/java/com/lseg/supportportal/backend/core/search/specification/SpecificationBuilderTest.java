package com.lseg.supportportal.backend.core.search.specification;

import com.lseg.supportportal.backend.core.search.domain.FilterCriteria;
import com.lseg.supportportal.backend.core.search.domain.SearchOperator;
import com.lseg.supportportal.backend.core.search.domain.SearchRequest;
import com.lseg.supportportal.backend.tools.searchdatabase.orders.domain.Order;
import org.springframework.data.jpa.domain.Specification;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SpecificationBuilderTest {

    private SpecificationBuilder<Order> builder;

    @BeforeEach
    void setUp() {
        builder = new SpecificationBuilder<>(Order.class);
    }

    @Test
    void shouldReturnEmptySpecificationWhenSearchRequestHasNoFilters() {
        SearchRequest requestEmpty = new SearchRequest(List.of());

        Specification<Order> specEmpty = builder.build(requestEmpty);

        assertNotNull(specEmpty, "Specification container should never be null");
    }

    @Test
    void shouldCompileCleanlyWhenValidRegisteredKeyIsPassed() {
        FilterCriteria criteria = new FilterCriteria("reutersCode", SearchOperator.EQUAL, "TRI.N");
        SearchRequest request = new SearchRequest(List.of(criteria));

        assertDoesNotThrow(() -> builder.build(request),
                "Builder should map registered whitelisted annotation keys with zero errors.");
    }

    @Test
    void shouldThrowIllegalArgumentExceptionWhenKeyIsUnknown() {
        FilterCriteria criteria = new FilterCriteria("unauthorizedHackField", SearchOperator.EQUAL, "value");
        SearchRequest request = new SearchRequest(List.of(criteria));

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> builder.build(request),
                "Builder must immediately reject keys that are not registered.");

        assertTrue(exception.getMessage().contains("Unknown filter key"),
                "Error context should clearly flag that the key resolution failed.");
    }
}
