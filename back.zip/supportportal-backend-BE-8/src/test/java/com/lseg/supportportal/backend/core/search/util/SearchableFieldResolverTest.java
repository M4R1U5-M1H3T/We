package com.lseg.supportportal.backend.core.search.util;

import com.lseg.supportportal.backend.core.search.annotation.SearchableField;
import java.lang.reflect.Field;
import java.util.Map;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SearchableFieldResolverTest {

    static class DummyOrderEntity {
        @SearchableField(key = "reutersCode")
        private String productRicCode;

        @SearchableField(key = "group")
        private String orderGroup;

        // Intentionally missing annotation
        private String nonSearchableField;
    }

    @Test
    void shouldResolveSearchableFieldsWhenFieldsAreAnnotated() {
        Map<String, Field> result = SearchableFieldResolver.resolveSearchableFieldsByKey(DummyOrderEntity.class);

        assertEquals(2, result.size(), "Should only extract fields containing the @SearchableField annotation.");

        assertTrue(result.containsKey("reutersCode"));
        assertEquals("productRicCode", result.get("reutersCode").getName());

        assertTrue(result.containsKey("group"));
        assertEquals("orderGroup", result.get("group").getName());
    }

    @Test
    void shouldIgnoreFieldsWhenSearchableAnnotationIsMissing() {
        Map<String, Field> result = SearchableFieldResolver.resolveSearchableFieldsByKey(DummyOrderEntity.class);

        assertFalse(result.containsKey("nonSearchableField"), "Fields missing @SearchableField must be ignored.");
    }
}
