package com.lseg.supportportal.backend.core.search.validator;

import com.lseg.supportportal.backend.core.search.annotation.ValidSearchRequest;
import com.lseg.supportportal.backend.core.search.domain.FilterCriteria;
import com.lseg.supportportal.backend.core.search.domain.SearchOperator;
import com.lseg.supportportal.backend.core.search.domain.SearchRequest;
import com.lseg.supportportal.backend.tools.searchdatabase.orders.domain.Order;
import jakarta.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

class SearchRequestValidatorTest {

    private SearchRequestValidator validator;
    private ConstraintValidatorContext context;

    @BeforeEach
    void setUp() {
        validator = new SearchRequestValidator();

        ValidSearchRequest annotation = mock(ValidSearchRequest.class);
        doReturn(Order.class).when(annotation).entity();

        validator.initialize(annotation);

        context = mock(ConstraintValidatorContext.class);
        ConstraintValidatorContext.ConstraintViolationBuilder violationBuilder = mock(ConstraintValidatorContext.ConstraintViolationBuilder.class);
        var nodeBuilder = mock(ConstraintValidatorContext.ConstraintViolationBuilder.NodeBuilderCustomizableContext.class);

        when(context.buildConstraintViolationWithTemplate(anyString())).thenReturn(violationBuilder);
        when(violationBuilder.addPropertyNode(anyString())).thenReturn(nodeBuilder);
        when(nodeBuilder.addConstraintViolation()).thenReturn(context);
    }

    @Test
    void shouldReturnTrueWhenPayloadOrFiltersAreNull() {
        assertTrue(validator.isValid(null, context));
        assertTrue(validator.isValid(new SearchRequest(null), context));
    }

    @Test
    void shouldReturnTrueWhenFilterKeyIsValid() {
        // "reutersCode" is tagged with @SearchableField inside Order.class
        FilterCriteria criteria = new FilterCriteria("reutersCode", SearchOperator.EQUAL, "IBM.N");
        SearchRequest request = new SearchRequest(List.of(criteria));

        assertTrue(validator.isValid(request, context));
    }

    @Test
    void shouldReturnFalseWhenFilterKeyDoesNotExist() {
        FilterCriteria criteria = new FilterCriteria("invalidKey", SearchOperator.EQUAL, "value");
        SearchRequest request = new SearchRequest(List.of(criteria));

        assertFalse(validator.isValid(request, context));
        verify(context, times(1)).disableDefaultConstraintViolation();
        verify(context, times(1)).buildConstraintViolationWithTemplate(contains("invalidKey"));
    }
}
