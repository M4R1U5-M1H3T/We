package com.lseg.supportportal.backend.tools.searchdatabase.orders.service;

import com.lseg.supportportal.backend.core.search.config.SearchProperties;
import com.lseg.supportportal.backend.tools.searchdatabase.orders.domain.Order;
import com.lseg.supportportal.backend.tools.searchdatabase.orders.repository.OrderRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.SliceImpl;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class OrderServiceTest {

    @Mock
    private OrderRepository orderRepository;
    @Mock
    private SearchProperties searchProperties;

    @InjectMocks
    private OrderService orderService;

    @Captor
    private ArgumentCaptor<Pageable> pageableCaptor;

    @BeforeEach
    void setUp() {
        when(searchProperties.getHardLimit()).thenReturn(100);
    }

    private static Stream<Arguments> provideOrderCounts() {
        return Stream.of(
                Arguments.of(5),
                Arguments.of(100),
                Arguments.of(150)
        );
    }

    @ParameterizedTest(name = "Run {index}: Testing size: {0})")
    @MethodSource("provideOrderCounts")
    void returnsExpectedContentCount(int mockOrderCount) {
        List<Order> mockOrders = createFakeOrders(mockOrderCount);
        when(orderRepository.findAllBy(any(Pageable.class))).thenReturn(new SliceImpl<>(mockOrders));

        List<Order> result = orderService.findAll();

        verify(orderRepository).findAllBy(pageableCaptor.capture());
        Pageable capturedPageable = pageableCaptor.getValue();

        assertThat(capturedPageable.getPageSize()).isEqualTo(searchProperties.getHardLimit());
        assertThat(capturedPageable.getPageNumber()).isZero();

        assertThat(result).hasSize(mockOrderCount);
        assertThat(result).isEqualTo(mockOrders);
    }

    private List<Order> createFakeOrders(int count) {
        return IntStream.range(0, count).mapToObj(i -> {
            Order order = new Order();
            ReflectionTestUtils.setField(order, "clOrdId", String.valueOf(i));
            ReflectionTestUtils.setField(order, "ownerGroup", "mockOwnerGroup");
            return order;
        }).toList();
    }

    @Test
    void returnsEmptyResult() {
        when(orderRepository.findAllBy(any(Pageable.class))).thenReturn(new SliceImpl<>(List.of()));

        List<Order> result = orderService.findAll();

        verify(orderRepository).findAllBy(pageableCaptor.capture());

        assertThat(result).isEmpty();
    }
}
