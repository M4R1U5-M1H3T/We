package com.lseg.supportportal.backend.core.search.specification;

import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Map;

import org.junit.jupiter.api.Test;

import com.lseg.supportportal.backend.core.search.domain.FilterCriteria;
import com.lseg.supportportal.backend.core.search.domain.SearchOperator;
import com.lseg.supportportal.backend.tools.searchdatabase.orders.domain.Order;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Root;

class GenericSpecificationTest {

    @SuppressWarnings("unchecked")
    @Test
    void shouldInvokeEqualPredicateWhenOperatorIsEqual() {
        FilterCriteria criteria = new FilterCriteria("reutersCode", SearchOperator.EQUAL, "IBM.N");
        GenericSpecification<Order> specification = new GenericSpecification<>(criteria, "productRicCode");

        Root<Order> root = mock(Root.class);
        CriteriaQuery<?> query = mock(CriteriaQuery.class);
        CriteriaBuilder cb = mock(CriteriaBuilder.class);
        Path<Object> path = mock(Path.class);

        when(root.get("productRicCode")).thenReturn(path);

        specification.toPredicate(root, query, cb);

        verify(cb, times(1)).equal(path, "IBM.N");
    }

    @SuppressWarnings("unchecked")
    @Test
    void shouldInvokeBetweenPredicateWithParsedDatesWhenValueIsMapWithSpaces() {
        Map<String, String> dateMap = Map.of("from", "2025-05-29", "to", "2025-05-30");
        FilterCriteria criteria = new FilterCriteria("createdDate", SearchOperator.BETWEEN, dateMap);
        GenericSpecification<Order> specification = new GenericSpecification<>(criteria, "createdAt");

        Root<Order> root = mock(Root.class);
        CriteriaQuery<?> query = mock(CriteriaQuery.class);
        CriteriaBuilder cb = mock(CriteriaBuilder.class);
        Path<Object> rawPath = mock(Path.class);
        Expression<LocalDate> typedExpression = mock(Expression.class);

        when(root.get("createdAt")).thenReturn(rawPath);

        when(rawPath.as(LocalDate.class)).thenReturn(typedExpression);

        specification.toPredicate(root, query, cb);

        LocalDate expectedFrom = LocalDate.of(2025, 5, 29);
        LocalDate expectedTo = LocalDate.of(2025, 5, 30);

        verify(cb, times(1)).between(eq(typedExpression), eq(expectedFrom), eq(expectedTo));
    }
}
