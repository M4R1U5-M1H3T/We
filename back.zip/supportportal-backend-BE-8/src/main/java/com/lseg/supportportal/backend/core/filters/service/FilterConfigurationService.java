package com.lseg.supportportal.backend.core.filters.service;

import java.util.Arrays;
import java.util.Collections;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.lseg.supportportal.backend.core.filters.domain.Filter;
import com.lseg.supportportal.backend.core.filters.domain.FilterConfig;
import com.lseg.supportportal.backend.core.filters.domain.FilterDefinition;
import com.lseg.supportportal.backend.core.filters.domain.FilterOption;
import com.lseg.supportportal.backend.core.filters.domain.FilterType;
import com.lseg.supportportal.backend.core.filters.domain.PageFilters;
import com.lseg.supportportal.backend.core.filters.exception.FilterConfigurationException;
import com.lseg.supportportal.backend.core.filters.validator.FilterConfigurationValidator;
import com.lseg.supportportal.backend.tools.searchdatabase.datasets.domain.Dataset;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class FilterConfigurationService {

    private final FilterConfigurationLoader filterConfigurationLoader;
    private final FilterConfigurationMapper filterConfigurationMapper;
    private volatile Map<Dataset, PageFilters> pageFiltersByDataset;

    public FilterConfigurationService(
            final FilterConfigurationLoader filterConfigurationLoader,
            final FilterConfigurationMapper filterConfigurationMapper
    ) {
        this.filterConfigurationLoader = filterConfigurationLoader;
        this.filterConfigurationMapper = filterConfigurationMapper;
    }

    @PostConstruct
    public void initialize() {

        final Map<String, FilterDefinition> definitions = filterConfigurationLoader.loadDefinitions();

        this.pageFiltersByDataset = Arrays.stream(Dataset.values())
                   .collect(Collectors.toMap(
                           dataset -> dataset,
                           dataset -> buildPageFilters(dataset, definitions),
                           (a, b) -> a,
                           () -> new EnumMap<>(Dataset.class)
                   ));
    }

    public PageFilters getPageFilters(final String page) {
        return pageFiltersByDataset.get(Dataset.fromName(page));
    }

    private PageFilters buildPageFilters(final Dataset dataset, final Map<String, FilterDefinition> definitions) {
        final FilterConfig filterConfig = filterConfigurationLoader.loadFilterConfig(dataset);
        return filterConfigurationMapper.toPageFilters(dataset, filterConfig, definitions);
    }
}
