package com.lseg.supportportal.backend.core.filters.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

public enum FilterType {
    @JsonProperty("dropdown") DROPDOWN,
    @JsonProperty("text") TEXT,
    @JsonProperty("date_range") DATE_RANGE
}
