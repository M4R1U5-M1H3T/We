package com.lseg.supportportal.backend.core.filters.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.lseg.supportportal.backend.core.filters.domain.FilterConfig;
import com.lseg.supportportal.backend.core.filters.domain.FilterDefinition;
import com.lseg.supportportal.backend.core.filters.validator.FilterConfigurationValidator;
import com.lseg.supportportal.backend.tools.searchdatabase.datasets.domain.Dataset;

@Component
public class FilterConfigurationLoader {
    private final FilterJsonReader filterJsonReader;
    private final FilterConfigurationPathResolver filterConfigurationPathResolver;
    private final Resource definitionsResource;

    public FilterConfigurationLoader(
            final FilterJsonReader filterJsonReader,
            final FilterConfigurationPathResolver filterConfigurationPathResolver,
            @Value("classpath:filters/filter-definitions.json") final Resource definitionsResource
    ) {
        this.filterJsonReader = filterJsonReader;
        this.filterConfigurationPathResolver = filterConfigurationPathResolver;
        this.definitionsResource = definitionsResource;
    }

    public Map<String, FilterDefinition> loadDefinitions() {
        return filterJsonReader.read(definitionsResource, new TypeReference<Map<String, FilterDefinition>>() {});

    }

    public FilterConfig loadFilterConfig(Dataset dataset) {
        final Resource resource = filterConfigurationPathResolver.resolve(dataset);
        final FilterConfig filterConfig = filterJsonReader.read(resource, new TypeReference<FilterConfig>() {});
        FilterConfigurationValidator.validate(resource, filterConfig, dataset.getEntityClass());
        return filterConfig;
    }
}
