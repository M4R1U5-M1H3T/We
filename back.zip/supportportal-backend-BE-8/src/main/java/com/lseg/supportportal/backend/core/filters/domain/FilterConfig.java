package com.lseg.supportportal.backend.core.filters.domain;

import java.util.List;
import java.util.Map;

public record FilterConfig(List<String> defaultFilterOrder, Map<String, Filter> filters) {}
