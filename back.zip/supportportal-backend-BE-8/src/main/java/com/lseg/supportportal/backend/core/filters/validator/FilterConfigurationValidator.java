package com.lseg.supportportal.backend.core.filters.validator;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import com.lseg.supportportal.backend.core.filters.domain.FilterConfig;
import com.lseg.supportportal.backend.core.filters.exception.FilterConfigurationException;
import com.lseg.supportportal.backend.core.search.util.SearchableFieldResolver;

@Component
public class FilterConfigurationValidator {

    public static void validate(final Resource filterConfigResource, final FilterConfig filterConfig, final Class<?> entityClass) {
        validateDefaultFilterOrder(filterConfigResource, filterConfig);
        validateFiltersAreSearchable(filterConfigResource, filterConfig, entityClass);
    }

    private static void validateDefaultFilterOrder(final Resource filterConfigResource, final FilterConfig filterConfig) {
        final Set<String> orderedKeys = new HashSet<>(filterConfig.defaultFilterOrder());
        final Set<String> definedKeys = filterConfig.filters().keySet();

        if (orderedKeys.size() != filterConfig.defaultFilterOrder().size()) {
            throw new FilterConfigurationException(
                    "Duplicate filter key found in defaultFilterOrder of '" + filterConfigResource.getDescription() + "'");
        }
        if (!definedKeys.containsAll(orderedKeys)) {
            throw new FilterConfigurationException(
                    "defaultFilterOrder references unknown filter keys in '" + filterConfigResource.getDescription() + "' - defaultFilterOrder: "
                            + orderedKeys + ", filters: " + definedKeys);
        }
    }

    private static void validateFiltersAreSearchable(
            final Resource filterConfigResource, final FilterConfig filterConfig, final Class<?> entityClass) {
        final Set<String> searchableKeys = SearchableFieldResolver.resolveSearchableFieldsByKey(entityClass).keySet();
        final Set<String> unresolvedFilterKeys = filterConfig.filters()
                .entrySet()
                .stream()
                .filter(e -> !searchableKeys.contains(e.getKey()) && e.getValue().title() == null)
                .map(Map.Entry::getKey)
                .collect(Collectors.toSet());

        if (!unresolvedFilterKeys.isEmpty()) {
            throw new FilterConfigurationException("Filters " + unresolvedFilterKeys + " declared in '" + filterConfigResource.getDescription()
                    + "' have no matching @SearchableField on " + entityClass.getSimpleName()
                    + " and no explicit 'title' override in the filter config");
        }
    }
}
