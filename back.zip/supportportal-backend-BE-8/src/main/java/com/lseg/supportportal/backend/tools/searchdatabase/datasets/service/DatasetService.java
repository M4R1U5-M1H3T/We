package com.lseg.supportportal.backend.tools.searchdatabase.datasets.service;

import com.lseg.supportportal.backend.core.metadata.Label;
import com.lseg.supportportal.backend.tools.searchdatabase.datasets.domain.ColumnInfo;
import com.lseg.supportportal.backend.tools.searchdatabase.datasets.domain.Dataset;
import org.springframework.stereotype.Service;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;

@Service
public class DatasetService {

    public List<String> getAvailableDatasetNames() {
        return Arrays.stream(Dataset.values()).map(Dataset::getLabel).toList();
    }

    public List<ColumnInfo> getColumns(final String datasetName) {
        final var dataset = Dataset.fromLabel(datasetName);
        return Arrays.stream(dataset.getEntityClass().getDeclaredFields())
                .map(field -> new ColumnInfo(field.getName(), resolveDisplayName(field)))
                .toList();
    }

    private String resolveDisplayName(final Field field) {
        Label displayName = field.getAnnotation(Label.class);
        return displayName != null ? displayName.value() : field.getName();
    }
}
