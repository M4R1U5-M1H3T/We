package com.lseg.supportportal.backend.tools.searchdatabase.orders.controller;

import com.lseg.supportportal.backend.core.search.annotation.ValidSearchRequest;
import com.lseg.supportportal.backend.core.search.domain.SearchRequest;
import com.lseg.supportportal.backend.tools.searchdatabase.orders.domain.Order;
import com.lseg.supportportal.backend.tools.searchdatabase.orders.service.OrderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/database/orders")
@RequiredArgsConstructor
@Tag(name = "Orders", description = "Endpoint for accessing order data")
public class OrderController {
    private final OrderService orderService;

    @GetMapping
    @Operation(
            summary = "Retrieve orders",
            description = "Retrieves orders from the database."
    )
    @ApiResponse(responseCode = "200", description = "Successfully retrieved orders.")
    public ResponseEntity<List<Order>> findOrders() {
        final List<Order> orders = orderService.findAll();

        return ResponseEntity.ok().body(orders);
    }

    @PostMapping("/search")
    @Operation(
            summary = "Search orders",
            description = "Searches orders from the database using the provided filters."
    )
    @ApiResponse(responseCode = "200", description = "Successfully retrieved orders.")
    public ResponseEntity<List<Order>> searchOrders(
            @Valid @RequestBody @ValidSearchRequest(entity = Order.class)
            SearchRequest searchRequest) {
        final List<Order> orders = orderService.searchOrders(searchRequest);

        return ResponseEntity.ok(orders);
    }
}
