package com.lseg.supportportal.backend.core.search.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "database.search")
@Getter
@Setter
public class SearchProperties {
    // if "database.search.hard-limit" is missing from application.properties, defaults to 100
    private int hardLimit = 100;
}
