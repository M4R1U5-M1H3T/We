package com.lseg.supportportal.backend.core.search.domain;

public enum SearchOperator {
    EQUAL,
    LIKE,
    BETWEEN,
}
