package com.lseg.supportportal.backend.core.filters.service;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.lseg.supportportal.backend.core.filters.domain.FilterOption;

import jakarta.annotation.PostConstruct;

@Component
public class FilterDataProvider {

    private final FilterJsonReader filterJsonReader;
    private final Resource valuesResource;
    private volatile Map<String, List<FilterOption>> filterValues;

    public FilterDataProvider(final FilterJsonReader filterJsonReader, @Value("classpath:filters/filter-values.json") final Resource valuesResource) {
        this.filterJsonReader = filterJsonReader;
        this.valuesResource = valuesResource;
    }

    @PostConstruct
    public void initialize() {
        this.filterValues = filterJsonReader.read(valuesResource, new TypeReference<Map<String, List<FilterOption>>>() {});
    }

    public List<FilterOption> getOptions(final String filterKey) {
        return filterValues.getOrDefault(filterKey, Collections.emptyList());
    }
}

