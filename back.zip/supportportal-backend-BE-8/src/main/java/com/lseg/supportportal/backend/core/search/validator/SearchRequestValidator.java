package com.lseg.supportportal.backend.core.search.validator;

import com.lseg.supportportal.backend.core.search.annotation.ValidSearchRequest;
import com.lseg.supportportal.backend.core.search.domain.FilterCriteria;
import com.lseg.supportportal.backend.core.search.domain.SearchRequest;
import com.lseg.supportportal.backend.core.search.util.SearchableFieldResolver;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import java.util.List;
import java.util.Set;

public class SearchRequestValidator implements ConstraintValidator<ValidSearchRequest, SearchRequest> {
    private Set<String> allowedKeys;

    @Override
    public void initialize(ValidSearchRequest constraintAnnotation) {
        this.allowedKeys = SearchableFieldResolver.resolveSearchableFieldsByKey(constraintAnnotation.entity()).keySet();
    }

    @Override
    public boolean isValid(SearchRequest searchRequest, ConstraintValidatorContext context) {
        List<FilterCriteria> filters = (searchRequest != null && searchRequest.filters() != null)
                ? searchRequest.filters() : List.of();

        return filters.stream()
                .filter(filterCriteria -> filterCriteria.key() != null && !allowedKeys.contains(filterCriteria.key()))
                .findFirst()
                .map(invalidFilter -> {
                    context.disableDefaultConstraintViolation();
                    context.buildConstraintViolationWithTemplate(
                            "Validation failed: Filter key " + invalidFilter.key() + " does not exist."
                    ).addConstraintViolation();
                    return false;
                })
                .orElse(true);
    }
}
