package com.lseg.supportportal.backend.tools.searchdatabase.executions.service;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.lseg.supportportal.backend.core.search.config.SearchProperties;
import com.lseg.supportportal.backend.core.search.domain.SearchRequest;
import com.lseg.supportportal.backend.core.search.specification.SpecificationBuilder;
import com.lseg.supportportal.backend.tools.searchdatabase.executions.domain.Execution;
import com.lseg.supportportal.backend.tools.searchdatabase.executions.repository.ExecutionRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ExecutionService {

    private final ExecutionRepository executionRepository;
    private final SearchProperties searchProperties;
    private final SpecificationBuilder<Execution> specificationBuilder = new SpecificationBuilder<>(Execution.class);

    public List<Execution> findAll() {
        final Pageable pageable = Pageable.ofSize(searchProperties.getHardLimit());
        return executionRepository.findAllBy(pageable).getContent();
    }

    public List<Execution> searchExecutions(SearchRequest searchRequest) {
        final Pageable pageable = Pageable.ofSize(searchProperties.getHardLimit());
        Specification<Execution> specification = specificationBuilder.build(searchRequest);
        return executionRepository.findAll(specification, pageable).getContent();
    }
}
