package com.lseg.supportportal.backend.core.search.annotation;

import com.lseg.supportportal.backend.core.search.validator.SearchRequestValidator;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.*;

@Target({ElementType.TYPE, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = SearchRequestValidator.class)
@Documented
public @interface ValidSearchRequest {
    Class<?> entity();
    String message() default "Validation failed";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}
