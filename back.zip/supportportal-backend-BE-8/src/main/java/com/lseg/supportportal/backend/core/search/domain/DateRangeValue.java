package com.lseg.supportportal.backend.core.search.domain;

import java.time.LocalDate;

public record DateRangeValue(LocalDate from, LocalDate to) {}
