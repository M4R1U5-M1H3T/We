package com.lseg.supportportal.backend.core.filters.service;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import com.lseg.supportportal.backend.tools.searchdatabase.datasets.domain.Dataset;

@Component
public class FilterConfigurationPathResolver {
    private static final String PATH_TEMPLATE = "filters/search-db-%s-filters.json";

    public Resource resolve(Dataset dataset) {
        return new ClassPathResource(PATH_TEMPLATE.formatted(dataset.getName()));
    }
}
