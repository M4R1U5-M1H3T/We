package com.lseg.supportportal.backend.tools.searchdatabase.executions.repository;

import com.lseg.supportportal.backend.tools.searchdatabase.executions.domain.Execution;
import com.lseg.supportportal.backend.tools.searchdatabase.executions.domain.ExecutionPrimaryKey;
import org.springframework.data.domain.Slice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;
import org.springframework.data.domain.Pageable;

@Repository
public interface ExecutionRepository extends JpaRepository<Execution, ExecutionPrimaryKey>, JpaSpecificationExecutor<Execution> {
    Slice<Execution> findAllBy(Pageable pageable);
}
