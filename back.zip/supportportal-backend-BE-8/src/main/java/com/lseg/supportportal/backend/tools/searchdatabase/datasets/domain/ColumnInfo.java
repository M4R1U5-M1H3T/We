package com.lseg.supportportal.backend.tools.searchdatabase.datasets.domain;

public record ColumnInfo(String name, String label) {
}
