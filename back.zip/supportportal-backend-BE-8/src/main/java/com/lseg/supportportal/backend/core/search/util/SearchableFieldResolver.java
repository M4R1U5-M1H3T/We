package com.lseg.supportportal.backend.core.search.util;

import com.lseg.supportportal.backend.core.search.annotation.SearchableField;

import java.lang.reflect.Field;
import java.util.*;
import java.util.stream.Collectors;

public class SearchableFieldResolver {
    private SearchableFieldResolver() {}

    public static Map<String, Field> resolveSearchableFieldsByKey(Class<?> entityClass) {
        return Arrays.stream(entityClass.getDeclaredFields())
                .filter(field -> field.isAnnotationPresent(SearchableField.class))
                .collect(Collectors.toMap(
                                field -> field.getAnnotation(SearchableField.class).key(),
                                field -> field
                        )
                );
    }
}
