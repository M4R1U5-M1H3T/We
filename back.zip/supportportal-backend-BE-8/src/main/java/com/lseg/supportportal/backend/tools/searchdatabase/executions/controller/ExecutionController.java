package com.lseg.supportportal.backend.tools.searchdatabase.executions.controller;

import com.lseg.supportportal.backend.core.search.annotation.ValidSearchRequest;
import com.lseg.supportportal.backend.core.search.domain.SearchRequest;
import com.lseg.supportportal.backend.tools.searchdatabase.executions.service.ExecutionService;
import com.lseg.supportportal.backend.tools.searchdatabase.executions.domain.Execution;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/database/executions")
@RequiredArgsConstructor
@Tag(name = "Executions", description = "Endpoint for accessing execution data")
public class ExecutionController {
    private final ExecutionService executionService;

    @GetMapping
    @Operation(summary = "Retrieve executions", description = "Retrieves executions from the database.")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved executions.")
    public ResponseEntity<List<Execution>> findExecutions() {
        final List<Execution> executions = executionService.findAll();
        return ResponseEntity.ok().body(executions);
    }

    @PostMapping("/search")
    @Operation(
            summary = "Search executions",
            description = "Searches executions from the database using the provided filters"
    )
    @ApiResponse(responseCode = "200", description = "Successfully retrieved executions.")
    public ResponseEntity<List<Execution>> searchExecutions(
            @Valid @RequestBody @ValidSearchRequest(entity = Execution.class)
            SearchRequest searchRequest) {
        final List<Execution> executions = executionService.searchExecutions(searchRequest);

        return ResponseEntity.ok(executions);
    }
}
