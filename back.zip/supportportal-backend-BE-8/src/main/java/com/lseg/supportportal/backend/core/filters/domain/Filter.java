package com.lseg.supportportal.backend.core.filters.domain;

/**                                                                                                                                            ┃
 * title is optional and should only be set for "virtual" filters with no                                                                      ┃
 * backing @SearchableField/@Label on the dataset entity (e.g. "region",                                                                       ┃
 * which selects which region database to query rather than filtering rows).                                                                   ┃
 * Entity-backed filters must leave title null and get it from @Label instead.                                                                 ┃
 */
public record Filter(boolean required, String placeholder, String title) {}