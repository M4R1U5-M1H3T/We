package com.lseg.supportportal.backend.core.filters.service;

import java.io.IOException;
import java.io.InputStream;

import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lseg.supportportal.backend.core.filters.exception.FilterConfigurationException;

@Component
public class FilterJsonReader {

    private final ObjectMapper objectMapper = new ObjectMapper();

    public <T> T read(final Resource resource, final TypeReference<T> typeReference) {
        try (InputStream inputStream = resource.getInputStream()) {
            return objectMapper.readValue(inputStream, typeReference);
        } catch (IOException e) {
            throw new FilterConfigurationException("Failed to read filter configuration from '" + resource.getDescription() + "'", e);
        }
    }
}
