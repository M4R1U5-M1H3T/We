package com.lseg.supportportal.backend.tools.searchdatabase.datasets.domain;

import com.lseg.supportportal.backend.tools.searchdatabase.executions.domain.Execution;
import com.lseg.supportportal.backend.tools.searchdatabase.orders.domain.Order;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

@Getter
@AllArgsConstructor
public enum Dataset {
    ORDERS("Orders", "orders", Order.class),
    EXECUTIONS("Executions", "executions", Execution.class);

    private final String label;
    private final String name;
    private final Class<?> entityClass;
    public static Dataset fromLabel(final String label) {
        return Arrays.stream(values())
                .filter(dataset -> dataset.label.equalsIgnoreCase(label))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Unknown dataset: " + label));
    }

    public static Dataset fromName(final String name) {
        return Arrays.stream(values())
                .filter(dataset -> dataset.name.equalsIgnoreCase(name))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Unknown dataset: " + name));
    }
}
