package com.lseg.supportportal.backend.core.search.domain;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

import java.util.List;

public record SearchRequest(
        @NotNull(message = "Filters list must not be null")
        @Valid
        List<FilterCriteria> filters
) {}