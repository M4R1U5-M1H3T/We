package com.lseg.supportportal.backend.tools.searchdatabase.orders.repository;

import com.lseg.supportportal.backend.tools.searchdatabase.orders.domain.Order;
import com.lseg.supportportal.backend.tools.searchdatabase.orders.domain.OrderPrimaryKey;
import org.springframework.data.domain.Slice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;
import org.springframework.data.domain.Pageable;

@Repository
public interface OrderRepository extends JpaRepository<Order, OrderPrimaryKey>, JpaSpecificationExecutor<Order> {
    Slice<Order> findAllBy(Pageable pageable);
}
