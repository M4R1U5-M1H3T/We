package com.lseg.supportportal.backend.core.filters.domain;

import java.util.List;
import java.util.Map;

import lombok.Builder;

@Builder
public record PageFilters(List<String> defaultFilters, Map<String, FilterEntry> filters) {

    @Builder
    public record FilterEntry(String title, FilterType type, boolean required, List<FilterOption> data, FilterProps props) {}

    @Builder
    public record FilterProps(String placeholder) {}
}