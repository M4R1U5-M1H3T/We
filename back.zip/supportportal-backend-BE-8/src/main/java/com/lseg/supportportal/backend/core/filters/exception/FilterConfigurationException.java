package com.lseg.supportportal.backend.core.filters.exception;

/**
 * Raised when the filter configuration (JSON resources under {@code classpath:filters/})
 * is missing, malformed, or internally inconsistent - e.g. a page profile references a
 * filter key that has no corresponding {@code FilterDefinition}.
 * This is a configuration/data problem rather than an illegal object state, so it is
 * modeled as its own exception type instead of a generic {@link IllegalStateException}.
 */
public class FilterConfigurationException extends RuntimeException {

    public FilterConfigurationException(final String message) {
        super(message);
    }

    public FilterConfigurationException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
