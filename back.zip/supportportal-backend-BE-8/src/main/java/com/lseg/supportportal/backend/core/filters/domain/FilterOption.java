package com.lseg.supportportal.backend.core.filters.domain;

public record FilterOption(String label, String value, boolean selected) {}