package com.lseg.supportportal.backend.core.search.specification;

import com.lseg.supportportal.backend.core.search.domain.FilterCriteria;
import com.lseg.supportportal.backend.core.search.domain.SearchRequest;
import com.lseg.supportportal.backend.core.search.util.SearchableFieldResolver;
import org.springframework.data.jpa.domain.Specification;

import java.util.Map;
import java.util.stream.Collectors;

public class SpecificationBuilder<T> {
    private final Map<String, String> keyToFieldName;

    public SpecificationBuilder(Class<T> entityClass) {
        this.keyToFieldName = SearchableFieldResolver.resolveSearchableFieldsByKey(entityClass)
                .entrySet()
                .stream()
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        entry -> entry.getValue().getName()
                ));
    }

    public Specification<T> build(SearchRequest searchRequest) {
        return searchRequest.filters().stream()
                .map(this::toSpecification)
                .reduce(((_, _, _) -> null), Specification::and);
    }

    private Specification<T> toSpecification(FilterCriteria filterCriteria) {
        final String fieldName = keyToFieldName.get(filterCriteria.key());
        if (fieldName == null) {
            throw new IllegalArgumentException("Unknown filter key " + filterCriteria.key());
        }
        return new GenericSpecification<>(filterCriteria, fieldName);
    }
}
