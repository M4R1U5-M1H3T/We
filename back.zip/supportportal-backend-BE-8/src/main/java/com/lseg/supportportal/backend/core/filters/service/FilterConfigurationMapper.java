package com.lseg.supportportal.backend.core.filters.service;

import java.lang.reflect.Field;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.lseg.supportportal.backend.core.filters.domain.Filter;
import com.lseg.supportportal.backend.core.filters.domain.FilterConfig;
import com.lseg.supportportal.backend.core.filters.domain.FilterDefinition;
import com.lseg.supportportal.backend.core.filters.domain.FilterOption;
import com.lseg.supportportal.backend.core.filters.domain.FilterType;
import com.lseg.supportportal.backend.core.filters.domain.PageFilters;
import com.lseg.supportportal.backend.core.filters.exception.FilterConfigurationException;
import com.lseg.supportportal.backend.core.metadata.Label;
import com.lseg.supportportal.backend.core.search.util.SearchableFieldResolver;
import com.lseg.supportportal.backend.tools.searchdatabase.datasets.domain.Dataset;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class FilterConfigurationMapper {

    private final FilterDataProvider filterDataProvider;

    public FilterConfigurationMapper(final FilterDataProvider filterDataProvider) {
        this.filterDataProvider = filterDataProvider;
    }

    public PageFilters toPageFilters(final Dataset dataset, final FilterConfig filterConfig, final Map<String, FilterDefinition> definitions) {
        final Map<String, Field> searchableFieldsByKey = SearchableFieldResolver.resolveSearchableFieldsByKey(dataset.getEntityClass());
        final Map<String, PageFilters.FilterEntry> filters = new LinkedHashMap<>();

        for (final Map.Entry<String, Filter> entry : filterConfig.filters().entrySet()) {
            final String filterKey = entry.getKey();
            final Filter filter = entry.getValue();
            final FilterDefinition definition = definitions.get(filterKey);
            if (definition == null) {
                throw new FilterConfigurationException(
                        "Requested unknown filter: '" + filterKey + "' - no matching entry in filter-definitions.json");
            }
            final String title = resolveTitle(filterKey, filterConfig.filters().get(filterKey), searchableFieldsByKey);
            filters.put(filterKey, buildFilterEntry(title, filterKey, filter, definition));
        }

        final List<String> defaultFilterKeys = List.copyOf(filterConfig.defaultFilterOrder());
        return PageFilters.builder().defaultFilters(defaultFilterKeys).filters(Collections.unmodifiableMap(filters)).build();
    }

    private PageFilters.FilterEntry buildFilterEntry(
            final String title, final String filterKey, final Filter filter, final FilterDefinition definition) {

        final List<FilterOption> filterData = filterDataProvider.getOptions(filterKey);

        if (definition.type() == FilterType.DROPDOWN && filterData.isEmpty()) {
            log.warn("Dropdown filter '{}' has no options configured in filter-values.json", filterKey);
        }

        final PageFilters.FilterProps props = PageFilters.FilterProps.builder().placeholder(filter.placeholder()).build();

        return PageFilters.FilterEntry.builder()
                .title(title)
                .type(definition.type())
                .required(filter.required())
                .data(filterData)
                .props(props)
                .build();
    }

    private String resolveTitle(final String filterKey, final Filter filter, final Map<String, Field> searchableFieldsByKeys) {
        final Field field = searchableFieldsByKeys.get(filterKey);
        if (field != null) {
            final Label label = field.getAnnotation(Label.class);
            if (label != null) {
                return label.value();
            }
        }

        if (filter.title() != null) {
            return filter.title();
        }

        log.warn("Filter '{}' has no matching @SearchableField - falling back to raw key as title", filterKey);
        return filterKey;
    }
}
