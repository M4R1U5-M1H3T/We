package com.lseg.supportportal.backend.tools.searchdatabase.datasets.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lseg.supportportal.backend.tools.searchdatabase.datasets.domain.ColumnInfo;
import com.lseg.supportportal.backend.tools.searchdatabase.datasets.service.DatasetService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/database")
@RequiredArgsConstructor
@Tag(name = "Datasets", description = "Endpoints for discovering available datasets and their column structure.")
public class DatasetController {

    private final DatasetService datasetService;

    @GetMapping("/datasets")
    @Operation(summary = "Retrieve dataset names", description = "Retrieves the names of all available datasets.")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved dataset names.")
    public ResponseEntity<List<String>> getAvailableDatasets() {
        return ResponseEntity.ok(datasetService.getAvailableDatasetNames());
    }

    @GetMapping("/{dataset}/columns")
    @Operation(summary = "Retrieve dataset column names", description = "Retrieves the column names for a dataset")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved column names.")
    @ApiResponse(responseCode = "404", description = "No dataset exists with the given name.")
    public ResponseEntity<List<ColumnInfo>> getDatasetColumns(@PathVariable String dataset) {
        return ResponseEntity.ok(datasetService.getColumns(dataset));
    }
}
