export type SearchOperator = 'EQUAL' | 'LIKE' | 'BETWEEN' | 'IN';

export type DateRangeValue = {
  from: string;
  to: string;
};

export type FilterCriteria = {
  key: string;
  operator: SearchOperator;
  value: string | string[] | DateRangeValue;
};
