import type { FilterConfig } from '@/components/dynamic-form';
import { buildSearchFilters } from '@/slices';

const filterConfig: FilterConfig = {
  defaultFilters: ['region'],
  filters: {
    region: { title: 'Region', type: 'dropdown', required: true, data: [], props: { placeholder: '' } },
    group: {
      title: 'Group',
      type: 'dropdown',
      required: false,
      data: [],
      props: { placeholder: '', multiple: true },
    },
    reutersCode: { title: 'Reuters Code', type: 'text', required: false, data: [], props: { placeholder: '' } },
    createdDate: { title: 'Created Date', type: 'date_range', required: false, data: [], props: { placeholder: '' } },
  },
};

describe('buildSearchFilters', () => {
  it('returns an empty array when there is no filter config', () => {
    expect(buildSearchFilters({ region: 'EMEA' }, null)).toEqual([]);
  });

  it('ignores filters without a value', () => {
    expect(buildSearchFilters({ region: '' }, filterConfig)).toEqual([]);
  });

  it('maps single-select dropdown filters to an EQUAL criteria', () => {
    expect(buildSearchFilters({ region: 'EMEA' }, filterConfig)).toEqual([
      { key: 'region', operator: 'EQUAL', value: 'EMEA' },
    ]);
  });

  it('maps multi-select dropdown filters to an IN criteria', () => {
    expect(buildSearchFilters({ group: 'group-1,group-2' }, filterConfig)).toEqual([
      { key: 'group', operator: 'IN', value: ['group-1', 'group-2'] },
    ]);
  });

  it('ignores multi-select dropdown filters that resolve to no values', () => {
    expect(buildSearchFilters({ group: ',' }, filterConfig)).toEqual([]);
  });

  it('maps text filters to a LIKE criteria', () => {
    expect(buildSearchFilters({ reutersCode: 'ABC' }, filterConfig)).toEqual([
      { key: 'reutersCode', operator: 'LIKE', value: 'ABC' },
    ]);
  });

  it('maps date_range filters to a BETWEEN criteria', () => {
    expect(buildSearchFilters({ createdDate: '2026-01-01,2026-01-31' }, filterConfig)).toEqual([
      { key: 'createdDate', operator: 'BETWEEN', value: { from: '2026-01-01T00:00:00', to: '2026-01-31T23:59:59' } },
    ]);
  });

  it('ignores date_range filters with a missing start or end date', () => {
    expect(buildSearchFilters({ createdDate: '2026-01-01,' }, filterConfig)).toEqual([]);
  });
});
