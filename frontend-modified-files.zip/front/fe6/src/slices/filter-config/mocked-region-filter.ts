import type { FilterConfig, FilterDefinition } from '@/components/dynamic-form';

// The Region filter is purely aesthetic on the frontend: it is no longer provided by the
// backend and its selected value is never sent as part of a search request. In the future
// it will be used to choose which database the data comes from.
export const MOCKED_REGION_FILTER_KEY = 'Region';

export const mockedRegionFilter: FilterDefinition = {
  title: 'Region',
  type: 'dropdown',
  required: false,
  data: [
    { label: 'AMER', value: 'AMER', selected: false },
    { label: 'EMEA', value: 'EMEA', selected: false },
    { label: 'APAC', value: 'APAC', selected: false },
  ],
  props: { placeholder: 'Optional' },
};

export const withMockedRegionFilter = (config: FilterConfig): FilterConfig => ({
  defaultFilters: config.defaultFilters.includes(MOCKED_REGION_FILTER_KEY)
    ? config.defaultFilters
    : [MOCKED_REGION_FILTER_KEY, ...config.defaultFilters],
  filters: {
    ...config.filters,
    [MOCKED_REGION_FILTER_KEY]: mockedRegionFilter,
  },
});
