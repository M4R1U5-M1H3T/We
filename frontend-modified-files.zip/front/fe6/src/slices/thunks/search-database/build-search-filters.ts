import type { FilterConfig } from '@/components/dynamic-form';
import { MOCKED_REGION_FILTER_KEY } from '@/slices/filter-config';

import type { DateRangeValue, FilterCriteria, SearchOperator } from './search-filter-types';

const DATE_RANGE_SEPARATOR = ',';

const FILTER_TYPE_OPERATORS: Record<string, SearchOperator> = {
  dropdown: 'EQUAL',
  text: 'LIKE',
  date_range: 'BETWEEN',
};

const buildDateRangeValue = (rawValue: string): DateRangeValue | null => {
  const [startDate, endDate] = rawValue.split(DATE_RANGE_SEPARATOR);

  if (!startDate || !endDate) {
    return null;
  }

  return { from: startDate, to: endDate };
};

const buildFilterCriterion = (filterConfig: FilterConfig, key: string, rawValue: string): FilterCriteria | null => {
  if (!rawValue) {
    return null;
  }

  const filterType = filterConfig.filters[key]?.type;
  const operator = FILTER_TYPE_OPERATORS[filterType!] ?? 'EQUAL';

  if (operator === 'BETWEEN') {
    const value = buildDateRangeValue(rawValue);

    return value ? { key, operator, value } : null;
  }

  return { key, operator, value: rawValue };
};

const isFilterCriteria = (criterion: FilterCriteria | null): criterion is FilterCriteria => criterion !== null;

export const buildSearchFilters = (
  filterValues: Record<string, string>,
  filterConfig: FilterConfig | null
): FilterCriteria[] => {
  if (!filterConfig) {
    return [];
  }

  return Object.entries(filterValues)
    .filter(([key]) => key !== MOCKED_REGION_FILTER_KEY)
    .map(([key, rawValue]) => buildFilterCriterion(filterConfig, key, rawValue))
    .filter(isFilterCriteria);
};
