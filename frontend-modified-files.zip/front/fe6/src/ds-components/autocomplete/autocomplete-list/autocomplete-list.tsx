import { createComponent } from '@lit/react';
import { AutocompleteList as DSAutocompleteList } from '@lseg-workspace/components/autocomplete';
import * as React from 'react';

export const AutocompleteList = createComponent({
  react: React,
  tagName: 'ds-autocomplete-list',
  elementClass: DSAutocompleteList,
});
