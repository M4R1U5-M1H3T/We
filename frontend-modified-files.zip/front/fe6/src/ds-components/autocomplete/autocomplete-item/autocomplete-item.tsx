import { createComponent } from '@lit/react';
import { AutocompleteItem as DSAutocompleteItem } from '@lseg-workspace/components/autocomplete';
import * as React from 'react';

export const AutocompleteItem = createComponent({
  react: React,
  tagName: 'ds-autocomplete-item',
  elementClass: DSAutocompleteItem,
  events: {
    onSelect: 'select',
  },
});
