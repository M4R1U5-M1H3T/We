import { createComponent } from '@lit/react';
import { Autocomplete as DSAutocomplete } from '@lseg-workspace/components/autocomplete';
import * as React from 'react';

export const Autocomplete = createComponent({
  react: React,
  tagName: 'ds-autocomplete',
  elementClass: DSAutocomplete,
  events: {
    onChange: 'change',
    onInput: 'input',
    onClear: 'clear',
  },
});
