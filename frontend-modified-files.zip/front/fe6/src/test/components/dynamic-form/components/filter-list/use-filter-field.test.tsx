import { describe, expect, jest, test } from '@jest/globals';
import { act, renderHook } from '@testing-library/react';

import { ComboboxField, DateRangeField, DropdownField } from '@/components/dynamic-form/components';
import { type FilterFieldProps, useFilterField } from '@/components/dynamic-form/components';

describe('useFilterField Custom Hook', () => {
  const createMockProps = (type: 'dropdown' | 'date_range', multiple = false): FilterFieldProps => ({
    filterKey: 'Region',
    filterItem: {
      title: 'Region',
      type,
      required: true,
      data: [],
      props: {
        placeholder: 'Select option...',
        multiple,
      },
    },
    value: undefined,
    onChange: jest.fn(),
    onRemove: jest.fn(),
  });

  test('should return the ComboboxField component when type is a single-select dropdown', () => {
    const props = createMockProps('dropdown');
    const { result } = renderHook(() => useFilterField(props));

    expect(result.current.Component).toBe(ComboboxField);
  });

  test('should return the DropdownField component when type is a multi-select dropdown', () => {
    const props = createMockProps('dropdown', true);
    const { result } = renderHook(() => useFilterField(props));

    expect(result.current.Component).toBe(DropdownField);
  });

  test('should return the DateRangeField component when type is date_range', () => {
    const props = createMockProps('date_range');
    const { result } = renderHook(() => useFilterField(props));

    expect(result.current.Component).toBe(DateRangeField);
  });

  test('should send the new value up to the parent component when a change happens', () => {
    const props = createMockProps('dropdown');
    const { result } = renderHook(() => useFilterField(props));

    act(() => {
      result.current.handleChange('AMER');
    });

    expect(props.onChange).toHaveBeenCalledWith('Region', 'AMER');
  });

  test('should tell the parent component to remove this filter field', () => {
    const props = createMockProps('dropdown');
    const { result } = renderHook(() => useFilterField(props));

    act(() => {
      result.current.handleRemove();
    });

    expect(props.onRemove).toHaveBeenCalledWith('Region');
  });
});
