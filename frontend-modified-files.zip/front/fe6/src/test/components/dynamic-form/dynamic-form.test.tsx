import { describe, expect, jest, test } from '@jest/globals';
import { render } from '@testing-library/react';

import { DynamicForm } from '@/components';
import { mockFilterConfig } from '@/test/__mocks__/mock-filter-config';

describe('DynamicForm snapshot test', () => {
  test('matches snapshot', () => {
    const { asFragment } = render(<DynamicForm config={mockFilterConfig} onFiltersChange={jest.fn()} />);
    expect(asFragment()).toMatchSnapshot();
  });
});

describe('DynamicForm Add Filter dropdown', () => {
  test('excludes already-added filters from the Add Filter options', () => {
    const { container } = render(<DynamicForm config={mockFilterConfig} onFiltersChange={jest.fn()} />);

    const addFilterSelect = container.querySelector('.add-filter-menu ds-select');
    const optionLabels = Array.from(addFilterSelect?.querySelectorAll('ds-option') ?? []).map(
      option => option.textContent?.trim()
    );

    // "Region" is visible by default (a required filter), so it should not be offered again.
    expect(optionLabels).not.toContain('Region');
    expect(optionLabels).toContain('Group');
  });
});
