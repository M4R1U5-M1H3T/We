import type { FilterConfig } from '@/components/dynamic-form';
import { fetchFilterConfig, filtersReducer, MOCKED_REGION_FILTER_KEY } from '@/slices';

const backendConfig: FilterConfig = {
  defaultFilters: ['Group'],
  filters: {
    Group: {
      title: 'Group',
      type: 'dropdown',
      required: false,
      data: [{ label: 'Group 1', value: 'group-1', selected: false }],
      props: { placeholder: 'Optional' },
    },
  },
};

describe('filtersSlice reducer', () => {
  it('returns the initial state', () => {
    const state = filtersReducer(undefined, { type: '@@INIT' });

    expect(state).toEqual({ config: null, isLoading: false, error: null });
  });

  it('merges the mocked Region filter into the config on fulfilled fetch', () => {
    const action = fetchFilterConfig.fulfilled(backendConfig, 'reqId', 'orders');
    const state = filtersReducer(undefined, action);

    expect(state.config?.filters[MOCKED_REGION_FILTER_KEY]).toEqual({
      title: 'Region',
      type: 'dropdown',
      required: false,
      data: [
        { label: 'AMER', value: 'AMER', selected: false },
        { label: 'EMEA', value: 'EMEA', selected: false },
        { label: 'APAC', value: 'APAC', selected: false },
      ],
      props: { placeholder: 'Optional' },
    });
    expect(state.config?.filters.Group).toEqual(backendConfig.filters.Group);
    expect(state.config?.defaultFilters).toEqual([MOCKED_REGION_FILTER_KEY, 'Group']);
  });

  it('does not duplicate Region in defaultFilters if the backend already lists it', () => {
    const configWithRegionDefault: FilterConfig = {
      ...backendConfig,
      defaultFilters: [MOCKED_REGION_FILTER_KEY, 'Group'],
    };
    const action = fetchFilterConfig.fulfilled(configWithRegionDefault, 'reqId', 'orders');
    const state = filtersReducer(undefined, action);

    expect(state.config?.defaultFilters).toEqual([MOCKED_REGION_FILTER_KEY, 'Group']);
  });
});
