import type { FilterConfig } from '@/components/dynamic-form';
import { buildSearchFilters } from '@/slices';

const filterConfig: FilterConfig = {
  defaultFilters: ['region'],
  filters: {
    region: { title: 'Region', type: 'dropdown', required: true, data: [], props: { placeholder: '' } },
    reutersCode: { title: 'Reuters Code', type: 'text', required: false, data: [], props: { placeholder: '' } },
    createdDate: { title: 'Created Date', type: 'date_range', required: false, data: [], props: { placeholder: '' } },
  },
};

describe('buildSearchFilters', () => {
  it('returns an empty array when there is no filter config', () => {
    expect(buildSearchFilters({ region: 'EMEA' }, null)).toEqual([]);
  });

  it('ignores filters without a value', () => {
    expect(buildSearchFilters({ region: '' }, filterConfig)).toEqual([]);
  });

  it('maps dropdown filters to an EQUAL criteria', () => {
    expect(buildSearchFilters({ region: 'EMEA' }, filterConfig)).toEqual([
      { key: 'region', operator: 'EQUAL', value: 'EMEA' },
    ]);
  });

  it('maps text filters to a LIKE criteria', () => {
    expect(buildSearchFilters({ reutersCode: 'ABC' }, filterConfig)).toEqual([
      { key: 'reutersCode', operator: 'LIKE', value: 'ABC' },
    ]);
  });

  it('maps date_range filters to a BETWEEN criteria using dates only, without a time component', () => {
    expect(buildSearchFilters({ createdDate: '2026-01-01,2026-01-31' }, filterConfig)).toEqual([
      { key: 'createdDate', operator: 'BETWEEN', value: { from: '2026-01-01', to: '2026-01-31' } },
    ]);
  });

  it('ignores date_range filters with a missing start or end date', () => {
    expect(buildSearchFilters({ createdDate: '2026-01-01,' }, filterConfig)).toEqual([]);
  });

  it('excludes the mocked Region filter from the payload sent to the backend', () => {
    expect(buildSearchFilters({ region: 'EMEA', Region: 'AMER' }, filterConfig)).toEqual([
      { key: 'region', operator: 'EQUAL', value: 'EMEA' },
    ]);
  });
});
