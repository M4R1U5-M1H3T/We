import { AddFilterMenu } from '@/components/dynamic-form/components';
import { FilterList } from '@/components/dynamic-form/components';

import type { FilterConfig } from './types';
import { useDynamicForm } from './use-dynamic-form';

export interface DynamicFormProps {
  config: FilterConfig | null;
  onFiltersChange?: (values: Record<string, string>, isValid: boolean) => void;
}

export const DynamicForm = ({ config, onFiltersChange }: DynamicFormProps) => {
  const {
    filters,
    defaultFilters,
    allFilterKeys,
    visibleFilters,
    selectedValues,
    addFilterKey,
    handleChange,
    handleAddFilter,
    handleRemoveFilter,
  } = useDynamicForm(config, onFiltersChange);

  const pendingDefaultFilters = defaultFilters.filter(filterKey => !visibleFilters.includes(filterKey));
  const availableFilterKeys = allFilterKeys.filter(filterKey => !visibleFilters.includes(filterKey));

  return (
    <div className="dynamic-form">
      <FilterList
        filters={filters}
        visibleFilters={visibleFilters}
        selectedValues={selectedValues}
        onChange={handleChange}
        onRemove={handleRemoveFilter}
      />

      <AddFilterMenu
        filters={filters}
        allFilterKeys={availableFilterKeys}
        pendingDefaultFilters={pendingDefaultFilters}
        addFilterKey={addFilterKey}
        onAddFilter={handleAddFilter}
      />
    </div>
  );
};
