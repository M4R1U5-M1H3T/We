import type { FilterDefinition } from '@/components';

import { ComboboxField } from '../combobox-field';
import { DateRangeField } from '../date-range-field';
import { DropdownField } from '../dropdown-field';
import { TextInputField } from '../text-input-field';

export interface FilterFieldProps {
  filterKey: string;
  filterItem: FilterDefinition;
  value: string | undefined;
  onChange: (filterKey: string, value: string) => void;
  onRemove: (filterKey: string) => void;
}

const FILTER_COMPONENTS = {
  dropdown: ComboboxField,
  date_range: DateRangeField,
  text: TextInputField,
} as const;

type FilterType = keyof typeof FILTER_COMPONENTS;

export const useFilterField = (props: FilterFieldProps) => {
  const { filterKey, filterItem, onChange, onRemove } = props;

  // Multi-select dropdowns keep the tag-based Select; single-select dropdowns get
  // free text support (besides the default choices) via the Autocomplete-based ComboboxField.
  const Component =
    filterItem.type === 'dropdown' && filterItem.props?.multiple
      ? DropdownField
      : FILTER_COMPONENTS[filterItem.type as FilterType];

  const handleChange = (newValue: string) => {
    onChange(filterKey, newValue);
  };

  const handleRemove = () => {
    onRemove(filterKey);
  };

  return {
    Component,
    handleChange,
    handleRemove,
  };
};
