import { Autocomplete, AutocompleteItem, AutocompleteList } from '@/ds-components';

export interface ComboboxFieldOption {
  label: string;
  value: string;
}

export interface ComboboxFieldProps {
  data?: ComboboxFieldOption[];
  value?: string;
  placeholder?: string;
  multiple?: boolean;
  clearable?: boolean;
  onChange?: (value: string) => void;
}

export const ComboboxField = ({ data = [], value, placeholder, clearable = true, onChange }: ComboboxFieldProps) => {
  const handleChange = (event: Event) => {
    const target = event.target as HTMLElement & { value: string };
    onChange?.(target.value);
  };

  return (
    <Autocomplete
      value={value}
      placeholder={placeholder}
      clearable={clearable}
      highlightMatches={true}
      onChange={handleChange}
    >
      <AutocompleteList>
        {data.map(option => (
          <AutocompleteItem key={option.value} label={option.label} />
        ))}
      </AutocompleteList>
    </Autocomplete>
  );
};
