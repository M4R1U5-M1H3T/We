import type { FilterConfig } from '@/components/dynamic-form';

export const mockFilterConfig: FilterConfig = {
  defaultFilters: ['Region', 'Group', 'Reuters Code', 'Created Date'],
  filters: {
    Region: {
      title: 'Region',
      type: 'dropdown',
      required: true,
      data: [
        { label: 'AMER', value: 'AMER', selected: false },
        { label: 'EMEA', value: 'EMEA', selected: false },
        { label: 'APAC', value: 'APAC', selected: false },
      ],
      props: { placeholder: 'Required' },
    },
    Group: {
      title: 'Group',
      type: 'dropdown',
      required: false,
      data: [
        { label: 'Group 1', value: 'group-1', selected: false },
        { label: 'Group 2', value: 'group-2', selected: false },
      ],
      props: { placeholder: 'Optional' },
    },
    'Reuters Code': {
      title: 'Reuters Code',
      type: 'dropdown',
      required: false,
      data: [],
      props: { placeholder: 'Optional' },
    },
    'Created Date': {
      title: 'Created Date',
      type: 'date_range',
      required: false,
      data: [],
      props: { placeholder: 'Optional' },
    },
    Account: {
      title: 'Account',
      type: 'dropdown',
      required: false,
      data: [],
      props: { placeholder: 'Optional' },
    },
    Side: {
      title: 'Side',
      type: 'dropdown',
      required: false,
      data: [
        { label: 'Buy', value: 'BUY', selected: false },
        { label: 'Sell', value: 'SELL', selected: false },
      ],
      props: { placeholder: 'Optional' },
    },
    Tag: {
      title: 'Tag',
      type: 'select',
      required: false,
      data: [],
      props: { placeholder: 'Optional' },
    },
  },
};
