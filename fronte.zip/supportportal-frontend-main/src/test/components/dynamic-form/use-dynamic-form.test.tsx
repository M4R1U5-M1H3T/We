import { act, renderHook } from '@testing-library/react';

import { useDynamicForm } from '@/components';
import { mockFilterConfig } from '@/test/__mocks__/mock-filter-config';

describe('useDynamicForm Custom Hook', () => {
  test('should initialize with correct default filters and values', () => {
    const { result } = renderHook(() => useDynamicForm(mockFilterConfig));

    expect(result.current.visibleFilters).toEqual(['Region']);

    expect(result.current.allFilterKeys).toContain('Region');
    expect(result.current.allFilterKeys).toContain('Group');

    expect(result.current.selectedValues).toEqual({});
    expect(result.current.isValid).toBe(false);
  });

  test('should update selectedValues and become valid when a value is changed', () => {
    const { result } = renderHook(() => useDynamicForm(mockFilterConfig));
    act(() => {
      result.current.handleChange('Region', 'AMER');
    });
    expect(result.current.selectedValues).toEqual({ Region: 'AMER' });
    expect(result.current.isValid).toBe(true);
  });

  test('should allow adding an optional filter', () => {
    const { result } = renderHook(() => useDynamicForm(mockFilterConfig));
    act(() => {
      result.current.handleAddFilter('Group');
    });
    expect(result.current.visibleFilters).toEqual(['Region', 'Group']);
  });

  test('should ignore requests to add a filter that is already visible', () => {
    const { result } = renderHook(() => useDynamicForm(mockFilterConfig));
    act(() => {
      result.current.handleAddFilter('Region');
    });
    expect(result.current.visibleFilters).toEqual(['Region']);
  });

  test('should refuse to remove a required filter field', () => {
    const { result } = renderHook(() => useDynamicForm(mockFilterConfig));
    act(() => {
      result.current.handleRemoveFilter('Region');
    });
    expect(result.current.visibleFilters).toContain('Region');
  });
});
