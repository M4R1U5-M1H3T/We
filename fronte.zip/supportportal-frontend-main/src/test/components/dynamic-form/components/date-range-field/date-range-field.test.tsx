import { describe, expect, jest, test } from '@jest/globals';
import { render } from '@testing-library/react';

import { DateRangeField } from '@/components/dynamic-form/components';

describe('DateRangeField Component Snapshot', () => {
  test('matches snapshot with standard placeholder and value properties', () => {
    const { asFragment } = render(
      <DateRangeField value="2026-08-17" placeholder="Select Date Range" onChange={jest.fn()} />
    );
    expect(asFragment()).toMatchSnapshot();
  });
});
