import { describe, expect, jest, test } from '@jest/globals';
import { render } from '@testing-library/react';

import { AddFilterMenu } from '@/components/dynamic-form/components';
import { mockFilterConfig } from '@/test/__mocks__/mock-filter-config';

describe('AddFilterMenu subcomponent Snapshot', () => {
  test('matches snapshot with pending unselected filters', () => {
    const visibleFilters = ['Region'];
    const pendingDefaultFilters = mockFilterConfig.defaultFilters.filter(key => !visibleFilters.includes(key));

    const { asFragment } = render(
      <AddFilterMenu
        filters={mockFilterConfig.filters}
        allFilterKeys={Object.keys(mockFilterConfig.filters)}
        pendingDefaultFilters={pendingDefaultFilters}
        addFilterKey=""
        onAddFilter={jest.fn()}
      />
    );

    expect(asFragment()).toMatchSnapshot();
  });
});
