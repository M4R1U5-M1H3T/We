import { describe, expect, jest, test } from '@jest/globals';
import { render } from '@testing-library/react';

import { DropdownField } from '@/components/dynamic-form/components';

describe('DropdownField Component Snapshot', () => {
  const mockOptions = [
    { label: 'AMER', value: 'AMER' },
    { label: 'EMEA', value: 'EMEA' },
  ];

  test('matches snapshot with a single selection layout', () => {
    const { asFragment } = render(
      <DropdownField
        data={mockOptions}
        value="AMER"
        placeholder="Select Region"
        multiple={false}
        onChange={jest.fn()}
      />
    );
    expect(asFragment()).toMatchSnapshot();
  });

  test('matches snapshot with multiple selection layout enabled', () => {
    const { asFragment } = render(
      <DropdownField data={mockOptions} placeholder="Select Multiple" multiple={true} onChange={jest.fn()} />
    );
    expect(asFragment()).toMatchSnapshot();
  });
});
