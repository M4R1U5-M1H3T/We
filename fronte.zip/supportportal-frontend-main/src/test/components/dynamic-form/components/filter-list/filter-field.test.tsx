import { describe, expect, jest, test } from '@jest/globals';
import { render } from '@testing-library/react';

import { FilterField } from '@/components/dynamic-form/components/filter-list/filter-field';

describe('FilterField Subcomponent Snapshots', () => {
  test('matches snapshot for a required dropdown field', () => {
    const mockProps = {
      filterKey: 'Region',
      filterItem: {
        title: 'Region',
        type: 'dropdown',
        required: true,
        data: [{ label: 'AMER', value: 'AMER', selected: false }],
        props: { placeholder: 'Select Region' },
      },
      value: 'AMER',
      onChange: jest.fn(),
      onRemove: jest.fn(),
    };

    const { asFragment } = render(<FilterField {...mockProps} />);
    expect(asFragment()).toMatchSnapshot();
  });

  test('matches snapshot for an optional date range field with a remove button', () => {
    const mockProps = {
      filterKey: 'Created Date',
      filterItem: {
        title: 'Created Date',
        type: 'date_range',
        required: false,
        data: [],
        props: { placeholder: 'Select Dates' },
      },
      value: undefined,
      onChange: jest.fn(),
      onRemove: jest.fn(),
    };

    const { asFragment } = render(<FilterField {...mockProps} />);
    expect(asFragment()).toMatchSnapshot();
  });

  test('matches fallback snapshot if filter type is not implemented', () => {
    const mockProps = {
      filterKey: 'UnknownField',
      filterItem: {
        title: 'Unknown Field',
        type: 'unsupported_type_format',
        required: false,
        data: [],
        props: {
          placeholder: 'Select option...',
        },
      },
      value: undefined,
      onChange: jest.fn(),
      onRemove: jest.fn(),
    };

    const { asFragment } = render(<FilterField {...mockProps} />);
    expect(asFragment()).toMatchSnapshot();
  });
});
