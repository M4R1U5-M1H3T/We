import { describe, expect, jest, test } from '@jest/globals';
import { render } from '@testing-library/react';

import { FilterList } from '@/components/dynamic-form/components';
import { mockFilterConfig } from '@/test/__mocks__/mock-filter-config';

describe('FilterList subcomponent Snapshot', () => {
  test('matches snapshot with multiple active filters', () => {
    const { asFragment } = render(
      <FilterList
        filters={mockFilterConfig.filters}
        visibleFilters={['Region', 'Group']}
        selectedValues={{ Region: 'AMER' }}
        onChange={jest.fn()}
        onRemove={jest.fn()}
      />
    );

    expect(asFragment()).toMatchSnapshot();
  });
});
