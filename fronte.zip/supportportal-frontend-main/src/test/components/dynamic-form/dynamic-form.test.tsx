import { describe, expect, jest, test } from '@jest/globals';
import { render } from '@testing-library/react';

import { DynamicForm } from '@/components';
import { mockFilterConfig } from '@/test/__mocks__/mock-filter-config';

describe('DynamicForm snapshot test', () => {
  test('matches snapshot', () => {
    const { asFragment } = render(<DynamicForm config={mockFilterConfig} onFiltersChange={jest.fn()} />);
    expect(asFragment()).toMatchSnapshot();
  });
});
