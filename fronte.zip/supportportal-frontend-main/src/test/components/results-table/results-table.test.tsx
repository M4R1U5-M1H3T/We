import { render, screen } from '@testing-library/react';

import { ResultsTable } from '@/components';
import type { SearchResults } from '@/features';

const emptyResults: SearchResults = { columns: [], rows: [] };

const populatedResults: SearchResults = {
  columns: [
    { name: 'id', displayName: 'ID' },
    { name: 'customerName', displayName: 'Customer Name' },
  ],
  rows: [
    { id: 1, customerName: 'Alice' },
    { id: 2, customerName: 'Bob' },
  ],
};

describe('Snapshot tests', () => {
  it('matches snapshot with no results', () => {
    const { container } = render(<ResultsTable results={emptyResults} />);
    expect(container).toMatchSnapshot();
  });

  it('matches snapshot with results', () => {
    const { container } = render(<ResultsTable results={populatedResults} />);
    expect(container).toMatchSnapshot();
  });
});

describe('Behaviour tests', () => {
  it('renders the "Results" heading', () => {
    render(<ResultsTable results={emptyResults} />);
    expect(screen.getByRole('heading', { name: 'Results' })).toBeInTheDocument();
  });

  it('renders a ds-data-grid element', () => {
    const { container } = render(<ResultsTable results={emptyResults} />);
    expect(container.querySelector('ds-data-grid')).toBeInTheDocument();
  });

  it('maps each column definition to a field/headerName pair with the shared min width', () => {
    const { container } = render(<ResultsTable results={populatedResults} />);
    const grid = container.querySelector('ds-data-grid') as HTMLElement & {
      columnDefs: { field: string; headerName: string; minWidth: number }[];
    };

    expect(grid.columnDefs).toEqual([
      { field: 'id', headerName: 'ID', minWidth: 150 },
      { field: 'customerName', headerName: 'Customer Name', minWidth: 150 },
    ]);
  });

  it('passes the rows through as rowData unchanged', () => {
    const { container } = render(<ResultsTable results={populatedResults} />);
    const grid = container.querySelector('ds-data-grid') as HTMLElement & { rowData: unknown };

    expect(grid.rowData).toEqual(populatedResults.rows);
  });

  it('renders with an empty grid when there are no columns or rows', () => {
    const { container } = render(<ResultsTable results={emptyResults} />);
    const grid = container.querySelector('ds-data-grid') as HTMLElement & {
      columnDefs: unknown[];
      rowData: unknown[];
    };

    expect(grid.columnDefs).toEqual([]);
    expect(grid.rowData).toEqual([]);
  });
});
