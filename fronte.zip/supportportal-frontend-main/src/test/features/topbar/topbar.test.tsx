import '@testing-library/jest-dom';

import { act, render, screen } from '@testing-library/react';
import { MemoryRouter, useLocation } from 'react-router-dom';

import { TopBar } from '@/features';

const LocationDisplay = () => {
  const location = useLocation();

  return <div data-testid="location">{location.pathname}</div>;
};

const renderTopBar = (route = '/tora-oems') =>
  render(
    <MemoryRouter initialEntries={[route]}>
      <TopBar />
      <LocationDisplay />
    </MemoryRouter>
  );

describe('Snapshot tests', () => {
  it('matches snapshot on the base OEMS page', () => {
    const { container } = renderTopBar('/tora-oems');
    expect(container).toMatchSnapshot();
  });

  it('matches snapshot on a sub-page', () => {
    const { container } = renderTopBar('/tora-oems/search');
    expect(container).toMatchSnapshot();
  });
});

describe('Behaviour tests', () => {
  it('shows the OEMS Support label without a sub-page name on the base page', () => {
    renderTopBar('/tora-oems');

    expect(screen.getByText('OEMS Support')).toBeInTheDocument();
    expect(screen.queryByText('Search')).not.toBeInTheDocument();
    expect(screen.queryByText('Track Order')).not.toBeInTheDocument();
    expect(screen.queryByText('AI Chat')).not.toBeInTheDocument();
  });

  it.each([
    ['/tora-oems/search', 'Search'],
    ['/tora-oems/track-order', 'Track Order'],
    ['/tora-oems/ai-chat', 'AI Chat'],
  ])('shows the sub-page name for %s', (route, subPageName) => {
    renderTopBar(route);

    expect(screen.getByText('OEMS Support')).toBeInTheDocument();
    expect(screen.getByText(subPageName)).toBeInTheDocument();
  });

  it('shows the connected to production badge', () => {
    renderTopBar('/tora-oems');

    expect(screen.getByText('Connected to Production')).toBeInTheDocument();
  });

  it('navigates back to the OEMS home page when the OEMS Support label is clicked', async () => {
    renderTopBar('/tora-oems/search');

    await act(async () => {
      screen.getByText('OEMS Support').dispatchEvent(new MouseEvent('click', { bubbles: true }));
      await Promise.resolve();
    });

    expect(screen.getByTestId('location')).toHaveTextContent('/tora-oems');
  });

  it('navigates to the AI chat page when the AI Chat action button is clicked', async () => {
    renderTopBar('/tora-oems');

    const button = document.querySelector('ds-button')!;
    await act(async () => {
      button.dispatchEvent(new Event('click', { bubbles: true }));
      await Promise.resolve();
    });

    expect(screen.getByTestId('location')).toHaveTextContent('/tora-oems/ai-chat');
  });
});
