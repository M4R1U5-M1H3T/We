import '@testing-library/jest-dom';

import { act, render, screen } from '@testing-library/react';
import { MemoryRouter, useLocation } from 'react-router-dom';

import { HomePage } from '@/features';

const LocationDisplay = () => {
  const location = useLocation();

  return <div data-testid="location">{location.pathname}</div>;
};

const renderPage = () =>
  render(
    <MemoryRouter initialEntries={['/']}>
      <HomePage />
      <LocationDisplay />
    </MemoryRouter>
  );

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = renderPage();
    expect(container).toMatchSnapshot();
  });
});

describe('Behaviour tests', () => {
  it('renders the tools card with all three tool buttons', () => {
    renderPage();

    expect(screen.getByText('Tools')).toBeInTheDocument();
    expect(screen.getByText('AI Chat')).toBeInTheDocument();
    expect(screen.getByText('Search')).toBeInTheDocument();
    expect(screen.getByText('Track Order')).toBeInTheDocument();
  });

  it('navigates to the AI chat page when the AI Chat button is clicked', async () => {
    renderPage();

    const button = screen.getByText('AI Chat').closest('ds-button')!;
    await act(async () => {
      button.dispatchEvent(new Event('click', { bubbles: true }));
      await Promise.resolve();
    });

    expect(screen.getByTestId('location')).toHaveTextContent('/tora-oems/ai-chat');
  });

  it('navigates to the search page when the Search button is clicked', async () => {
    renderPage();

    const button = screen.getByText('Search').closest('ds-button')!;
    await act(async () => {
      button.dispatchEvent(new Event('click', { bubbles: true }));
      await Promise.resolve();
    });

    expect(screen.getByTestId('location')).toHaveTextContent('/tora-oems/search');
  });

  it('navigates to the track order page when the Track Order button is clicked', async () => {
    renderPage();

    const button = screen.getByText('Track Order').closest('ds-button')!;
    await act(async () => {
      button.dispatchEvent(new Event('click', { bubbles: true }));
      await Promise.resolve();
    });

    expect(screen.getByTestId('location')).toHaveTextContent('/tora-oems/track-order');
  });
});
