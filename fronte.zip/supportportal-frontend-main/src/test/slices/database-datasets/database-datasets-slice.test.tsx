import {
  databaseDatasetsReducer,
  fetchDatasetsThunk,
  selectDatasets,
  selectDatasetsError,
  selectDatasetsStatus,
} from '@/slices';
import type { RootState } from '@/store/store';

const mockDatasetsList = ['Orders', 'Customers', 'Products'];

describe('databaseDatasetsSlice reducer', () => {
  it('returns the initial state', () => {
    const state = databaseDatasetsReducer(undefined, { type: '@@INIT' });

    expect(state).toEqual({
      items: [],
      status: 'idle',
      error: null,
    });
  });

  describe('fetchDatasetsThunk', () => {
    it('sets status to loading on pending', () => {
      const action = fetchDatasetsThunk.pending('reqId');
      const state = databaseDatasetsReducer(undefined, action);

      expect(state.status).toBe('loading');
    });

    it('stores items and sets status to success on fulfilled', () => {
      const action = fetchDatasetsThunk.fulfilled(mockDatasetsList, 'reqId');
      const state = databaseDatasetsReducer(undefined, action);

      expect(state.status).toBe('success');
      expect(state.items).toEqual(mockDatasetsList);
    });

    it('sets status to failed and maps custom error message on rejected', () => {
      const rejectPayload = { message: 'Database lookup timed out', statusCode: 504 };
      const action = fetchDatasetsThunk.rejected(null, 'reqId', undefined, rejectPayload);
      const state = databaseDatasetsReducer(undefined, action);

      expect(state.status).toBe('failed');
      expect(state.error).toBe('Database lookup timed out');
    });

    it('falls back to default error text on rejected when payload message is missing', () => {
      const action = fetchDatasetsThunk.rejected(null, 'reqId', undefined, undefined);
      const state = databaseDatasetsReducer(undefined, action);

      expect(state.status).toBe('failed');
      expect(state.error).toBe('Failed to fetch datasets');
    });
  });
});

describe('databaseDatasetsSlice selectors', () => {
  const buildMockState = (items: string[], status: any, error: string | null): RootState =>
    ({
      datasets: {
        items,
        status,
        error,
      },
    }) as unknown as RootState;

  it('selectDatasets extracts items array from state root', () => {
    const state = buildMockState(mockDatasetsList, 'success', null);
    expect(selectDatasets(state)).toEqual(mockDatasetsList);
  });

  it('selectDatasetsStatus extracts current operation status flags', () => {
    const state = buildMockState([], 'loading', null);
    expect(selectDatasetsStatus(state)).toBe('loading');
  });

  it('selectDatasetsError extracts descriptive failure reason data', () => {
    const state = buildMockState([], 'failed', 'Connection refused');
    expect(selectDatasetsError(state)).toBe('Connection refused');
  });
});
