import { describe, expect, jest, test } from '@jest/globals';
import axios from 'axios';

import { fetchFilterConfig } from '@/slices';
import { mockFilterConfig } from '@/test/__mocks__/mock-filter-config';

describe('filterThunks - fetchFilterConfig', () => {
  afterEach(() => {
    jest.restoreAllMocks();
  });

  test('dispatches fulfilled action and returns config data on successful API call', async () => {
    const axiosSpy = jest.spyOn(axios, 'get').mockResolvedValueOnce({ data: mockFilterConfig });

    const dispatch = jest.fn() as any;
    const thunk = fetchFilterConfig('orders');

    const result = await thunk(dispatch, () => ({}) as any, undefined as any);
    expect(result.meta.requestStatus).toBe('fulfilled');
    expect(result.payload).toEqual(mockFilterConfig);
    expect(axiosSpy).toHaveBeenCalledWith('/api/database/filters/orders');
  });

  test('dispatches rejected action with error message on failed API call', async () => {
    const errorMessage = 'Network Error';
    jest.spyOn(axios, 'get').mockRejectedValueOnce(new Error(errorMessage));

    const dispatch = jest.fn() as any;
    const thunk = fetchFilterConfig('orders');

    const result = await thunk(dispatch, () => ({}) as any, undefined as any);
    expect(result.meta.requestStatus).toBe('rejected');
    expect(result.payload).toBe(errorMessage);
  });
});
