import { jest } from '@jest/globals';

const mockAxiosGet = jest.fn<<T>() => Promise<{ data: T }>>();

jest.unstable_mockModule('axios', () => ({
  __esModule: true,
  default: {
    get: mockAxiosGet,
    isAxiosError: jest.fn(() => false),
  },
}));

const { fetchDatasetsThunk } = await import('@/slices');

describe('fetchDatasetsThunk', () => {
  beforeEach(() => {
    mockAxiosGet.mockReset();
  });

  it('dispatches fulfilled with dataset items array on successful API call', async () => {
    const mockDatasets = ['Orders', 'Customers'];
    mockAxiosGet.mockResolvedValue({ data: mockDatasets });

    const dispatch = jest.fn();
    const thunk = fetchDatasetsThunk();

    const result = await thunk(dispatch as any, jest.fn() as any, undefined);

    expect(mockAxiosGet).toHaveBeenCalledWith('/api/database/datasets');
    expect(result.type).toBe('datasets/fetchDatasets/fulfilled');
    expect(result.payload).toEqual(mockDatasets);
  });

  it('dispatches rejected with wrapped error payload when API call fails', async () => {
    const apiError = new Error('Not Found');
    mockAxiosGet.mockRejectedValue(apiError);

    const dispatch = jest.fn();
    const thunk = fetchDatasetsThunk();

    const result = await thunk(dispatch as any, jest.fn() as any, undefined);

    expect(result.type).toBe('datasets/fetchDatasets/rejected');
    expect(result.payload).toBeDefined();
  });
});
