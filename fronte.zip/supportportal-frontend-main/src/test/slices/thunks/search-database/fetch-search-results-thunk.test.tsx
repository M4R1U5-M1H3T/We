import { jest } from '@jest/globals';

const mockAxiosGet = jest.fn<<T>() => Promise<{ data: T }>>();

jest.unstable_mockModule('axios', () => ({
  __esModule: true,
  default: {
    get: mockAxiosGet,
    isAxiosError: jest.fn(() => false),
  },
}));

const { fetchSearchResultsThunk } = await import('@/slices');

describe('fetchSearchResultsThunk', () => {
  beforeEach(() => {
    mockAxiosGet.mockReset();
  });

  it('dispatches fulfilled with database rows on successful API call', async () => {
    const mockRows = [{ id: 1, name: 'Item A' }];
    mockAxiosGet.mockResolvedValue({ data: mockRows });

    const dispatch = jest.fn();
    const thunk = fetchSearchResultsThunk('Orders');

    const result = await thunk(dispatch as any, jest.fn() as any, undefined);

    expect(mockAxiosGet).toHaveBeenCalledWith('/api/database/orders');
    expect(result.type).toBe('search/fetchSearchResults/fulfilled');
    expect(result.payload).toEqual(mockRows);
  });

  it('dispatches rejected with wrapped error payload when API call fails', async () => {
    const apiError = new Error('Database Error');
    mockAxiosGet.mockRejectedValue(apiError);

    const dispatch = jest.fn();
    const thunk = fetchSearchResultsThunk('Orders');

    const result = await thunk(dispatch as any, jest.fn() as any, undefined);

    expect(result.type).toBe('search/fetchSearchResults/rejected');
    expect(result.payload).toBeDefined();
  });
});
