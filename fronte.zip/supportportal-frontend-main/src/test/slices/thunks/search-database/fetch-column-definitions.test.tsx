import { jest } from '@jest/globals';

const mockAxiosGet = jest.fn<<T>() => Promise<{ data: T }>>();

jest.unstable_mockModule('axios', () => ({
  __esModule: true,
  default: {
    get: mockAxiosGet,
    isAxiosError: jest.fn(() => false),
  },
}));

const { fetchColumnDefinitionsThunk } = await import('@/slices');

describe('fetchColumnDefinitionsThunk', () => {
  beforeEach(() => {
    mockAxiosGet.mockReset();
  });

  it('dispatches fulfilled with column definitions on successful API call', async () => {
    const mockColumns = [{ name: 'id', displayName: 'ID' }];
    mockAxiosGet.mockResolvedValue({ data: mockColumns });

    const dispatch = jest.fn();
    const thunk = fetchColumnDefinitionsThunk('Orders');

    const result = await thunk(dispatch as any, jest.fn() as any, undefined);

    expect(mockAxiosGet).toHaveBeenCalledWith('/api/database/orders/columns');
    expect(result.type).toBe('search/fetchColumnDefinitions/fulfilled');
    expect(result.payload).toEqual(mockColumns);
  });

  it('dispatches rejected with wrapped error payload when API call fails', async () => {
    const apiError = new Error('Network Failure');
    mockAxiosGet.mockRejectedValue(apiError);

    const dispatch = jest.fn();
    const thunk = fetchColumnDefinitionsThunk('Orders');

    const result = await thunk(dispatch as any, jest.fn() as any, undefined);

    expect(result.type).toBe('search/fetchColumnDefinitions/rejected');
    expect(result.payload).toBeDefined();
  });
});
