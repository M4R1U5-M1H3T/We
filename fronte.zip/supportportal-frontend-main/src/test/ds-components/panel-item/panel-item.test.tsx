import { render } from '@testing-library/react';

import { PanelItem } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<PanelItem />);
    expect(container).toMatchSnapshot();
  });
});
