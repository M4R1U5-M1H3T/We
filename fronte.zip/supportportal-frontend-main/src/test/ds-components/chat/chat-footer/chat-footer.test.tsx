import { render } from '@testing-library/react';

import { ChatFooter } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<ChatFooter />);
    expect(container).toMatchSnapshot();
  });
});
