import { jest } from '@jest/globals';
import { render } from '@testing-library/react';

import { ChatMessage } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<ChatMessage />);
    expect(container).toMatchSnapshot();
  });
});

describe('Behaviour tests', () => {
  describe('On Actions tests', () => {
    it('calls onActions when the element dispatches an action event', () => {
      const onActions = jest.fn();
      const { container } = render(<ChatMessage onActions={onActions} />);
      const element = container.querySelector('ds-chat-message')!;
      element.dispatchEvent(new CustomEvent('actions'));
      expect(onActions).toHaveBeenCalledTimes(1);
    });
  });
});
