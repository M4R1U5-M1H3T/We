import { render } from '@testing-library/react';

import { ChatHeader } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<ChatHeader />);
    expect(container).toMatchSnapshot();
  });
});
