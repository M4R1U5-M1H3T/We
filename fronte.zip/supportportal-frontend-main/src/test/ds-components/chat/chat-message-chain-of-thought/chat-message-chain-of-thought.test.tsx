import { jest } from '@jest/globals';
import { render } from '@testing-library/react';

import { ChatMessageChainOfThought } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<ChatMessageChainOfThought />);
    expect(container).toMatchSnapshot();
  });
});

describe('Behaviour tests', () => {
  describe('Expand Action tests', () => {
    it('calls onExpand when the element dispatches an expand event', () => {
      const onExpand = jest.fn();
      const { container } = render(<ChatMessageChainOfThought onExpand={onExpand} />);
      const element = container.querySelector('ds-chat-message-chain-of-thought')!;
      element.dispatchEvent(new CustomEvent('expand'));
      expect(onExpand).toHaveBeenCalledTimes(1);
    });
  });

  describe('Collapse Action tests', () => {
    it('calls onCollapse when the element dispatches a collapse event', () => {
      const onCollapse = jest.fn();
      const { container } = render(<ChatMessageChainOfThought onCollapse={onCollapse} />);
      const element = container.querySelector('ds-chat-message-chain-of-thought')!;
      element.dispatchEvent(new CustomEvent('collapse'));
      expect(onCollapse).toHaveBeenCalledTimes(1);
    });
  });
});
