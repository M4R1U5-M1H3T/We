import { render } from '@testing-library/react';

import { Chat } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<Chat />);
    expect(container).toMatchSnapshot();
  });
});
