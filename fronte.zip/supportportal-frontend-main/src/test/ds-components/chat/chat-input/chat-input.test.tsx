import { jest } from '@jest/globals';
import { render } from '@testing-library/react';

import { ChatInput } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<ChatInput />);
    expect(container).toMatchSnapshot();
  });
});

describe('Behaviour tests', () => {
  describe('Send Action tests', () => {
    it('calls onSend when the element dispatches a send event', () => {
      const onSend = jest.fn();
      const { container } = render(<ChatInput onSend={onSend} />);
      const element = container.querySelector('ds-chat-input')!;
      element.dispatchEvent(new CustomEvent('send'));
      expect(onSend).toHaveBeenCalledTimes(1);
    });
  });

  describe('Stop Action tests', () => {
    it('calls onStop when the element dispatches a stop event', () => {
      const onStop = jest.fn();
      const { container } = render(<ChatInput onStop={onStop} />);
      const element = container.querySelector('ds-chat-input')!;
      element.dispatchEvent(new CustomEvent('stop'));
      expect(onStop).toHaveBeenCalledTimes(1);
    });
  });
});
