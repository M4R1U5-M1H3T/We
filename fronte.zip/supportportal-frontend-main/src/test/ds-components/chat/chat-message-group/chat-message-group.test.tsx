import { render } from '@testing-library/react';

import { ChatMessageGroup } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<ChatMessageGroup />);
    expect(container).toMatchSnapshot();
  });
});
