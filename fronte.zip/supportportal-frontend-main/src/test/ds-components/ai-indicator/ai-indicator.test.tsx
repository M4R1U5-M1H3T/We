import { render } from '@testing-library/react';

import { AiIndicator } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<AiIndicator />);
    expect(container).toMatchSnapshot();
  });
});
