import { render } from '@testing-library/react';

import { Icon } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<Icon />);
    expect(container).toMatchSnapshot();
  });
});
