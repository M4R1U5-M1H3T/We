import { render } from '@testing-library/react';

import { RelativeTime } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<RelativeTime />);
    expect(container).toMatchSnapshot();
  });
});
