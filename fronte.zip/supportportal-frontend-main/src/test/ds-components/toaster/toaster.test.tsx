import { render } from '@testing-library/react';

import { Toaster } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<Toaster />);
    expect(container).toMatchSnapshot();
  });
});
