import { render } from '@testing-library/react';

import { Shell } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<Shell />);
    expect(container).toMatchSnapshot();
  });
});
