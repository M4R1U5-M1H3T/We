import { jest } from '@jest/globals';
import { render } from '@testing-library/react';

import { Select } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<Select />);
    expect(container).toMatchSnapshot();
  });
});

describe('Behaviour tests', () => {
  describe('Change Action tests', () => {
    it('calls onChange when the element dispatches a change event', () => {
      const onChange = jest.fn();
      const { container } = render(<Select onChange={onChange} />);
      const element = container.querySelector('ds-select')!;
      element.dispatchEvent(new Event('change'));
      expect(onChange).toHaveBeenCalled();
    });
  });

  describe('Clear Action tests', () => {
    it('calls onClear when the element dispatches a clear event', () => {
      const onClear = jest.fn();
      const { container } = render(<Select onClear={onClear} />);
      const element = container.querySelector('ds-select')!;
      element.dispatchEvent(new Event('clear'));
      expect(onClear).toHaveBeenCalled();
    });
  });

  describe('Open Action tests', () => {
    it('calls onOpen when the element dispatches a open event', () => {
      const onOpen = jest.fn();
      const { container } = render(<Select onOpen={onOpen} />);
      const element = container.querySelector('ds-select')!;
      element.dispatchEvent(new Event('open'));
      expect(onOpen).toHaveBeenCalled();
    });
  });

  describe('Close Action tests', () => {
    it('calls onClose when the element dispatches a close event', () => {
      const onClose = jest.fn();
      const { container } = render(<Select onClose={onClose} />);
      const element = container.querySelector('ds-select')!;
      element.dispatchEvent(new Event('close'));
      expect(onClose).toHaveBeenCalled();
    });
  });
});
