import { render } from '@testing-library/react';

import { SelectOption } from '@/ds-components/select';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(
      <SelectOption value="AMER" disabled={false}>
        Americas Region
      </SelectOption>
    );
    expect(container).toMatchSnapshot();
  });
});
