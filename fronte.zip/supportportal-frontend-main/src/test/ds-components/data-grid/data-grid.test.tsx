import { render } from '@testing-library/react';

import { DataGrid } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<DataGrid />);
    expect(container).toMatchSnapshot();
  });
});
