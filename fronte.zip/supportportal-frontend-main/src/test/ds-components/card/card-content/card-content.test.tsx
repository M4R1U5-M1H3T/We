import { render } from '@testing-library/react';

import { CardContent } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<CardContent />);
    expect(container).toMatchSnapshot();
  });
});
