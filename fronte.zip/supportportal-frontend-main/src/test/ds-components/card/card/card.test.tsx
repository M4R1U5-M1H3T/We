import { render } from '@testing-library/react';

import { Card } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<Card />);
    expect(container).toMatchSnapshot();
  });
});
