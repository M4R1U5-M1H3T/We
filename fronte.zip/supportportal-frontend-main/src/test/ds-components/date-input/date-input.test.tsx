import { jest } from '@jest/globals';
import { render } from '@testing-library/react';

import { DateInput } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<DateInput />);
    expect(container).toMatchSnapshot();
  });
});

describe('Behaviour tests', () => {
  describe('Input Action tests', () => {
    it('calls onInput when the element dispatches an input event', () => {
      const onInput = jest.fn();
      const { container } = render(<DateInput onInput={onInput} />);
      const element = container.querySelector('ds-date-input')!;
      element.dispatchEvent(new Event('input'));
      expect(onInput).toHaveBeenCalled();
    });
  });

  describe('Change Action tests', () => {
    it('calls onChange when the element dispatches a change event', () => {
      const onChange = jest.fn();
      const { container } = render(<DateInput onChange={onChange} />);
      const element = container.querySelector('ds-date-input')!;
      element.dispatchEvent(new Event('change'));
      expect(onChange).toHaveBeenCalled();
    });
  });

  describe('Clear Action tests', () => {
    it('calls onClear when the element dispatches a clear event', () => {
      const onClear = jest.fn();
      const { container } = render(<DateInput onClear={onClear} />);
      const element = container.querySelector('ds-date-input')!;
      element.dispatchEvent(new Event('clear'));
      expect(onClear).toHaveBeenCalled();
    });
  });
});
