import { jest } from '@jest/globals';
import { render } from '@testing-library/react';

import { ContextMenu } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<ContextMenu />);
    expect(container).toMatchSnapshot();
  });
});

describe('Behaviour tests', () => {
  describe('Show Action tests', () => {
    it('calls onShow when the element dispatches a show event', () => {
      const onShow = jest.fn();
      const { container } = render(<ContextMenu onShow={onShow} />);
      container.querySelector('ds-context-menu')!.dispatchEvent(new Event('show'));
      expect(onShow).toHaveBeenCalled();
    });
  });

  describe('Hide Action tests', () => {
    it('calls onHide when the element dispatches a hide event', () => {
      const onHide = jest.fn();
      const { container } = render(<ContextMenu onHide={onHide} />);
      container.querySelector('ds-context-menu')!.dispatchEvent(new Event('hide'));
      expect(onHide).toHaveBeenCalled();
    });
  });

  describe('After Show Action tests', () => {
    it('calls onAfterShow when the element dispatches a after-show event', () => {
      const onAfterShow = jest.fn();
      const { container } = render(<ContextMenu onAfterShow={onAfterShow} />);
      container.querySelector('ds-context-menu')!.dispatchEvent(new Event('after-show'));
      expect(onAfterShow).toHaveBeenCalled();
    });
  });

  describe('After Hide Action tests', () => {
    it('calls onAfterHide when the element dispatches a after-hide event', () => {
      const onAfterHide = jest.fn();
      const { container } = render(<ContextMenu onAfterHide={onAfterHide} />);
      container.querySelector('ds-context-menu')!.dispatchEvent(new Event('after-hide'));
      expect(onAfterHide).toHaveBeenCalled();
    });
  });
});
