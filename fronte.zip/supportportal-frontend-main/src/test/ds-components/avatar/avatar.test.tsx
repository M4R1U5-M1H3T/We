import { render } from '@testing-library/react';

import { Avatar } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<Avatar />);
    expect(container).toMatchSnapshot();
  });
});
