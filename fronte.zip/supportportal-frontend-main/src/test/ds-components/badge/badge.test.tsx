import { render } from '@testing-library/react';

import { Badge } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<Badge />);
    expect(container).toMatchSnapshot();
  });
});
