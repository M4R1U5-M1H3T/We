import { render } from '@testing-library/react';

import { ShellHeader } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<ShellHeader />);
    expect(container).toMatchSnapshot();
  });
});
