import { render } from '@testing-library/react';

import { GridLayout } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<GridLayout />);
    expect(container).toMatchSnapshot();
  });
});
