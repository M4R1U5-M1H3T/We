import { render } from '@testing-library/react';

import { Form } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<Form />);
    expect(container).toMatchSnapshot();
  });
});
