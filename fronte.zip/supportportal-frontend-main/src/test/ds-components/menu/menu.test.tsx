import { render } from '@testing-library/react';

import { Menu } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<Menu />);
    expect(container).toMatchSnapshot();
  });
});
