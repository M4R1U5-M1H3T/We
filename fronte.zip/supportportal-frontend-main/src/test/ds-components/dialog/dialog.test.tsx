import { jest } from '@jest/globals';
import { render } from '@testing-library/react';

import { Dialog } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<Dialog />);
    expect(container).toMatchSnapshot();
  });
});

describe('Behaviour tests', () => {
  describe('Show Action tests', () => {
    it('calls onShow when the element dispatches a show event', () => {
      const onShow = jest.fn();
      const { container } = render(<Dialog onShow={onShow} />);
      const element = container.querySelector('ds-dialog')!;
      element.dispatchEvent(new CustomEvent('show'));
      expect(onShow).toHaveBeenCalled();
    });
  });

  describe('After Show Action tests', () => {
    it('calls onAfterShow when the element dispatches an after-show event', () => {
      const onAfterShow = jest.fn();
      const { container } = render(<Dialog onAfterShow={onAfterShow} />);
      const element = container.querySelector('ds-dialog')!;
      element.dispatchEvent(new CustomEvent('after-show'));
      expect(onAfterShow).toHaveBeenCalled();
    });
  });

  describe('Hide Action tests', () => {
    it('calls onHide when the element dispatches a hide event', () => {
      const onHide = jest.fn();
      const { container } = render(<Dialog onHide={onHide} />);
      const element = container.querySelector('ds-dialog')!;
      element.dispatchEvent(new CustomEvent('hide'));
      expect(onHide).toHaveBeenCalled();
    });
  });

  describe('After Hide Action tests', () => {
    it('calls onAfterHide when the element dispatches an after-hide event', () => {
      const onAfterHide = jest.fn();
      const { container } = render(<Dialog onAfterHide={onAfterHide} />);
      const element = container.querySelector('ds-dialog')!;
      element.dispatchEvent(new CustomEvent('after-hide'));
      expect(onAfterHide).toHaveBeenCalled();
    });
  });
});
