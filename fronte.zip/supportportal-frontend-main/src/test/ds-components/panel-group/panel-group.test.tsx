import { render } from '@testing-library/react';

import { PanelGroup } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<PanelGroup />);
    expect(container).toMatchSnapshot();
  });
});
