import { render } from '@testing-library/react';

import { Logo } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<Logo />);
    expect(container).toMatchSnapshot();
  });
});
