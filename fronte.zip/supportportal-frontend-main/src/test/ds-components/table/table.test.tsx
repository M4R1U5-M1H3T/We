import { render } from '@testing-library/react';

import { Table } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<Table />);
    expect(container).toMatchSnapshot();
  });
});
