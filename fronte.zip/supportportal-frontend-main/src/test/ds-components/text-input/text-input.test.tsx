import { render } from '@testing-library/react';

import { TextInput } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<TextInput />);
    expect(container).toMatchSnapshot();
  });
});
