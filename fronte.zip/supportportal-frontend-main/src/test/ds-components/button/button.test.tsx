import { jest } from '@jest/globals';
import { render } from '@testing-library/react';

import { Button } from '@/ds-components';

describe('Snapshot tests', () => {
  it('matches snapshot', () => {
    const { container } = render(<Button />);
    expect(container).toMatchSnapshot();
  });
});

describe('Behaviour tests', () => {
  describe('Click Action tests', () => {
    it('calls onClick when the element dispatches a click event', () => {
      const onClick = jest.fn();
      const { container } = render(<Button onClick={onClick} />);
      const element = container.querySelector('ds-button')!;
      element.click();
      expect(onClick).toHaveBeenCalled();
    });
  });
});
