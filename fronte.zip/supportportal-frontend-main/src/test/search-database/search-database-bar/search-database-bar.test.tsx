import '@testing-library/jest-dom';

import { jest } from '@jest/globals';
import { configureStore } from '@reduxjs/toolkit';
import { act, render, screen } from '@testing-library/react';
import { Provider } from 'react-redux';

import { SearchDatabaseBar } from '@/features';
import { databaseDatasetsReducer, filtersReducer, searchDatabaseReducer } from '@/slices';
import type { RootState } from '@/store/store';

const buildStore = (preloadedState?: Partial<RootState>) =>
  configureStore<RootState>({
    reducer: { search: searchDatabaseReducer, datasets: databaseDatasetsReducer, filters: filtersReducer },
    preloadedState: preloadedState as any,
  });

const renderBar = (
  onSearch: (value: string) => void,
  status: 'idle' | 'loading' | 'success' | 'failed' = 'idle',
  datasets: string[] = ['Orders', 'Customers']
) => {
  const store = buildStore({ datasets: { items: datasets, status: 'success', error: null } });

  return {
    store,
    ...render(
      <Provider store={store}>
        <SearchDatabaseBar onSearch={onSearch} status={status} />
      </Provider>
    ),
  };
};

describe('Snapshot tests', () => {
  it('matches snapshot in idle state', () => {
    const { container } = renderBar(jest.fn());
    expect(container).toMatchSnapshot();
  });

  it('matches snapshot in loading state', () => {
    const { container } = renderBar(jest.fn(), 'loading');
    expect(container).toMatchSnapshot();
  });
});

describe('Behaviour tests', () => {
  it('renders an option for each dataset', () => {
    renderBar(jest.fn(), 'idle', ['Orders', 'Customers']);

    expect(screen.getByText('Orders')).toBeInTheDocument();
    expect(screen.getByText('Customers')).toBeInTheDocument();
  });

  it('calls onSearch with the default dataset when the search button is clicked', () => {
    const onSearch = jest.fn();
    const { container } = renderBar(onSearch);

    const button = container.querySelector('ds-button')!;
    button.dispatchEvent(new Event('click', { bubbles: true }));

    expect(onSearch).toHaveBeenCalledWith('orders', {});
  });

  it('calls onSearch with the newly selected dataset after changing the select', () => {
    const onSearch = jest.fn();
    const { container } = renderBar(onSearch, 'idle', ['Orders', 'Customers']);

    const select = container.querySelector('ds-select') as any;

    act(() => {
      select.value = 'customers';
      select.dispatchEvent(new Event('change', { bubbles: true }));
    });

    const button = container.querySelector('ds-button')!;
    button.dispatchEvent(new Event('click', { bubbles: true }));

    expect(onSearch).toHaveBeenCalledWith('customers', {});
  });

  it('dispatches searchReset when the selected dataset changes', () => {
    const { container, store } = renderBar(jest.fn());

    // Seed a non-idle search state so we can observe it being reset.
    store.dispatch({ type: 'search/fetchColumnDefinitions/rejected', error: { message: 'boom' } });

    const select = container.querySelector('ds-select') as any;

    act(() => {
      select.value = 'customers';
      select.dispatchEvent(new Event('change', { bubbles: true }));
    });

    expect(store.getState().search.columnsStatus).toBe('idle');
    expect(store.getState().search.columnsError).toBeNull();
  });

  it('disables the button and shows the loading label while loading', () => {
    const { container, getByText } = renderBar(jest.fn(), 'loading');

    const button = container.querySelector('ds-button') as any;
    expect(button.disabled).toBe(true);
    expect(getByText('Searching...')).toBeInTheDocument();
  });
});
