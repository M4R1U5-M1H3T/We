import { useEffect, useState } from 'react';

import type { FilterConfig } from './types';

export const useDynamicForm = (
  config: FilterConfig | null,
  onFiltersChange?: (values: Record<string, string>, isValid: boolean) => void
) => {
  const filters = config?.filters ?? {};
  const defaultFilters =
    config?.defaultFilters ?? Object.keys(filters).filter(filterKey => filters[filterKey]?.required);

  const [selectedValues, setSelectedValues] = useState<Record<string, string>>({});
  const [visibleFilters, setVisibleFilters] = useState<string[]>([]);
  const [addFilterKey, setAddFilterKey] = useState('');
  const [initializedConfig, setInitializedConfig] = useState<typeof config>(null);

  if (config !== initializedConfig) {
    setInitializedConfig(config);
    setVisibleFilters(config ? defaultFilters.filter(filterKey => filters[filterKey]?.required) : []);
    setSelectedValues({});
  }

  const handleChange = (filterKey: string, value: string) => {
    setSelectedValues(prev => ({ ...prev, [filterKey]: value }));
  };

  const handleAddFilter = (filterKey: string) => {
    if (!filterKey || visibleFilters.includes(filterKey)) {
      return;
    }

    setVisibleFilters(prev => [...prev, filterKey]);
    setAddFilterKey('');
  };

  const handleRemoveFilter = (filterKey: string) => {
    if (filters[filterKey]?.required) {
      return;
    }

    setVisibleFilters(prev => prev.filter(key => key !== filterKey));
    setSelectedValues(prev => {
      const next = { ...prev };
      delete next[filterKey];

      return next;
    });
  };

  const isValid = visibleFilters.every(filterKey => {
    const filterItem = filters[filterKey];

    if (!filterItem?.required) {
      return true;
    }

    return Boolean(selectedValues[filterKey]);
  });

  useEffect(() => {
    onFiltersChange?.(selectedValues, isValid);
  }, [selectedValues, isValid]);

  return {
    filters,
    defaultFilters,
    allFilterKeys: Object.keys(filters),
    visibleFilters,
    selectedValues,
    addFilterKey,
    handleChange,
    handleAddFilter,
    handleRemoveFilter,
    isValid,
  };
};
