import { TextInput } from '@/ds-components';

export interface TextInputFieldProps {
  value?: string;
  placeholder?: string;
  multiple?: boolean;
  onChange?: (value: string) => void;
}

export const TextInputField = ({ value, placeholder, onChange }: TextInputFieldProps) => {
  const handleChange = (event: Event) => {
    const target = event.target as HTMLElement & { value: string };
    onChange?.(target.value);
  };

  return <TextInput value={value ?? ''} placeholder={placeholder} onChange={handleChange} />;
};
