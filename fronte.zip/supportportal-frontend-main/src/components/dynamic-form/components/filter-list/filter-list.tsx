import type { FilterDefinition } from '@/components';
import { FilterField } from '@/components/dynamic-form/components/filter-list/filter-field';

export interface FilterListProps {
  filters: Record<string, FilterDefinition>;
  visibleFilters: string[];
  selectedValues: Record<string, string>;
  onChange: (filterKey: string, value: string) => void;
  onRemove: (filterKey: string) => void;
}

export const FilterList = ({ filters, visibleFilters, selectedValues, onChange, onRemove }: FilterListProps) => (
  <>
    {visibleFilters.map(filterKey => {
      const filterItem = filters[filterKey];

      if (!filterItem) {
        return null;
      }

      return (
        <FilterField
          key={filterKey}
          filterKey={filterKey}
          filterItem={filterItem}
          value={selectedValues[filterKey]}
          onChange={onChange}
          onRemove={onRemove}
        />
      );
    })}
  </>
);
