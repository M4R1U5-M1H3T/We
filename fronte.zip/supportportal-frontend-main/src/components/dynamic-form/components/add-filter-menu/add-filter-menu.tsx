import './add-filter-menu.css';

import type { FilterDefinition } from '@/components';
import { DropdownField } from '@/components/dynamic-form/components';
import { Button, Icon } from '@/ds-components';

export interface AddFilterMenuProps {
  filters: Record<string, FilterDefinition>;
  allFilterKeys: string[];
  pendingDefaultFilters: string[];
  addFilterKey: string;
  onAddFilter: (filterKey: string) => void;
}

export const AddFilterMenu = ({
  filters,
  allFilterKeys,
  pendingDefaultFilters,
  addFilterKey,
  onAddFilter,
}: AddFilterMenuProps) => (
  <div className="add-filter-menu">
    <DropdownField
      data={allFilterKeys.map(key => ({ label: filters[key]?.title ?? key, value: key }))}
      value={addFilterKey}
      placeholder="Add Filter"
      icon="action_filter_alt"
      onChange={onAddFilter}
    />

    <div className="quick-filters">
      {pendingDefaultFilters.map(filterKey => (
        <Button key={filterKey} onClick={() => onAddFilter(filterKey)}>
          <Icon slot="start" name="action_add" />
          {filters[filterKey]?.title ?? filterKey}
        </Button>
      ))}
    </div>
  </div>
);
