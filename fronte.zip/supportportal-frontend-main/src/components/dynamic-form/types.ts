export interface FilterOption {
  label: string;
  value: string;
  selected: boolean;
}

export interface FilterDefinition {
  title: string;
  type: string;
  required: boolean;
  data: FilterOption[];
  props: {
    placeholder: string;
    multiple?: boolean;
  };
}

export interface FilterConfig {
  defaultFilters: string[];
  filters: Record<string, FilterDefinition>;
}
