import './index.css';

import { DataGrid } from '@/ds-components';
import type { SearchResults } from '@/features';

type ResultsTableProps = {
  results: SearchResults;
};

export const ResultsTable = ({ results }: ResultsTableProps) => {
  const COLUMN_MIN_WIDTH = 150;

  const columnDefs = results.columns.map(column => ({
    field: column.name,
    headerName: column.displayName,
    minWidth: COLUMN_MIN_WIDTH,
  }));

  return (
    <div className="table">
      <h1>Results</h1>
      <DataGrid columnDefs={columnDefs} rowData={results.rows} />
    </div>
  );
};
