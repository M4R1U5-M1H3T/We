import { configureStore } from '@reduxjs/toolkit';

import { databaseDatasetsReducer, filtersReducer, searchDatabaseReducer } from '@/slices';

export const store = configureStore({
  reducer: {
    filters: filtersReducer,
    search: searchDatabaseReducer,
    datasets: databaseDatasetsReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
