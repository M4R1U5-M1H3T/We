import { createComponent } from '@lit/react';
import { PanelGroup as DSPanelGroup } from '@lseg-workspace/components/panel-group';
import * as React from 'react';

export const PanelGroup = createComponent({
  react: React,
  tagName: 'ds-panel-group',
  elementClass: DSPanelGroup,
});
