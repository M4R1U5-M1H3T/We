import { createComponent } from '@lit/react';
import { Avatar as DSAvatar } from '@lseg-workspace/components/avatar';
import * as React from 'react';

export const Avatar = createComponent({
  react: React,
  tagName: 'ds-avatar',
  elementClass: DSAvatar,
});
