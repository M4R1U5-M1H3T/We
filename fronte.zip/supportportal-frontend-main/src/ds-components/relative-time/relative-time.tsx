import { createComponent } from '@lit/react';
import { RelativeTime as DSRelativeTime } from '@lseg-workspace/components/relative-time';
import * as React from 'react';

export const RelativeTime = createComponent({
  react: React,
  tagName: 'ds-relative-time',
  elementClass: DSRelativeTime,
});
