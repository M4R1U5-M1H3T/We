import { createComponent } from '@lit/react';
import { Badge as DSBadge } from '@lseg-workspace/components/badge';
import * as React from 'react';

export const Badge = createComponent({
  react: React,
  tagName: 'ds-badge',
  elementClass: DSBadge,
});
