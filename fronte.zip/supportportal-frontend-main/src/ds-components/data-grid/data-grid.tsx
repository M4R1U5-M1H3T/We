import { createComponent } from '@lit/react';
import { DataGrid as DSDataGrid } from '@lseg-workspace/components/data-grid';
import * as React from 'react';

export const DataGrid = createComponent({
  react: React,
  tagName: 'ds-data-grid',
  elementClass: DSDataGrid,
});
