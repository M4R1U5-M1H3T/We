import { createComponent } from '@lit/react';
import { Button as DSButton } from '@lseg-workspace/components/button';
import * as React from 'react';

export const Button = createComponent({
  react: React,
  tagName: 'ds-button',
  elementClass: DSButton,
  events: {
    onClick: 'click',
  },
});
