import { createComponent } from '@lit/react';
import { AiIndicator as DSAiIndicator } from '@lseg-workspace/components/ai-indicator';
import * as React from 'react';

export const AiIndicator = createComponent({
  react: React,
  tagName: 'ds-ai-indicator',
  elementClass: DSAiIndicator,
});
