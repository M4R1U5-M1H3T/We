import { createComponent } from '@lit/react';
import { Select as DSSelect } from '@lseg-workspace/components/select';
import * as React from 'react';

export const Select = createComponent({
  react: React,
  tagName: 'ds-select',
  elementClass: DSSelect,
  events: {
    onChange: 'change',
    onClear: 'clear',
    onOpen: 'open',
    onClose: 'close',
  },
});
