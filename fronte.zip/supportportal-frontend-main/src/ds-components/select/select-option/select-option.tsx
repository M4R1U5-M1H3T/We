import { createComponent } from '@lit/react';
import { SelectOption as DSSelectOption } from '@lseg-workspace/components/select';
import * as React from 'react';

export const SelectOption = createComponent({
  react: React,
  tagName: 'ds-option',
  elementClass: DSSelectOption,
});
