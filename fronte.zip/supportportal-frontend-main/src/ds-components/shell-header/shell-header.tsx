import { createComponent } from '@lit/react';
import { ShellHeader as DSShellHeader } from '@lseg-workspace/components/shell-header';
import * as React from 'react';

export const ShellHeader = createComponent({
  react: React,
  tagName: 'ds-shell-header',
  elementClass: DSShellHeader,
});
