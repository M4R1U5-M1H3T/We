import { createComponent } from '@lit/react';
import { Toaster as DSToaster } from '@lseg-workspace/components/toaster';
import * as React from 'react';

export const Toaster = createComponent({
  react: React,
  tagName: 'ds-toaster',
  elementClass: DSToaster,
});
