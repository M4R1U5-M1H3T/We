import { createComponent } from '@lit/react';
import { ChatMessageChainOfThought as DSChatMessageChainOfThought } from '@lseg-workspace/components/chat';
import * as React from 'react';

export const ChatMessageChainOfThought = createComponent({
  react: React,
  tagName: 'ds-chat-message-chain-of-thought',
  elementClass: DSChatMessageChainOfThought,
  events: {
    onExpand: 'expand',
    onCollapse: 'collapse',
  },
});
