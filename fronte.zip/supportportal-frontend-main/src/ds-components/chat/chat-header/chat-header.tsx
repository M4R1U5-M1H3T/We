import { createComponent } from '@lit/react';
import { ChatHeader as DSChatHeader } from '@lseg-workspace/components/chat';
import * as React from 'react';

export const ChatHeader = createComponent({
  react: React,
  tagName: 'ds-chat-header',
  elementClass: DSChatHeader,
});
