import { createComponent } from '@lit/react';
import { ChatMessageGroup as DSChatMessageGroup } from '@lseg-workspace/components/chat';
import * as React from 'react';

export const ChatMessageGroup = createComponent({
  react: React,
  tagName: 'ds-chat-message-group',
  elementClass: DSChatMessageGroup,
});
