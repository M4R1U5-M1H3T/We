import { createComponent } from '@lit/react';
import { ChatMessage as DSChatMessage } from '@lseg-workspace/components/chat';
import * as React from 'react';

export const ChatMessage = createComponent({
  react: React,
  tagName: 'ds-chat-message',
  elementClass: DSChatMessage,
  events: {
    onActions: 'actions',
  },
});
