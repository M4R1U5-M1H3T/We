import { createComponent } from '@lit/react';
import { ChatInput as DSChatInput } from '@lseg-workspace/components/chat';
import * as React from 'react';

export const ChatInput = createComponent({
  react: React,
  tagName: 'ds-chat-input',
  elementClass: DSChatInput,
  events: {
    onSend: 'send',
    onStop: 'stop',
  },
});
