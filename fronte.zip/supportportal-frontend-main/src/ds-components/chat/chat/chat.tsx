import { createComponent } from '@lit/react';
import { Chat as DSChat } from '@lseg-workspace/components/chat';
import * as React from 'react';

export const Chat = createComponent({
  react: React,
  tagName: 'ds-chat',
  elementClass: DSChat,
});
