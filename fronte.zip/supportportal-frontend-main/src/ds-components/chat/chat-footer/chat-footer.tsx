import { createComponent } from '@lit/react';
import { ChatFooter as DSChatFooter } from '@lseg-workspace/components/chat';
import * as React from 'react';

export const ChatFooter = createComponent({
  react: React,
  tagName: 'ds-chat-footer',
  elementClass: DSChatFooter,
});
