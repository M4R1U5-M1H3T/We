import { createComponent } from '@lit/react';
import { Form as DSForm } from '@lseg-workspace/components/form';
import * as React from 'react';

export const Form = createComponent({
  react: React,
  tagName: 'ds-form',
  elementClass: DSForm,
});
