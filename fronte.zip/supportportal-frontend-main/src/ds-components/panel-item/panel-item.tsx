import { createComponent } from '@lit/react';
import { PanelItem as DSPanelItem } from '@lseg-workspace/components/panel-item';
import * as React from 'react';

export const PanelItem = createComponent({
  react: React,
  tagName: 'ds-panel-item',
  elementClass: DSPanelItem,
});
