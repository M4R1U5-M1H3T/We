import { createComponent } from '@lit/react';
import { GridLayout as DSGridLayout } from '@lseg-workspace/components/grid-layout';
import * as React from 'react';

export const GridLayout = createComponent({
  react: React,
  tagName: 'ds-grid-layout',
  elementClass: DSGridLayout,
});
