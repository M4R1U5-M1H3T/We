import { createComponent } from '@lit/react';
import { Dialog as DSDialog } from '@lseg-workspace/components/dialog';
import * as React from 'react';

export const Dialog = createComponent({
  react: React,
  tagName: 'ds-dialog',
  elementClass: DSDialog,
  events: {
    onShow: 'show',
    onAfterShow: 'after-show',
    onHide: 'hide',
    onAfterHide: 'after-hide',
  },
});
