import { createComponent } from '@lit/react';
import { Menu as DSMenu } from '@lseg-workspace/components/menu';
import * as React from 'react';

export const Menu = createComponent({
  react: React,
  tagName: 'ds-menu',
  elementClass: DSMenu,
});
