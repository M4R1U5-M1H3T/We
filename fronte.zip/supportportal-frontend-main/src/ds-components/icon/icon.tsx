import { createComponent } from '@lit/react';
import { Icon as DSIcon } from '@lseg-workspace/components/icon';
import * as React from 'react';

export const Icon = createComponent({
  react: React,
  tagName: 'ds-icon',
  elementClass: DSIcon,
});
