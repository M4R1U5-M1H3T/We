import { createComponent } from '@lit/react';
import { Logo as DSLogo } from '@lseg-workspace/components/logo';
import * as React from 'react';

export const Logo = createComponent({
  react: React,
  tagName: 'ds-logo',
  elementClass: DSLogo,
});
