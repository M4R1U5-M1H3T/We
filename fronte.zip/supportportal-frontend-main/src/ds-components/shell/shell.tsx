import { createComponent } from '@lit/react';
import { Shell as DSShell } from '@lseg-workspace/components/shell';
import * as React from 'react';

export const Shell = createComponent({
  react: React,
  tagName: 'ds-shell',
  elementClass: DSShell,
});
