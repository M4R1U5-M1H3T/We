import { createComponent } from '@lit/react';
import { TextInput as DSTextInput } from '@lseg-workspace/components/text-input';
import * as React from 'react';

type TextInputElement = Omit<DSTextInput, 'autocorrect'> & { autocorrect: boolean };

export const TextInput = createComponent({
  react: React,
  tagName: 'ds-text-input',
  elementClass: DSTextInput as unknown as { new (): TextInputElement },
  events: {
    onInput: 'input',
    onChange: 'change',
    onBlur: 'blur',
    onFocus: 'focus',
    onInvalid: 'invalid',
  },
});
