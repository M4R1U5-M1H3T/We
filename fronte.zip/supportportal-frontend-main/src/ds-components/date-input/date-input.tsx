import { createComponent } from '@lit/react';
import { DateInput as DSDateInput } from '@lseg-workspace/components/date-input';
import * as React from 'react';

export const DateInput = createComponent({
  react: React,
  tagName: 'ds-date-input',
  elementClass: DSDateInput,
  events: {
    onInput: 'input',
    onChange: 'change',
    onClear: 'clear',
  },
});
