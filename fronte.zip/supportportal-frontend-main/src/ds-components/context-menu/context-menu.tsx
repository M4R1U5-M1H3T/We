import { createComponent } from '@lit/react';
import { ContextMenu as DSContextMenu } from '@lseg-workspace/components/context-menu';
import * as React from 'react';

export const ContextMenu = createComponent({
  react: React,
  tagName: 'ds-context-menu',
  elementClass: DSContextMenu,
  events: {
    onShow: 'show',
    onHide: 'hide',
    onAfterShow: 'after-show',
    onAfterHide: 'after-hide',
  },
});
