import { createComponent } from '@lit/react';
import { Table as DSTable } from '@lseg-workspace/components/table';
import * as React from 'react';

export const Table = createComponent({
  react: React,
  tagName: 'ds-table',
  elementClass: DSTable,
});
