import { createComponent } from '@lit/react';
import { Divider as DSDivider } from '@lseg-workspace/components/divider';
import * as React from 'react';

export const Divider = createComponent({
  react: React,
  tagName: 'ds-divider',
  elementClass: DSDivider,
});
