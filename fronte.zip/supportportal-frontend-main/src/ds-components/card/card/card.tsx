import { createComponent } from '@lit/react';
import { Card as DSCard } from '@lseg-workspace/components/card';
import * as React from 'react';

export const Card = createComponent({
  react: React,
  tagName: 'ds-card',
  elementClass: DSCard,
});
