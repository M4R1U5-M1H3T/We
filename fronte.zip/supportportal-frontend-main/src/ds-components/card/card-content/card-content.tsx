import { createComponent } from '@lit/react';
import { CardContent as DSCardContent } from '@lseg-workspace/components/card';
import * as React from 'react';

export const CardContent = createComponent({
  react: React,
  tagName: 'ds-card-content',
  elementClass: DSCardContent,
});
