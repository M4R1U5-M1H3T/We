import { createSlice } from '@reduxjs/toolkit';

import type { SearchResults } from '@/features';
import { fetchColumnDefinitionsThunk, fetchSearchResultsThunk } from '@/slices/thunks';
import type { RootState } from '@/store/store';

type SearchStatus = 'idle' | 'loading' | 'success' | 'failed';

type SearchPageState = {
  searchType: string | null;
  results: SearchResults;
  selectedDataset: string | null;
  columnsStatus: SearchStatus;
  rowsStatus: SearchStatus;
  columnsError: string | null;
  rowsError: string | null;
};

const initialState: SearchPageState = {
  searchType: null,
  results: {
    columns: [],
    rows: [],
  },
  selectedDataset: null,
  columnsStatus: 'idle',
  rowsStatus: 'idle',
  columnsError: null,
  rowsError: null,
};

export const searchDatabaseSlice = createSlice({
  name: 'search',
  initialState,
  reducers: {
    searchReset: state => {
      state.columnsStatus = 'idle';
      state.rowsStatus = 'idle';
      state.columnsError = null;
      state.rowsError = null;
      state.results = {
        columns: [],
        rows: [],
      };
    },
  },
  extraReducers: builder => {
    builder
      .addCase(fetchColumnDefinitionsThunk.pending, (state, action) => {
        state.columnsStatus = 'loading';
        state.searchType = action.meta.arg;
      })
      .addCase(fetchColumnDefinitionsThunk.fulfilled, (state, action) => {
        state.columnsStatus = 'success';
        state.results.columns = action.payload;
        state.selectedDataset = action.meta.arg;
      })
      .addCase(fetchColumnDefinitionsThunk.rejected, (state, action) => {
        state.columnsStatus = 'failed';
        state.columnsError = action.error.message || 'Failed to fetch column definitions.';
      })
      .addCase(fetchSearchResultsThunk.pending, (state, action) => {
        state.rowsStatus = 'loading';
        state.searchType = action.meta.arg;
      })
      .addCase(fetchSearchResultsThunk.fulfilled, (state, action) => {
        state.rowsStatus = 'success';
        state.results.rows = action.payload;
        state.selectedDataset = action.meta.arg;
      })
      .addCase(fetchSearchResultsThunk.rejected, (state, action) => {
        state.rowsStatus = 'failed';
        state.rowsError = action.error.message || 'Failed to fetch search results.';
      });
  },
});

export const searchDatabaseReducer = searchDatabaseSlice.reducer;
export const { searchReset } = searchDatabaseSlice.actions;

export const selectSearchType = (state: RootState) => state.search.searchType;
export const selectSearchResults = (state: RootState) => state.search.results;
export const selectSelectedDataset = (state: RootState) => state.search.selectedDataset;
export const selectColumnsStatus = (state: RootState) => state.search.columnsStatus;
export const selectColumnsError = (state: RootState) => state.search.columnsError;
export const selectRowsStatus = (state: RootState) => state.search.rowsStatus;
export const selectRowsError = (state: RootState) => state.search.rowsError;

export const selectSearchPageStatus = (state: RootState): SearchStatus => {
  const { columnsStatus, rowsStatus } = state.search;

  if (columnsStatus === 'failed' || rowsStatus === 'failed') {
    return 'failed';
  }

  if (columnsStatus === 'loading' || rowsStatus === 'loading') {
    return 'loading';
  }

  if (columnsStatus === 'success' && rowsStatus === 'success') {
    return 'success';
  }

  return 'idle';
};
