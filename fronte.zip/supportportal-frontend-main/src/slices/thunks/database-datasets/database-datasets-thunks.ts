import axios from 'axios';

import { handleThunkError } from '@/slices/thunks/error-utils';
import { createAppAsyncThunkWithErrorPayload } from '@/store/hooks';

export const fetchDatasetsThunk = createAppAsyncThunkWithErrorPayload<string[], void>(
  'datasets/fetchDatasets',
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get<string[]>(`/api/database/datasets`);

      return response.data;
    } catch (error) {
      return rejectWithValue(handleThunkError(error));
    }
  }
);
