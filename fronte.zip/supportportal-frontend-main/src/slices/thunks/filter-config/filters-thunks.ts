import axios from 'axios';

import type { FilterConfig } from '@/components/dynamic-form';
import { createAppAsyncThunk } from '@/store/hooks';

export const fetchFilterConfig = createAppAsyncThunk('filters/fetchConfig', async (dataset: string, thunkAPI) => {
  try {
    const response = await axios.get<FilterConfig>(`/api/database/filters/${dataset}`).then(res => res.data);

    return response;
  } catch (error: any) {
    const message = error?.response?.data?.error || error?.message || 'An error occurred while fetching filter config.';

    return thunkAPI.rejectWithValue(message);
  }
});
