import axios from 'axios';

import type { ColumnDefinition, SearchRow } from '@/features';
import { handleThunkError } from '@/slices';
import { createAppAsyncThunkWithErrorPayload } from '@/store/hooks';

export const fetchColumnDefinitionsThunk = createAppAsyncThunkWithErrorPayload<ColumnDefinition[], string>(
  'search/fetchColumnDefinitions',
  async (dataset, { rejectWithValue }) => {
    const normalizedDataset = dataset.toLowerCase();

    try {
      const response = await axios.get<ColumnDefinition[]>(`/api/database/${normalizedDataset}/columns`);

      return response.data;
    } catch (error) {
      return rejectWithValue(handleThunkError(error));
    }
  }
);

export const fetchSearchResultsThunk = createAppAsyncThunkWithErrorPayload<SearchRow[], string>(
  'search/fetchSearchResults',
  async (dataset, { rejectWithValue }) => {
    const normalizedDataset = dataset.toLowerCase();

    try {
      const response = await axios.get<SearchRow[]>(`/api/database/${normalizedDataset}`);

      return response.data;
    } catch (error) {
      return rejectWithValue(handleThunkError(error));
    }
  }
);
