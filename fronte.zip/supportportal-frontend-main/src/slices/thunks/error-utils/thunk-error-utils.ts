import axios from 'axios';
import { StatusCodes } from 'http-status-codes';

import type { ApiErrorPayload } from '@/store/hooks';

export const handleThunkError = (error: unknown): ApiErrorPayload => {
  if (axios.isAxiosError(error)) {
    const message: string =
      error.response?.data?.message || error.response?.data?.fieldErrors || error.message || error.toString();

    return {
      message,
      statusCode: (error.response?.status as StatusCodes) ?? StatusCodes.INTERNAL_SERVER_ERROR,
    };
  }

  return {
    message: error instanceof Error ? error.message : 'An unknown error occurred',
    statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
  };
};
