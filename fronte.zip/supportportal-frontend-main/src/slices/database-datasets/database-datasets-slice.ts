import { createSlice } from '@reduxjs/toolkit';

import { fetchDatasetsThunk } from '@/slices/thunks';
import type { RootState } from '@/store/store';

type DatasetStatus = 'idle' | 'loading' | 'success' | 'failed';

type DatasetsState = {
  items: string[];
  status: DatasetStatus;
  error: string | null;
};

const initialState: DatasetsState = {
  items: [],
  status: 'idle',
  error: null,
};

export const databaseDatasetsSlice = createSlice({
  name: 'datasets',
  initialState,
  reducers: {},
  extraReducers: builder => {
    builder
      .addCase(fetchDatasetsThunk.pending, state => {
        state.status = 'loading';
      })
      .addCase(fetchDatasetsThunk.fulfilled, (state, action) => {
        state.status = 'success';
        state.items = action.payload;
      })
      .addCase(fetchDatasetsThunk.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.payload?.message || 'Failed to fetch datasets';
      });
  },
});

export const databaseDatasetsReducer = databaseDatasetsSlice.reducer;

export const selectDatasets = (state: RootState) => state.datasets.items;
export const selectDatasetsStatus = (state: RootState) => state.datasets.status;
export const selectDatasetsError = (state: RootState) => state.datasets.error;
