import { createSlice } from '@reduxjs/toolkit';

import type { FilterConfig } from '@/components/dynamic-form';
import { fetchFilterConfig } from '@/slices/thunks/filter-config';
import type { RootState } from '@/store/store';

interface FiltersState {
  config: FilterConfig | null;
  isLoading: boolean;
  error: string | null;
}

const initialState: FiltersState = {
  config: null,
  isLoading: false,
  error: null,
};

const filtersSlice = createSlice({
  name: 'filters',
  initialState,
  reducers: {
    resetFilterConfig: state => {
      state.config = null;
      state.isLoading = false;
      state.error = null;
    },
  },
  extraReducers: builder => {
    builder
      .addCase(fetchFilterConfig.pending, state => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchFilterConfig.fulfilled, (state, action) => {
        state.isLoading = false;
        state.config = action.payload;
      })
      .addCase(fetchFilterConfig.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message ?? 'Failed to load filters';
      });
  },
});

export const filtersReducer = filtersSlice.reducer;
export const { resetFilterConfig } = filtersSlice.actions;

export const selectFiltersConfig = (state: RootState) => state.filters.config;
export const selectFiltersIsLoading = (state: RootState) => state.filters.isLoading;
export const selectFiltersError = (state: RootState) => state.filters.error;
