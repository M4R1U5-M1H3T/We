import { useParams, useSearchParams } from 'react-router-dom';

export const TrackOrderPage = () => {
  const { region } = useParams<{ region?: string }>();
  const [searchParams] = useSearchParams();
  const parentId = searchParams.get('parent_id');

  return (
    <div>
      Track Order Page{region ? ` - Region: ${region}` : ''}
      {parentId ? ` - Parent_id: ${parentId}` : ''}
    </div>
  );
};
