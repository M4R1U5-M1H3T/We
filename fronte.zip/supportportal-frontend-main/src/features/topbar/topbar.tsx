import './index.css';

import { useLocation, useNavigate } from 'react-router-dom';

import { Avatar, Badge, Button, Divider, Icon, ShellHeader } from '@/ds-components';

const SUB_PAGE_NAMES: Record<string, string> = {
  '/tora-oems/search': 'Search',
  '/tora-oems/track-order': 'Track Order',
  '/tora-oems/ai-chat': 'AI Chat',
};

export const TopBar = () => {
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const subPageName = SUB_PAGE_NAMES[pathname];

  return (
    <ShellHeader>
      <div slot="logo" className="topbar-logo">
        <img src="lseg-tora-logo.svg" alt="LSEG Tora Logo" />
      </div>

      <div slot="logo" className="topbar-navigation">
        <span
          className={`topbar-navigation-oems${subPageName ? '--muted' : ''}`}
          onClick={() => navigate('/tora-oems')}
        >
          OEMS Support
        </span>
        {subPageName && (
          <>
            <Icon slot="icon-only" name="nav_chevron_forward" className="topbar-navigation-chevron" />
            <span className="topbar-navigation-subpage">{subPageName}</span>
          </>
        )}
      </div>

      <div slot="contextual-actions" className="topbar-actions">
        <Button sentiment="primary" tooltip="AI Chat" onClick={() => navigate('/tora-oems/ai-chat')}>
          <Icon slot="icon-only" name="app_ai_insights" />
        </Button>
        <Divider orientation="vertical" />
        <Badge sentiment="negative" emphasis="moderate" size="sm">
          Connected to Production
        </Badge>
      </div>

      <div slot="user-menu">
        <Avatar name="A B" size="sm" />
      </div>
    </ShellHeader>
  );
};
