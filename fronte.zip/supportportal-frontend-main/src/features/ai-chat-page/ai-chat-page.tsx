export const AIChatPage = () => <div>AIChatPage</div>;
