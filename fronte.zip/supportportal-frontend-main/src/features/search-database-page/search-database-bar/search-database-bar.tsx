import './index.css';

import { useEffect, useState } from 'react';

import { DynamicForm } from '@/components';
import { Button, Icon, Select, SelectOption } from '@/ds-components';
import {
  fetchFilterConfig,
  resetFilterConfig,
  searchReset,
  selectDatasets,
  selectFiltersConfig,
  selectSelectedDataset,
} from '@/slices';
import { useAppDispatch, useAppSelector } from '@/store/hooks';

type SearchBarProps = {
  onSearch: (searchType: string, filters?: Record<string, string>) => void;
  status: 'idle' | 'loading' | 'success' | 'failed';
};

const DEFAULT_SEARCH_TYPE: string = 'orders';

export const SearchDatabaseBar = ({ onSearch, status }: SearchBarProps) => {
  const dispatch = useAppDispatch();
  const datasets = useAppSelector(selectDatasets);
  const selectedDataset = useAppSelector(selectSelectedDataset);
  const [searchType, setSearchType] = useState<string>(selectedDataset ?? DEFAULT_SEARCH_TYPE);
  const [filterValues, setFilterValues] = useState<Record<string, string>>({});
  const [filtersValid, setFiltersValid] = useState(true);
  const isLoading = status === 'loading';
  const selectedSearchType = searchType || datasets[0]?.toLowerCase() || '';
  const filterConfig = useAppSelector(selectFiltersConfig);

  useEffect(() => {
    if (selectedSearchType) {
      dispatch(fetchFilterConfig(selectedSearchType));
    } else {
      dispatch(resetFilterConfig());
    }
  }, [dispatch, selectedSearchType]);

  const handleFiltersChange = (values: Record<string, string>, isValid: boolean) => {
    setFilterValues(values);
    setFiltersValid(isValid);
  };

  const handleSelectChange = (event: Event) => {
    const { value } = event.currentTarget as HTMLSelectElement;
    setSearchType(value);
    dispatch(searchReset());
  };

  return (
    <div className="bar">
      <div className="select-container">
        <div className="filter-field-header">Search For</div>
        <Select value={searchType} onChange={handleSelectChange}>
          {datasets.map(dataset => (
            <SelectOption key={dataset} value={dataset.toLowerCase()}>
              {dataset}
            </SelectOption>
          ))}
        </Select>
      </div>

      <DynamicForm config={filterConfig} onFiltersChange={handleFiltersChange} />

      <div className="row-break" aria-hidden="true" />

      <Button
        className="search-button"
        sentiment="primary"
        onClick={() => onSearch(selectedSearchType, filterValues)}
        disabled={isLoading || !filtersValid}
      >
        <Icon slot="start" name="search" />
        {isLoading ? 'Searching...' : 'Search'}
      </Button>

      {isLoading && <span className="loading-text">Loading...</span>}
    </div>
  );
};
