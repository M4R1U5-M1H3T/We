export type ColumnDefinition = {
  name: string;
  displayName: string;
};

export type SearchRow = Record<string, unknown>;

export type SearchResults = {
  columns: ColumnDefinition[];
  rows: SearchRow[];
};
