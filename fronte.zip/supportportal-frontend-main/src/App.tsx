import { Route, Routes } from 'react-router-dom';

import { Shell } from '@/ds-components';
import { TopBar } from '@/features';
import { AIChatPage, HomePage, SearchDatabasePage, TrackOrderPage } from '@/features';

export const App = () => (
  <Shell>
    <TopBar />
    <Routes>
      <Route path="/tora-oems" element={<HomePage />} />
      <Route path="/tora-oems/search" element={<SearchDatabasePage />} />
      <Route path="/tora-oems/track-order/:region?" element={<TrackOrderPage />} />
      <Route path="/tora-oems/ai-chat" element={<AIChatPage />} />
    </Routes>
  </Shell>
);
