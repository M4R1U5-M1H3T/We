import js from '@eslint/js';
import globals from 'globals';
import importX from 'eslint-plugin-import-x';
import reactHooks from 'eslint-plugin-react-hooks';
import reactRefresh from 'eslint-plugin-react-refresh';
import simpleImportSort from 'eslint-plugin-simple-import-sort';
import tseslint from 'typescript-eslint';
import { createTypeScriptImportResolver } from 'eslint-import-resolver-typescript';
import { defineConfig, globalIgnores } from 'eslint/config';

export default defineConfig([
  globalIgnores(['dist']),
  {
    files: ['**/*.{ts,tsx}'],
    extends: [
      js.configs.recommended,
      tseslint.configs.recommended,
      reactHooks.configs.flat.recommended,
      reactRefresh.configs.vite,
    ],
    languageOptions: {
      globals: globals.browser,
      parserOptions: {
        projectService: true,
        tsconfigRootDir: import.meta.dirname,
      },
    },
  },
  {
    files: ['**/*.{ts,tsx}'],
    settings: {
      'import-x/resolver-next': [createTypeScriptImportResolver()],
    },
    plugins: {
      'import-x': importX,
      'simple-import-sort': simpleImportSort,
    },
    rules: {
      curly: ['error', 'all'],
      'simple-import-sort/imports': ['error'],
      'simple-import-sort/exports': 'error',

      // TypeScript rules
      '@typescript-eslint/dot-notation': 'error',
      '@typescript-eslint/no-explicit-any': 'warn',
      '@typescript-eslint/no-non-null-assertion': 'warn',
      '@typescript-eslint/no-redeclare': 'error',
      '@typescript-eslint/no-shadow': 'error',
      '@typescript-eslint/no-unused-expressions': 'error',
      '@typescript-eslint/no-unused-vars': 'warn', // TODO: Fix unused vars and promote back to error
      '@typescript-eslint/no-use-before-define': 'warn',
      '@typescript-eslint/no-useless-constructor': 'error',

      // General code quality rules
      'arrow-body-style': 'error',
      'consistent-return': 'error',
      'max-lines': [
        'warn', // TODO: Refactor large files and promote back to error
        {
          max: 150,
          skipBlankLines: true,
          skipComments: true,
        },
      ],

      // Import rules
      'import-x/no-cycle': 'error',
      'import-x/no-named-as-default': 'warn', // TODO: Fix BigNumber/Grid imports and promote back to error
      'import-x/no-useless-path-segments': [
        'error',
        {
          noUselessIndex: true,
        },
      ],
      'import-x/extensions': 'off',
      'import-x/prefer-default-export': 'off',
      'import-x/no-extraneous-dependencies': 'off',
      // Code style rules
      'no-else-return': 'error',
      'no-nested-ternary': 'error',
      'no-param-reassign': [
        'warn',
        {
          props: true,
          ignorePropertyModificationsFor: ['state'],
        },
      ],
      'no-restricted-exports': 'warn',
      'no-plusplus': ['error', { allowForLoopAfterthoughts: true }],
      'no-restricted-syntax': 'off',
      'no-return-assign': 'error',
      'no-undef-init': 'error',
      'no-unneeded-ternary': 'error',
      'no-unsafe-optional-chaining': 'error',
      'object-shorthand': 'error',
      'no-useless-rename': 'warn',
      'no-constant-condition': ['error', { checkLoops: false }],
      'no-await-in-loop': 'off',
      'padding-line-between-statements': [
        'error',
        { blankLine: 'always', prev: '*', next: 'return' },
        { blankLine: 'always', prev: '*', next: 'if' },
        { blankLine: 'always', prev: 'if', next: '*' },
      ],
      'prefer-arrow-callback': 'error',
      'prefer-const': 'error',
      'prefer-destructuring': 'error',
      'prefer-template': 'error',
      'spaced-comment': 'error',

      // React hooks rules
      'react-hooks/exhaustive-deps': 'warn',
      'react-hooks/rules-of-hooks': 'error',
    },
  },
]);
