package com.lseg.supportportal.backend.tools.searchdatabase.executions.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.test.util.ReflectionTestUtils;

import com.lseg.supportportal.backend.core.search.config.SearchProperties;
import com.lseg.supportportal.backend.core.search.domain.SearchCriteria;
import com.lseg.supportportal.backend.core.search.domain.SearchOperator;
import com.lseg.supportportal.backend.core.search.domain.SearchRequest;
import com.lseg.supportportal.backend.tools.searchdatabase.executions.domain.Execution;
import com.lseg.supportportal.backend.tools.searchdatabase.executions.repository.ExecutionRepository;

@ExtendWith(MockitoExtension.class)
class ExecutionServiceTest {

    @Mock
    private ExecutionRepository executionRepository;
    @Mock
    private SearchProperties searchProperties;
    @InjectMocks
    private ExecutionService executionService;
    @Captor
    private ArgumentCaptor<Pageable> pageableCaptor;

    @BeforeEach
    void setUp() {
        when(searchProperties.getHardLimit()).thenReturn(100);
    }

    @Test
    void shouldReturnExecutionsMatchingSearchRequest() {
        SearchRequest searchRequest = new SearchRequest(List.of(new SearchCriteria("group", SearchOperator.EQUAL, "MDG")));

        List<Execution> mockExecutions = List.of(buildExecution("EXEC_1", "MDG", "VOD.L"), buildExecution("EXEC_2", "MDG", "AAPL.OQ"));

        when(executionRepository.findAll(any(Specification.class), any(Pageable.class))).thenReturn(new PageImpl<>(mockExecutions));

        List<Execution> result = executionService.searchExecutions(searchRequest);

        assertThat(result).isEqualTo(mockExecutions);

        verify(executionRepository).findAll(any(Specification.class), pageableCaptor.capture());

        Pageable capturedPageable = pageableCaptor.getValue();

        assertThat(capturedPageable.getPageSize()).isEqualTo(100);
        assertThat(capturedPageable.getPageNumber()).isZero();
    }

    @Test
    void shouldReturnEmptyListWhenNoExecutionsMatchSearchRequest() {
        SearchRequest searchRequest = new SearchRequest(List.of(new SearchCriteria("group", SearchOperator.EQUAL, "MDG")));

        when(executionRepository.findAll(any(Specification.class), any(Pageable.class))).thenReturn(new PageImpl<>(List.of()));

        List<Execution> result = executionService.searchExecutions(searchRequest);

        assertThat(result).isEmpty();

        verify(executionRepository).findAll(any(Specification.class), any(Pageable.class));
    }

    @Test
    void shouldUseConfiguredHardLimit() {
        when(searchProperties.getHardLimit()).thenReturn(50);

        SearchRequest searchRequest = new SearchRequest(List.of(new SearchCriteria("symbol", SearchOperator.LIKE, "VOD")));

        when(executionRepository.findAll(any(Specification.class), any(Pageable.class))).thenReturn(new PageImpl<>(List.of()));

        executionService.searchExecutions(searchRequest);

        verify(executionRepository).findAll(any(Specification.class), pageableCaptor.capture());

        Pageable capturedPageable = pageableCaptor.getValue();

        assertThat(capturedPageable.getPageSize()).isEqualTo(50);
        assertThat(capturedPageable.getPageNumber()).isZero();
    }

    private static Execution buildExecution(String execId, String ownerGroup, String symbol) {

        Execution execution = new Execution();

        ReflectionTestUtils.setField(execution, "execId", execId);

        ReflectionTestUtils.setField(execution, "ownerGroup", ownerGroup);

        ReflectionTestUtils.setField(execution, "symbol", symbol);

        return execution;
    }
}