package com.lseg.supportportal.backend.tools.searchdatabase.orders.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.test.util.ReflectionTestUtils;

import com.lseg.supportportal.backend.core.search.config.SearchProperties;
import com.lseg.supportportal.backend.core.search.domain.SearchCriteria;
import com.lseg.supportportal.backend.core.search.domain.SearchOperator;
import com.lseg.supportportal.backend.core.search.domain.SearchRequest;
import com.lseg.supportportal.backend.tools.searchdatabase.orders.domain.Order;
import com.lseg.supportportal.backend.tools.searchdatabase.orders.repository.OrderRepository;

@ExtendWith(MockitoExtension.class)
class OrderServiceTest {

    @Mock
    private OrderRepository orderRepository;
    @Mock
    private SearchProperties searchProperties;
    @InjectMocks
    private OrderService orderService;
    @Captor
    private ArgumentCaptor<Pageable> pageableCaptor;

    @BeforeEach
    void setUp() {
        when(searchProperties.getHardLimit()).thenReturn(100);
    }

    @Test
    void shouldReturnOrdersMatchingSearchRequest() {
        SearchRequest searchRequest = new SearchRequest(List.of(new SearchCriteria("group", SearchOperator.EQUAL, "MDG")));

        List<Order> mockOrders = List.of(
                buildOrder("ORDER_1", "MDG", "VOD.L", new BigDecimal("100.00")),
                buildOrder("ORDER_2", "MDG", "AAPL.OQ", new BigDecimal("50.00"))
        );

        when(orderRepository.findAll(any(Specification.class), any(Pageable.class))).thenReturn(new PageImpl<>(mockOrders));

        List<Order> result = orderService.searchOrders(searchRequest);

        assertThat(result).isEqualTo(mockOrders);

        verify(orderRepository).findAll(any(Specification.class), pageableCaptor.capture());

        Pageable capturedPageable = pageableCaptor.getValue();

        assertThat(capturedPageable.getPageSize()).isEqualTo(100);
        assertThat(capturedPageable.getPageNumber()).isZero();
    }

    @Test
    void shouldReturnEmptyListWhenNoOrdersMatchSearchRequest() {
        SearchRequest searchRequest = new SearchRequest(List.of(new SearchCriteria("group", SearchOperator.EQUAL, "MDG")));

        when(orderRepository.findAll(any(Specification.class), any(Pageable.class))).thenReturn(new PageImpl<>(List.of()));

        List<Order> result = orderService.searchOrders(searchRequest);

        assertThat(result).isEmpty();

        verify(orderRepository).findAll(any(Specification.class), any(Pageable.class));
    }

    @Test
    void shouldUseConfiguredHardLimit() {
        when(searchProperties.getHardLimit()).thenReturn(50);

        SearchRequest searchRequest = new SearchRequest(List.of(new SearchCriteria("reutersCode", SearchOperator.LIKE, "VOD")));

        when(orderRepository.findAll(any(Specification.class), any(Pageable.class))).thenReturn(new PageImpl<>(List.of()));

        orderService.searchOrders(searchRequest);

        verify(orderRepository).findAll(any(Specification.class), pageableCaptor.capture());

        Pageable capturedPageable = pageableCaptor.getValue();

        assertThat(capturedPageable.getPageSize()).isEqualTo(50);
        assertThat(capturedPageable.getPageNumber()).isZero();
    }

    private static Order buildOrder(String clOrdId, String ownerGroup, String productRicCode, BigDecimal orderQty) {

        Order order = new Order();

        ReflectionTestUtils.setField(order, "clOrdId", clOrdId);

        ReflectionTestUtils.setField(order, "ownerGroup", ownerGroup);

        ReflectionTestUtils.setField(order, "productRicCode", productRicCode);

        ReflectionTestUtils.setField(order, "orderQty", orderQty);

        return order;
    }
}