package com.lseg.supportportal.backend.core.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import jakarta.servlet.http.HttpServletRequest;

public class GlobalExceptionHandlerTest {

    private final GlobalExceptionHandler globalExceptionHandler = new GlobalExceptionHandler();

    @Test
    public void handleResponseStatusTest() {
        final ResponseStatusException exception = new ResponseStatusException(HttpStatusCode.valueOf(404));
        final HttpServletRequest request = Mockito.mock(HttpServletRequest.class);

        final ResponseEntity<ErrorResponse> responseEntity = globalExceptionHandler.handleResponseStatus(exception, request);
        assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
    }

    @Test
    public void handleValidationTest() {
        final MethodArgumentNotValidException exception = new MethodArgumentNotValidException(
                new MethodParameter(Object.class.getMethods()[0], -1),
                new BeanPropertyBindingResult(new Object(), "object")
        );
        final HttpServletRequest request = Mockito.mock(HttpServletRequest.class);

        final ResponseEntity<ErrorResponse> responseEntity = globalExceptionHandler.handleValidation(exception, request);
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
    }

    @Test
    public void handleTypeMismatchTest() {
        final MethodArgumentTypeMismatchException exception = new MethodArgumentTypeMismatchException(
                "value", String.class, "param", null, new IllegalArgumentException()
        );
        final HttpServletRequest request = Mockito.mock(HttpServletRequest.class);

        final ResponseEntity<ErrorResponse> responseEntity = globalExceptionHandler.handleBadRequest(exception, request);
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
    }

    @Test
    public void handleIllegalArgumentTest() {
        final IllegalArgumentException exception = new IllegalArgumentException();
        final HttpServletRequest request = Mockito.mock(HttpServletRequest.class);

        final ResponseEntity<ErrorResponse> responseEntity = globalExceptionHandler.handleBadRequest(exception, request);
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
    }

    @Test
    public void handleNoElementFoundTest() {
        final NoSuchElementException exception = new NoSuchElementException();
        final HttpServletRequest request = Mockito.mock(HttpServletRequest.class);

        final ResponseEntity<ErrorResponse> responseEntity = globalExceptionHandler.handleNotFound(exception, request);
        assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
    }

    @Test
    public void handleNotFoundTest() {
        final NoResourceFoundException exception = new NoResourceFoundException(HttpMethod.GET, "/unknown", "/unknown");
        final HttpServletRequest request = Mockito.mock(HttpServletRequest.class);

        final ResponseEntity<ErrorResponse> responseEntity = globalExceptionHandler.handleNotFound(exception, request);
        assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
    }

    @Test
    public void handleUnexpectedTest() {
        final Exception exception = new Exception();
        final HttpServletRequest request = Mockito.mock(HttpServletRequest.class);

        final ResponseEntity<ErrorResponse> responseEntity = globalExceptionHandler.handleUnexpected(exception, request);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
    }
}
