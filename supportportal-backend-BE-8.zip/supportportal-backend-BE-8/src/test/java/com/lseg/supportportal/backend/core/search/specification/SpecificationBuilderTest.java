package com.lseg.supportportal.backend.core.search.specification;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.data.jpa.domain.Specification;

import com.lseg.supportportal.backend.core.search.domain.SearchCriteria;
import com.lseg.supportportal.backend.core.search.domain.SearchOperator;
import com.lseg.supportportal.backend.core.search.domain.SearchRequest;
import com.lseg.supportportal.backend.tools.searchdatabase.orders.domain.Order;

class SpecificationBuilderTest {

    private SpecificationBuilder<Order> builder;

    @BeforeEach
    void setUp() {
        builder = new SpecificationBuilder<>(Order.class);
    }

    @Test
    void shouldReturnEmptySpecificationWhenSearchRequestHasNoFilters() {
        SearchRequest requestEmpty = new SearchRequest(List.of());

        Specification<Order> specEmpty = builder.build(requestEmpty);

        assertNotNull(specEmpty, "Specification container should never be null");
    }

    @Test
    void shouldCompileCleanlyWhenValidRegisteredKeyIsPassed() {
        SearchCriteria criteria = new SearchCriteria("reutersCode", SearchOperator.EQUAL, "TRI.N");
        SearchRequest request = new SearchRequest(List.of(criteria));

        assertDoesNotThrow(() -> builder.build(request), "Builder should map registered whitelisted annotation keys with zero errors.");
    }

    @Test
    void shouldThrowIllegalArgumentExceptionWhenKeyIsUnknown() {
        SearchCriteria criteria = new SearchCriteria("unauthorizedHackField", SearchOperator.EQUAL, "value");
        SearchRequest request = new SearchRequest(List.of(criteria));

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class, () -> builder.build(request),
                "Builder must immediately reject keys that are not registered."
        );

        assertTrue(exception.getMessage().contains("Unknown filter key"), "Error context should clearly flag that the key resolution failed.");
    }
}
