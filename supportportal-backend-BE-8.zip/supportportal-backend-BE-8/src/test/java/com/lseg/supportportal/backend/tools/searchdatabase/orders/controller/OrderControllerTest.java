package com.lseg.supportportal.backend.tools.searchdatabase.orders.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lseg.supportportal.backend.core.filters.domain.FilterDefinition;
import com.lseg.supportportal.backend.core.filters.domain.FilterType;
import com.lseg.supportportal.backend.core.filters.service.FilterConfigurationProvider;
import com.lseg.supportportal.backend.core.security.SecurityConfig;
import com.lseg.supportportal.backend.tools.searchdatabase.datasets.domain.Dataset;
import com.lseg.supportportal.backend.tools.searchdatabase.orders.domain.Order;
import com.lseg.supportportal.backend.tools.searchdatabase.orders.service.OrderService;

@WebMvcTest(OrderController.class)
@Import(SecurityConfig.class)
class OrderControllerTest {

    @Autowired
    private MockMvc mockMvc;
    private final ObjectMapper objectMapper = new ObjectMapper();
    @MockitoBean
    private OrderService orderService;
    @MockitoBean
    private FilterConfigurationProvider filterConfigurationProvider;

    @BeforeEach
    void setUp() {
        when(filterConfigurationProvider.getAllowedFilterKeys(Dataset.ORDERS)).thenReturn(
                Set.of("group", "side", "reutersCode", "account", "tag", "createdDate"));

        when(filterConfigurationProvider.getFilterDefinitions()).thenReturn(Map.of(
                "group", new FilterDefinition(FilterType.DROPDOWN, "Test"), "side", new FilterDefinition(FilterType.DROPDOWN, "Test"), "reutersCode",
                new FilterDefinition(FilterType.TEXT, "Test"), "account", new FilterDefinition(FilterType.TEXT, "Test"), "tag",
                new FilterDefinition(FilterType.TEXT, "Test"), "createdDate", new FilterDefinition(FilterType.DATE_RANGE, "Test")
        ));
    }

    @ParameterizedTest(name = "[{index}] key={0}, operator={1}, value={2}")
    @MethodSource("provideValidSearchCriteria")
    void shouldReturnOkWhenSearchRequestIsValid(String key, String operator, String value) throws Exception {

        List<Order> mockOrders = List.of(buildOrder("ORDER-1", "MDG", "PARENT", "VOD.L", new BigDecimal("100.00")));

        when(orderService.searchOrders(any())).thenReturn(mockOrders);

        mockMvc.perform(
                        post("/api/database/orders/search").contentType(MediaType.APPLICATION_JSON).content(buildSearchRequestBody(key, operator,
                                value)))
                .andExpect(status().isOk())
                .andExpect(content().json(objectMapper.writeValueAsString(mockOrders), true));
    }

    @ParameterizedTest(name = "[{index}] key={0}, operator={1}, value={2}")
    @MethodSource("provideOperatorIncompatibleWithFilterTypeCases")
    void shouldReturnBadRequestWhenOperatorIsNotCompatibleWithFilterType(String key, String operator, String value) throws Exception {

        mockMvc.perform(
                        post("/api/database/orders/search").contentType(MediaType.APPLICATION_JSON).content(buildSearchRequestBody(key, operator,
                                value)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void shouldReturnBadRequestWhenFilterKeyDoesNotExist() throws Exception {
        String requestBody = """
                {
                  "filters": [
                    {
                      "key": "invalidKey",
                      "operator": "EQUAL",
                      "value": "VOD.L"
                    }
                  ]
                }
                """;

        mockMvc.perform(post("/api/database/orders/search").contentType(MediaType.APPLICATION_JSON).content(requestBody))
                .andExpect(status().isBadRequest());
    }

    @Test
    void shouldReturnBadRequestWhenFiltersIsNull() throws Exception {
        String requestBody = """
                {
                  "filters": null
                }
                """;

        mockMvc.perform(post("/api/database/orders/search").contentType(MediaType.APPLICATION_JSON).content(requestBody))
                .andExpect(status().isBadRequest());
    }

    @Test
    void shouldReturnBadRequestWhenOperatorValueIsInvalidEnum() throws Exception {

        String requestBody = """
                {
                  "filters": [
                    {
                      "key": "group",
                      "operator": "dww",
                      "value": "Group10"
                    }
                  ]
                }
                """;

        mockMvc.perform(post("/api/database/orders/search").contentType(MediaType.APPLICATION_JSON).content(requestBody))
                .andExpect(status().isBadRequest());
    }

    private static Stream<Arguments> provideValidSearchCriteria() {
        return Stream.of(
                Arguments.of("group", "EQUAL", "\"MDG\""), Arguments.of("side", "EQUAL", "\"BUY\""),
                Arguments.of("reutersCode", "EQUAL", "\"VOD.L\""), Arguments.of("reutersCode", "LIKE", "\"VOD\""),
                Arguments.of("account", "EQUAL", "\"ACC-1\""), Arguments.of("account", "LIKE", "\"ACC\""), Arguments.of("tag", "EQUAL", "\"TAG-1\""),
                Arguments.of("tag", "LIKE", "\"TAG\""), Arguments.of("createdDate", "BETWEEN", "[\"2023-01-01\", \"2023-01-31\"]")
        );
    }

    private static Stream<Arguments> provideOperatorIncompatibleWithFilterTypeCases() {

        return Stream.of(
                Arguments.of("group", "LIKE", "\"GroupTest10\""), Arguments.of("side", "BETWEEN", "[\"BUY\", \"SELL\"]"),
                Arguments.of("reutersCode", "BETWEEN", "[\"A\", \"B\"]"), Arguments.of("account", "BETWEEN", "[\"A\", \"B\"]"),
                Arguments.of("tag", "BETWEEN", "[\"A\", \"B\"]"), Arguments.of("createdDate", "EQUAL", "\"2023-01-01\""),
                Arguments.of("createdDate", "LIKE", "\"2023-01-01\"")
        );
    }

    private static String buildSearchRequestBody(String key, String operator, String value) {

        return """
                {
                  "filters": [
                    {
                      "key": "%s",
                      "operator": "%s",
                      "value": %s
                    }
                  ]
                }
                """.formatted(key, operator, value);
    }

    private static Order buildOrder(String clOrdId, String ownerGroup, String parentType, String productRicCode, BigDecimal orderQty) {

        Order order = new Order();

        ReflectionTestUtils.setField(order, "clOrdId", clOrdId);

        ReflectionTestUtils.setField(order, "ownerGroup", ownerGroup);

        ReflectionTestUtils.setField(order, "parentType", parentType);

        ReflectionTestUtils.setField(order, "productRicCode", productRicCode);

        ReflectionTestUtils.setField(order, "orderQty", orderQty);

        return order;
    }
}



