package com.lseg.supportportal.backend.core.search.validator;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.contains;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.lseg.supportportal.backend.core.filters.domain.FilterDefinition;
import com.lseg.supportportal.backend.core.filters.domain.FilterType;
import com.lseg.supportportal.backend.core.filters.service.FilterConfigurationProvider;
import com.lseg.supportportal.backend.core.search.annotation.ValidSearchRequest;
import com.lseg.supportportal.backend.core.search.domain.SearchCriteria;
import com.lseg.supportportal.backend.core.search.domain.SearchOperator;
import com.lseg.supportportal.backend.core.search.domain.SearchRequest;
import com.lseg.supportportal.backend.tools.searchdatabase.datasets.domain.Dataset;

import jakarta.validation.ConstraintValidatorContext;

class SearchRequestValidatorTest {

    private SearchRequestValidator validator;
    private ConstraintValidatorContext context;
    private FilterConfigurationProvider configurationProvider;

    @BeforeEach
    void setUp() {
        configurationProvider = mock(FilterConfigurationProvider.class);

        doReturn(Map.of(
                "reutersCode", new FilterDefinition(FilterType.TEXT, "Test"),

                "group", new FilterDefinition(FilterType.DROPDOWN, "Test"),

                "createdDate", new FilterDefinition(FilterType.DATE_RANGE, "Test")
        )).when(configurationProvider).getFilterDefinitions();

        doReturn(Set.of("reutersCode", "group", "createdDate")).when(configurationProvider).getAllowedFilterKeys(Dataset.ORDERS);

        validator = new SearchRequestValidator(configurationProvider);

        final ValidSearchRequest annotation = mock(ValidSearchRequest.class);

        doReturn(Dataset.ORDERS).when(annotation).dataset();

        validator.initialize(annotation);

        context = mock(ConstraintValidatorContext.class);

        final ConstraintValidatorContext.ConstraintViolationBuilder violationBuilder = mock(
                ConstraintValidatorContext.ConstraintViolationBuilder.class);

        when(context.buildConstraintViolationWithTemplate(anyString())).thenReturn(violationBuilder);

        when(violationBuilder.addConstraintViolation()).thenReturn(context);
    }

    @Test
    void shouldReturnTrueWhenPayloadOrFiltersAreNull() {
        assertTrue(validator.isValid(null, context));

        assertTrue(validator.isValid(new SearchRequest(null), context));
    }

    @Test
    void shouldReturnTrueWhenFilterKeyIsValidAndOperatorIsCompatible() {
        final SearchCriteria criteria = new SearchCriteria("reutersCode", SearchOperator.EQUAL, "IBM.N");

        final SearchRequest request = new SearchRequest(List.of(criteria));

        assertTrue(validator.isValid(request, context));
    }

    @Test
    void shouldReturnFalseWhenFilterKeyIsNotSearchable() {
        final SearchCriteria criteria = new SearchCriteria("invalidKey", SearchOperator.EQUAL, "value");

        final SearchRequest request = new SearchRequest(List.of(criteria));

        assertFalse(validator.isValid(request, context));

        verify(context, times(1)).disableDefaultConstraintViolation();

        verify(context, times(1)).buildConstraintViolationWithTemplate(contains("invalidKey"));
    }

    @Test
    void shouldReturnFalseWhenFilterIsSearchableButNotAllowed() {
        doReturn(Set.of("group", "createdDate")).when(configurationProvider).getAllowedFilterKeys(Dataset.ORDERS);

        final ValidSearchRequest annotation = mock(ValidSearchRequest.class);

        doReturn(Dataset.ORDERS).when(annotation).dataset();

        validator.initialize(annotation);

        final SearchCriteria criteria = new SearchCriteria("reutersCode", SearchOperator.EQUAL, "IBM.N");

        final SearchRequest request = new SearchRequest(List.of(criteria));

        assertFalse(validator.isValid(request, context));

        verify(context, times(1)).disableDefaultConstraintViolation();

        verify(context, times(1)).buildConstraintViolationWithTemplate(contains("not allowed"));
    }

    @Test
    void shouldReturnFalseWhenOperatorIsNotCompatibleWithFilterType() {
        final SearchCriteria criteria = new SearchCriteria("group", SearchOperator.LIKE, "GroupTest10");

        final SearchRequest request = new SearchRequest(List.of(criteria));

        assertFalse(validator.isValid(request, context));

        verify(context, times(1)).disableDefaultConstraintViolation();

        verify(context, times(1)).buildConstraintViolationWithTemplate(contains("group"));
    }

    @Test
    void shouldReturnFalseWhenBetweenIsUsedOnNonDateRangeFilter() {
        final SearchCriteria criteria = new SearchCriteria("group", SearchOperator.BETWEEN, "Group10");

        final SearchRequest request = new SearchRequest(List.of(criteria));

        assertFalse(validator.isValid(request, context));

        verify(context, times(1)).disableDefaultConstraintViolation();

        verify(context, times(1)).buildConstraintViolationWithTemplate(contains("BETWEEN"));
    }

    @Test
    void shouldReturnTrueWhenBetweenIsUsedOnDateRangeFilter() {
        final SearchCriteria criteria = new SearchCriteria("createdDate", SearchOperator.BETWEEN, "2024-01-01");

        final SearchRequest request = new SearchRequest(List.of(criteria));

        assertTrue(validator.isValid(request, context));
    }

    @Test
    void shouldReturnTrueWhenAllowedSearchableKeyHasNoDefinitionEntry() {
        doReturn(Map.of()).when(configurationProvider).getFilterDefinitions();

        final ValidSearchRequest annotation = mock(ValidSearchRequest.class);

        doReturn(Dataset.ORDERS).when(annotation).dataset();

        validator.initialize(annotation);

        final SearchCriteria criteria = new SearchCriteria("reutersCode", SearchOperator.LIKE, "IBM");

        final SearchRequest request = new SearchRequest(List.of(criteria));

        assertTrue(validator.isValid(request, context));
    }
}