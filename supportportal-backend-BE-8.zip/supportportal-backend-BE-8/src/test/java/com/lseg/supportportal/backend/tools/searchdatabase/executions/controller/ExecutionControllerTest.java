package com.lseg.supportportal.backend.tools.searchdatabase.executions.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lseg.supportportal.backend.core.filters.domain.FilterDefinition;
import com.lseg.supportportal.backend.core.filters.domain.FilterType;
import com.lseg.supportportal.backend.core.filters.service.FilterConfigurationProvider;
import com.lseg.supportportal.backend.core.security.SecurityConfig;
import com.lseg.supportportal.backend.tools.searchdatabase.datasets.domain.Dataset;
import com.lseg.supportportal.backend.tools.searchdatabase.executions.domain.Execution;
import com.lseg.supportportal.backend.tools.searchdatabase.executions.service.ExecutionService;

@WebMvcTest(ExecutionController.class)
@Import(SecurityConfig.class)
class ExecutionControllerTest {

    @Autowired
    private MockMvc mockMvc;
    private final ObjectMapper objectMapper = new ObjectMapper();
    @MockitoBean
    private ExecutionService executionService;
    @MockitoBean
    private FilterConfigurationProvider filterConfigurationProvider;

    @BeforeEach
    void setUp() {
        when(filterConfigurationProvider.getAllowedFilterKeys(Dataset.EXECUTIONS)).thenReturn(Set.of("group", "symbol", "executionTime", "side"));

        when(filterConfigurationProvider.getFilterDefinitions()).thenReturn(Map.of(
                "group", new FilterDefinition(FilterType.DROPDOWN, "Test"), "symbol", new FilterDefinition(FilterType.TEXT, "Test"), "executionTime",
                new FilterDefinition(FilterType.DATE_RANGE, "Test"), "side", new FilterDefinition(FilterType.DROPDOWN, "Test")
        ));
    }

    @ParameterizedTest(name = "[{index}] key={0}, operator={1}, value={2}")
    @MethodSource("provideValidSearchCriteria")
    void shouldReturnOkWhenSearchRequestIsValid(String key, String operator, String value) throws Exception {

        List<Execution> mockExecutions = List.of();

        when(executionService.searchExecutions(any())).thenReturn(mockExecutions);

        mockMvc.perform(
                        post("/api/database/executions/search").contentType(MediaType.APPLICATION_JSON).content(buildSearchRequestBody(key,
                                operator, value)))
                .andExpect(status().isOk())
                .andExpect(content().json(objectMapper.writeValueAsString(mockExecutions), true));
    }

    @ParameterizedTest(name = "[{index}] key={0}, operator={1}, value={2}")
    @MethodSource("provideOperatorIncompatibleWithFilterTypeCases")
    void shouldReturnBadRequestWhenOperatorIsNotCompatibleWithFilterType(String key, String operator, String value) throws Exception {

        mockMvc.perform(
                        post("/api/database/executions/search").contentType(MediaType.APPLICATION_JSON).content(buildSearchRequestBody(key,
                                operator, value)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void shouldReturnBadRequestWhenFilterKeyDoesNotExist() throws Exception {
        String requestBody = """
                {
                  "filters": [
                    {
                      "key": "invalidKey",
                      "operator": "EQUAL",
                      "value": "value"
                    }
                  ]
                }
                """;

        mockMvc.perform(post("/api/database/executions/search").contentType(MediaType.APPLICATION_JSON).content(requestBody))
                .andExpect(status().isBadRequest());
    }

    @Test
    void shouldReturnBadRequestWhenFiltersIsNull() throws Exception {
        String requestBody = """
                {
                  "filters": null
                }
                """;

        mockMvc.perform(post("/api/database/executions/search").contentType(MediaType.APPLICATION_JSON).content(requestBody))
                .andExpect(status().isBadRequest());
    }

    @Test
    void shouldReturnBadRequestWhenOperatorValueIsInvalidEnum() throws Exception {

        String requestBody = """
                {
                  "filters": [
                    {
                      "key": "group",
                      "operator": "dww",
                      "value": "Group10"
                    }
                  ]
                }
                """;

        mockMvc.perform(post("/api/database/executions/search").contentType(MediaType.APPLICATION_JSON).content(requestBody))
                .andExpect(status().isBadRequest());
    }

    private static Stream<Arguments> provideValidSearchCriteria() {
        return Stream.of(
                Arguments.of("group", "EQUAL", "\"MDG\""), Arguments.of("side", "EQUAL", "\"BUY\""), Arguments.of("symbol", "EQUAL", "\"VOD.L\""),
                Arguments.of("symbol", "LIKE", "\"VOD\""), Arguments.of("executionTime", "BETWEEN", "[\"2023-01-01\", \"2023-01-31\"]")
        );
    }

    private static Stream<Arguments> provideOperatorIncompatibleWithFilterTypeCases() {

        return Stream.of(
                Arguments.of("group", "LIKE", "\"GroupTest10\""), Arguments.of("side", "BETWEEN", "[\"BUY\", \"SELL\"]"),
                Arguments.of("symbol", "BETWEEN", "[\"A\", \"B\"]"), Arguments.of("executionTime", "EQUAL", "\"2023-01-01\""),
                Arguments.of("executionTime", "LIKE", "\"2023-01-01\"")
        );
    }

    private static String buildSearchRequestBody(String key, String operator, String value) {

        return """
                {
                  "filters": [
                    {
                      "key": "%s",
                      "operator": "%s",
                      "value": %s
                    }
                  ]
                }
                """.formatted(key, operator, value);
    }
}