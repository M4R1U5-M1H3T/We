package com.lseg.supportportal.backend.tools.searchdatabase.orders.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lseg.supportportal.backend.core.search.annotation.ValidSearchRequest;
import com.lseg.supportportal.backend.core.search.domain.SearchRequest;
import com.lseg.supportportal.backend.tools.searchdatabase.datasets.domain.Dataset;
import com.lseg.supportportal.backend.tools.searchdatabase.orders.domain.Order;
import com.lseg.supportportal.backend.tools.searchdatabase.orders.service.OrderService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/database/orders")
@RequiredArgsConstructor
@Tag(name = "Orders", description = "Endpoint for accessing order data")
public class OrderController {

    private final OrderService orderService;

    @PostMapping("/search")
    @Operation(summary = "Search orders", description = "Searches orders from the database using the provided filters.")
    @ApiResponse(responseCode = "200", description = "Succesfully retrieved orders.")
    public ResponseEntity<List<Order>> searchOrders(@Valid @RequestBody @ValidSearchRequest(dataset = Dataset.ORDERS) SearchRequest searchRequest) {
        return ResponseEntity.ok(orderService.searchOrders(searchRequest));
    }
}