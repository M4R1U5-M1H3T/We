package com.lseg.supportportal.backend.core.search.exception;

public class InvalidSearchCriteriaException extends RuntimeException {

    public InvalidSearchCriteriaException(final String message) {
        super(message);
    }
}
