package com.lseg.supportportal.backend.tools.searchdatabase.executions.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lseg.supportportal.backend.core.search.annotation.ValidSearchRequest;
import com.lseg.supportportal.backend.core.search.domain.SearchRequest;
import com.lseg.supportportal.backend.tools.searchdatabase.datasets.domain.Dataset;
import com.lseg.supportportal.backend.tools.searchdatabase.executions.domain.Execution;
import com.lseg.supportportal.backend.tools.searchdatabase.executions.service.ExecutionService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/database/executions")
@RequiredArgsConstructor
@Tag(name = "Executions", description = "Endpoint for accessing execution data")
public class ExecutionController {

    private final ExecutionService executionService;

    @PostMapping("/search")
    @Operation(summary = "Search executions", description = "Searches executions from the database using the provided filters")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved executions.")
    public ResponseEntity<List<Execution>> searchExecutions(@Valid @RequestBody @ValidSearchRequest(dataset = Dataset.EXECUTIONS) SearchRequest searchRequest) {
        return ResponseEntity.ok(executionService.searchExecutions(searchRequest));
    }
}
