package com.lseg.supportportal.backend.core.search.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.lseg.supportportal.backend.core.search.validator.SearchRequestValidator;
import com.lseg.supportportal.backend.tools.searchdatabase.datasets.domain.Dataset;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

@Target({ElementType.TYPE, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = SearchRequestValidator.class)
@Documented
public @interface ValidSearchRequest {

    Dataset dataset();

    String message() default "Validation failed";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
