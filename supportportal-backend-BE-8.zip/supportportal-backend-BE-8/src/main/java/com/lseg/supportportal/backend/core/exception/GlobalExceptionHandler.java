package com.lseg.supportportal.backend.core.exception;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Objects;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import com.lseg.supportportal.backend.core.filters.exception.FilterConfigurationException;
import com.lseg.supportportal.backend.core.search.exception.InvalidSearchCriteriaException;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(ResponseStatusException.class)
    public ResponseEntity<ErrorResponse> handleResponseStatus(final ResponseStatusException ex, final HttpServletRequest request) {
        final HttpStatus status = HttpStatus.valueOf(ex.getStatusCode().value());
        log.info("Handled {} on {}: {}", status, request.getRequestURI(), ex.getReason());

        String message = Objects.requireNonNullElse(ex.getReason(), "Reason Unknown");
        return buildErrorResponse(status, message, request);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleValidation(final MethodArgumentNotValidException ex, final HttpServletRequest request) {
        final List<String> details = ex.getBindingResult()
                .getFieldErrors()
                .stream()
                .map(fieldError -> fieldError.getField() + ": " + fieldError.getDefaultMessage())
                .toList();
        log.warn("Validation Failed on {}: {}", request.getRequestURI(), details);
        return buildErrorResponse(HttpStatus.BAD_REQUEST, "Validation failed", request, details);
    }

    @ExceptionHandler({IllegalArgumentException.class, MethodArgumentTypeMismatchException.class, FilterConfigurationException.class,
                       HttpMessageNotReadableException.class, InvalidSearchCriteriaException.class})
    public ResponseEntity<ErrorResponse> handleBadRequest(final Exception ex, final HttpServletRequest request) {
        log.warn("Bad Request on {}: {}", request.getRequestURI(), ex.getMessage());
        return buildErrorResponse(HttpStatus.BAD_REQUEST, ex.getMessage(), request);
    }

    @ExceptionHandler({NoSuchElementException.class, NoResourceFoundException.class})
    public ResponseEntity<ErrorResponse> handleNotFound(final Exception ex, final HttpServletRequest request) {
        log.warn("Not Found on {}: {}", request.getRequestURI(), ex.getMessage());
        return buildErrorResponse(HttpStatus.NOT_FOUND, ex.getMessage(), request);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleUnexpected(final Exception ex, final HttpServletRequest request) {
        log.error("Unexpected Exception on {}", request.getRequestURI(), ex);
        return buildErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR, "An unexpected error occurred!", request);
    }

    private ResponseEntity<ErrorResponse> buildErrorResponse(final HttpStatus status, final String message, final HttpServletRequest request) {
        return buildErrorResponse(status, message, request, null);
    }

    private ResponseEntity<ErrorResponse> buildErrorResponse(
            final HttpStatus status, final String message, final HttpServletRequest request, final List<String> details) {
        return ResponseEntity.status(status)
                .body(ErrorResponse.of(status.value(), status.getReasonPhrase(), message, request.getRequestURI(), details));
    }
}
