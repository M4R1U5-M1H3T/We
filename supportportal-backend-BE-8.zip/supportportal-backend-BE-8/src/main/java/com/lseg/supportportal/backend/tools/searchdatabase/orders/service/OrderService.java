package com.lseg.supportportal.backend.tools.searchdatabase.orders.service;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.lseg.supportportal.backend.core.search.config.SearchProperties;
import com.lseg.supportportal.backend.core.search.domain.SearchRequest;
import com.lseg.supportportal.backend.core.search.specification.SpecificationBuilder;
import com.lseg.supportportal.backend.tools.searchdatabase.orders.domain.Order;
import com.lseg.supportportal.backend.tools.searchdatabase.orders.repository.OrderRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;
    private final SearchProperties searchProperties;
    private final SpecificationBuilder<Order> specificationBuilder = new SpecificationBuilder<>(Order.class);

    public List<Order> searchOrders(SearchRequest searchRequest) {
        final Pageable pageable = Pageable.ofSize(searchProperties.getHardLimit());
        Specification<Order> specification = specificationBuilder.build(searchRequest);
        return orderRepository.findAll(specification, pageable).getContent();
    }
}
