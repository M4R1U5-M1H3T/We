package com.lseg.supportportal.backend.core.filters.validator;

import java.util.HashSet;
import java.util.Set;

import org.springframework.core.io.Resource;

import com.lseg.supportportal.backend.core.fields.util.SearchableFieldResolver;
import com.lseg.supportportal.backend.core.filters.domain.FilterConfig;
import com.lseg.supportportal.backend.core.filters.exception.FilterConfigurationException;

public class FilterConfigurationValidator {

    private FilterConfigurationValidator() {}

    public static void validate(final Resource filterConfigResource, final FilterConfig filterConfig, final Class<?> entityClass) {
        validateAllowedFilters(filterConfigResource, filterConfig);
        validateDefaultFilters(filterConfigResource, filterConfig);
        validateRequiredFilters(filterConfigResource, filterConfig);
        validateFiltersAreSearchable(filterConfigResource, filterConfig, entityClass);
    }

    private static void validateAllowedFilters(final Resource filterConfigResource, final FilterConfig filterConfig) {
        final Set<String> uniqueFilters = new HashSet<>(filterConfig.allowedFilters());

        if (uniqueFilters.size() != filterConfig.allowedFilters().size()) {
            throw new FilterConfigurationException("Duplicate filter key found in allowedFilters of '" + filterConfigResource.getDescription() + "'");
        }
    }

    private static void validateDefaultFilters(final Resource filterConfigResource, final FilterConfig filterConfig) {
        final Set<String> defaultFilters = new HashSet<>(filterConfig.defaultFilters());

        if (defaultFilters.size() != filterConfig.defaultFilters().size()) {
            throw new FilterConfigurationException("Duplicate filter key found in defaultFilters of '" + filterConfigResource.getDescription() + "'");
        }
        if (!filterConfig.allowedFilters().containsAll(defaultFilters)) {
            throw new FilterConfigurationException(
                    "defaultFilters references unknown filter keys in '" + filterConfigResource.getDescription() + "' - defaultFilters: "
                            + defaultFilters + ", filters: " + filterConfig.allowedFilters());
        }
    }

    private static void validateRequiredFilters(final Resource filterConfigResource, final FilterConfig filterConfig) {
        final Set<String> requiredFilters = new HashSet<>(filterConfig.requiredFilters());

        if (requiredFilters.size() != filterConfig.requiredFilters().size()) {
            throw new FilterConfigurationException(
                    "Duplicate filter key found in requiredFilters of '" + filterConfigResource.getDescription() + "'");
        }

        if (!filterConfig.allowedFilters().containsAll(requiredFilters)) {
            throw new FilterConfigurationException(
                    "requiredFilters not present in allowedFilters of '" + filterConfigResource.getDescription() + "' - requiredFilters: "
                            + requiredFilters + ", allowedFilters: " + filterConfig.allowedFilters());
        }
    }

    private static void validateFiltersAreSearchable(
            final Resource filterConfigResource, final FilterConfig filterConfig, final Class<?> entityClass) {
        final Set<String> searchableKeys = SearchableFieldResolver.resolveSearchableFieldsByKey(entityClass).keySet();
        final Set<String> unresolvedFilterKeys = new HashSet<>(filterConfig.allowedFilters());

        unresolvedFilterKeys.removeAll(searchableKeys);

        if (!unresolvedFilterKeys.isEmpty()) {
            throw new FilterConfigurationException("Filters " + unresolvedFilterKeys + " declared in '" + filterConfigResource.getDescription()
                    + "' have no matching @SearchableField on " + entityClass.getSimpleName());
        }
    }
}
