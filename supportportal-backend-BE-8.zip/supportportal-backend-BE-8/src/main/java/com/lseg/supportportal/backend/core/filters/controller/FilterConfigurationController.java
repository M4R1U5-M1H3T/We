package com.lseg.supportportal.backend.core.filters.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lseg.supportportal.backend.core.filters.domain.PageFilters;
import com.lseg.supportportal.backend.core.filters.service.FilterConfigurationService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/database/filters")
@RequiredArgsConstructor
public class FilterConfigurationController {

    private final FilterConfigurationService filterConfigurationService;

    @GetMapping("/{page}")
    public ResponseEntity<PageFilters> getSearchFiltersForPage(@PathVariable final String page) {
        return ResponseEntity.ok(filterConfigurationService.getPageFilters(page));
    }

}
