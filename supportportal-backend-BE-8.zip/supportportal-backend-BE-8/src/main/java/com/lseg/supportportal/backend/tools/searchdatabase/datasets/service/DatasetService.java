package com.lseg.supportportal.backend.tools.searchdatabase.datasets.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.lseg.supportportal.backend.core.fields.util.LabelResolver;
import com.lseg.supportportal.backend.tools.searchdatabase.datasets.domain.ColumnInfo;
import com.lseg.supportportal.backend.tools.searchdatabase.datasets.domain.Dataset;

@Service
public class DatasetService {

    public List<String> getAvailableDatasetNames() {
        return Arrays.stream(Dataset.values()).map(Dataset::getLabel).toList();
    }

    public List<ColumnInfo> getColumns(final String datasetName) {
        final var dataset = Dataset.fromLabel(datasetName);
        return Arrays.stream(dataset.getEntityClass().getDeclaredFields())
                .map(field -> new ColumnInfo(field.getName(), LabelResolver.resolveDisplayName(field)))
                .toList();
    }
}
