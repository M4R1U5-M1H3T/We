package com.lseg.supportportal.backend.core.filters.service;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.lseg.supportportal.backend.core.filters.domain.FilterConfig;
import com.lseg.supportportal.backend.core.filters.domain.FilterDefinition;
import com.lseg.supportportal.backend.core.filters.domain.PageFilters;
import com.lseg.supportportal.backend.tools.searchdatabase.datasets.domain.Dataset;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class FilterConfigurationService {

    private final FilterConfigurationProvider filterConfigurationProvider;
    private final FilterConfigurationMapper filterConfigurationMapper;

    public PageFilters getPageFilters(final String datasetName) {
        final Dataset dataset = Dataset.fromName(datasetName);

        final FilterConfig config = filterConfigurationProvider.getConfig(dataset);
        final Map<String, FilterDefinition> definitions = filterConfigurationProvider.getFilterDefinitions();

        return filterConfigurationMapper.toPageFilters(dataset, config, definitions);
    }
}
