package com.lseg.supportportal.backend.core.search.validator;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import com.lseg.supportportal.backend.core.fields.util.SearchableFieldResolver;
import com.lseg.supportportal.backend.core.filters.domain.FilterDefinition;
import com.lseg.supportportal.backend.core.filters.service.FilterConfigurationProvider;
import com.lseg.supportportal.backend.core.search.annotation.ValidSearchRequest;
import com.lseg.supportportal.backend.core.search.domain.SearchCriteria;
import com.lseg.supportportal.backend.core.search.domain.SearchRequest;
import com.lseg.supportportal.backend.tools.searchdatabase.datasets.domain.Dataset;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class SearchRequestValidator implements ConstraintValidator<ValidSearchRequest, SearchRequest> {

    private final FilterConfigurationProvider filterConfigurationProvider;
    private Set<String> searchableKeys;
    private Set<String> allowedKeys;
    private Map<String, FilterDefinition> definitions;

    public SearchRequestValidator(final FilterConfigurationProvider filterConfigurationProvider) {
        this.filterConfigurationProvider = filterConfigurationProvider;
    }

    @Override
    public void initialize(ValidSearchRequest constraintAnnotation) {
        final Dataset dataset = constraintAnnotation.dataset();

        this.searchableKeys = SearchableFieldResolver.resolveSearchableFieldsByKey(dataset.getEntityClass()).keySet();
        this.allowedKeys = filterConfigurationProvider.getAllowedFilterKeys(dataset);
        this.definitions = filterConfigurationProvider.getFilterDefinitions();
    }

    @Override
    public boolean isValid(SearchRequest searchRequest, ConstraintValidatorContext context) {
        List<SearchCriteria> filters = (searchRequest != null && searchRequest.filters() != null) ? searchRequest.filters() : List.of();

        return filters.stream()
                .map(this::validate)
                .filter(Objects::nonNull)
                .findFirst()
                .map(message -> {
                    context.disableDefaultConstraintViolation();
                    context.buildConstraintViolationWithTemplate(message).addConstraintViolation();
                    return false;
                }).orElse(true);
    }

    private String validate(final SearchCriteria criteria) {
        if (criteria.key() == null || !searchableKeys.contains(criteria.key())) {
            return "Validation failed: Filter key " + criteria.key() + " is not searchable";
        }

        if (!allowedKeys.contains(criteria.key())) {
            return "Validation failed: Filter key " + criteria.key() + " is not allowed";
        }

        final FilterDefinition filterDefinition = definitions.get(criteria.key());
        if (filterDefinition != null && !criteria.operator().isCompatibleWith(filterDefinition.type())) {
            return "Validation failed: operator " + criteria.operator() + " is not compatible with filter '" + criteria.key() + "' (type "
                    + filterDefinition.type() + ").";
        }

        return null;
    }
}
