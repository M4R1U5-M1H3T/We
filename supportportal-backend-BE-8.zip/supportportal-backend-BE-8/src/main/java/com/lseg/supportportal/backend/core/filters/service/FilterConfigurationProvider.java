package com.lseg.supportportal.backend.core.filters.service;

import java.util.Arrays;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.lseg.supportportal.backend.core.filters.domain.FilterConfig;
import com.lseg.supportportal.backend.core.filters.domain.FilterDefinition;
import com.lseg.supportportal.backend.tools.searchdatabase.datasets.domain.Dataset;

import jakarta.annotation.PostConstruct;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class FilterConfigurationProvider {

    private final FilterConfigurationLoader filterConfigurationLoader;
    private Map<Dataset, FilterConfig> filterConfigurations;
    @Getter
    private Map<String, FilterDefinition> filterDefinitions;

    @PostConstruct
    public void initialize() {
        this.filterDefinitions = Map.copyOf(filterConfigurationLoader.loadDefinitions());

        this.filterConfigurations = Arrays.stream(Dataset.values())
                .collect(Collectors.toUnmodifiableMap(Function.identity(), filterConfigurationLoader::loadFilterConfig));
    }

    public FilterConfig getConfig(final Dataset dataset) {
        return filterConfigurations.get(dataset);
    }

    public Set<String> getAllowedFilterKeys(final Dataset dataset) {
        return Set.copyOf(getConfig(dataset).allowedFilters());
    }
}
