package com.lseg.supportportal.backend.core.fields.util;

import java.lang.reflect.Field;

import com.lseg.supportportal.backend.core.fields.annotation.Label;

public class LabelResolver {

    private LabelResolver() {}

    public static String resolveDisplayName(final Field field) {
        Label displayName = field.getAnnotation(Label.class);
        return displayName != null ? displayName.value() : field.getName();
    }
}
