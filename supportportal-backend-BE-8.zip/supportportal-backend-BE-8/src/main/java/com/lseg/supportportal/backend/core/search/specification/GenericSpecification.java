package com.lseg.supportportal.backend.core.search.specification;

import java.time.LocalDate;
import java.util.Map;

import org.springframework.data.jpa.domain.Specification;

import com.lseg.supportportal.backend.core.search.domain.DateRangeValue;
import com.lseg.supportportal.backend.core.search.domain.SearchCriteria;
import com.lseg.supportportal.backend.core.search.domain.SearchOperator;
import com.lseg.supportportal.backend.core.search.exception.InvalidSearchCriteriaException;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class GenericSpecification<T> implements Specification<T> {

    private final SearchCriteria searchCriteria;
    private final String fieldName;

    @Override
    public Predicate toPredicate(Root<T> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {
        Object value = searchCriteria.value();
        if (value == null) {
            return null;
        }

        Expression<?> expression = root.get(fieldName);
        SearchOperator operator = searchCriteria.operator();

        return switch (operator) {
            case EQUAL -> criteriaBuilder.equal(expression, value);
            case LIKE -> criteriaBuilder.like(criteriaBuilder.lower(expression.as(String.class)), toLikePattern(value));
            case BETWEEN -> getBetweenPredicate(criteriaBuilder, value, expression);
        };
    }

    private static Predicate getBetweenPredicate(CriteriaBuilder criteriaBuilder, Object value, Expression<?> expression) {
        Expression<LocalDate> dateExpression = expression.as(LocalDate.class);

        if (value instanceof DateRangeValue(LocalDate from, LocalDate to)) {
            return criteriaBuilder.between(dateExpression, from, to);
        }

        if (value instanceof Map<?, ?> map && map.containsKey("from") && map.containsKey("to")) {
            LocalDate from = LocalDate.parse(map.get("from").toString().trim());
            LocalDate to = LocalDate.parse(map.get("to").toString().trim());
            return criteriaBuilder.between(dateExpression, from, to);
        }

        throw new InvalidSearchCriteriaException("BETWEEN operator requires an object containing from and to fields.");
    }

    private static String toLikePattern(Object value) {
        return "%" + value.toString().toLowerCase() + "%";
    }

}
