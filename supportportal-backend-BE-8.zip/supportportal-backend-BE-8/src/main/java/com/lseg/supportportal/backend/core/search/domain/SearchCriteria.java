package com.lseg.supportportal.backend.core.search.domain;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record SearchCriteria(@NotBlank(message = "Filter key must not be blank") String key,
                             @NotNull(message = "Search operator must not be null") SearchOperator operator,
                             @NotNull(message = "Filter value must not be null") Object value) {}
