package com.lseg.supportportal.backend.core.filters.domain;

import java.util.List;

public record FilterConfig(List<String> requiredFilters, List<String> defaultFilters, List<String> allowedFilters) {}
