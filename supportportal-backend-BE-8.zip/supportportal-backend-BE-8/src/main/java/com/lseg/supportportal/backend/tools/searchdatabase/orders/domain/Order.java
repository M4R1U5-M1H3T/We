package com.lseg.supportportal.backend.tools.searchdatabase.orders.domain;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.lseg.supportportal.backend.core.fields.annotation.Label;
import com.lseg.supportportal.backend.core.fields.annotation.SearchableField;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "orders")
@IdClass(OrderPrimaryKey.class)
@Getter
@NoArgsConstructor
public class Order {

    @Id
    @Label("Client Order ID")
    @Column(name = "clordid", nullable = false)
    private String clOrdId;

    @Label("Order ID")
    @Column(name = "orderid")
    private String orderId;

    @Label("Symbol")
    @Column(name = "symbol")
    private String symbol;

    @Label("Order State")
    @Column(name = "ordstate")
    private String ordState;

    @Label("Security Type")
    @Column(name = "securitytype")
    private String securityType;

    @Label("Order Status")
    @Column(name = "ordstatus")
    private String ordStatus;

    @Label("Security Exchange")
    @Column(name = "securityexchange")
    private String securityExchange;

    @Label("Order Quantity")
    @Column(name = "orderqty")
    private BigDecimal orderQty;

    @Label("Price")
    @Column(name = "price")
    private BigDecimal price;

    @Label("Order Time")
    @Column(name = "ordertime")
    private LocalDateTime orderTime;

    @Label("Executing Broker")
    @Column(name = "execbroker")
    private String execBroker;

    @Label("Account")
    @SearchableField(key = "account")
    @Column(name = "account")
    private String account;

    @Label("Condition")
    @Column(name = "condition")
    private String condition;

    @Label("Owner")
    @Column(name = "owner")
    private String owner;

    @Id
    @Label("Owner Group")
    @SearchableField(key = "group")
    @Column(name = "ownergroup", nullable = false)
    private String ownerGroup;

    @Label("Side")
    @SearchableField(key = "side")
    @Column(name = "side")
    private String side;

    @Label("Receive Date")
    @Column(name = "recdate")
    private LocalDateTime recDate;

    @Label("Margin")
    @Column(name = "margin")
    private String margin;

    @Label("Trade Book")
    @Column(name = "tradebook")
    private String tradeBook;

    @Label("Commission")
    @Column(name = "commission")
    private BigDecimal commission;

    @Label("Commission Type")
    @Column(name = "commissiontype")
    private String commissionType;

    @Label("Stop Price")
    @Column(name = "stopprice")
    private BigDecimal stopPrice;

    @Label("Work Type")
    @Column(name = "worktype")
    private String workType;

    @Label("Manual Flag")
    @Column(name = "manualflag")
    private String manualFlag;

    @Label("Internal Account")
    @Column(name = "internalaccount")
    private String internalAccount;

    @Label("Allocation Method")
    @Column(name = "allocationmethod")
    private String allocationMethod;

    @Label("Confirmation")
    @Column(name = "confirmation")
    private String confirmation;

    @Label("Buy To Cover")
    @Column(name = "btc")
    private String btc;

    @Label("Expire Date")
    @Column(name = "expiredate")
    private LocalDateTime expireDate;

    @Label("Time In Force")
    @Column(name = "tif")
    private String tif;

    @Label("External ID")
    @Column(name = "externalid")
    private String externalId;

    @Label("Sender")
    @Column(name = "sender")
    private String sender;

    @Label("Update Time")
    @Column(name = "updatetime")
    private LocalDateTime updateTime;

    @Label("Broker Destination")
    @Column(name = "brokerdest")
    private String brokerDest;

    @Label("Synthetic Type")
    @Column(name = "synthtype")
    private String synthType;

    @Label("Parent Order ID")
    @Column(name = "parentid")
    private String parentId;

    @Label("Parent Type")
    @Column(name = "parenttype")
    private String parentType;

    @Label("Is Parent Order")
    @Column(name = "isparent")
    private String isParent;

    @Label("Liquidity Transaction ID")
    @Column(name = "liquiditytransid")
    private String liquidityTransId;

    @Label("Crossing Parameters")
    @Column(name = "crossingparams")
    private String crossingParams;

    @Label("Originator")
    @Column(name = "originator")
    private String originator;

    @Label("Broker-Specific Strategy")
    @Column(name = "brkspecstrat")
    private String brkSpecStrat;

    @Label("Settlement Date")
    @Column(name = "settlementdate")
    private LocalDateTime settlementDate;

    @Label("Traded Currency")
    @Column(name = "tradedccy")
    private String tradedCcy;

    @Label("Settlement FX Rate")
    @Column(name = "settlementfxrate")
    private BigDecimal settlementFxRate;

    @Label("Settlement Currency")
    @Column(name = "settlementccy")
    private String settlementCcy;

    @Label("Settlement FX Direction")
    @Column(name = "settlementfxdir")
    private String settlementFxDir;

    @Label("Product ISIN Code")
    @Column(name = "productisincode")
    private String productIsinCode;

    @Label("Product Bloomberg Code")
    @Column(name = "productbloombergcode")
    private String productBloombergCode;

    @Label("Product CUSIP Code")
    @Column(name = "productcusipcode")
    private String productCusipCode;

    @Label("Product SEDOL Code")
    @Column(name = "productsedolcode")
    private String productSedolCode;

    @Label("Open/Close")
    @Column(name = "openclose")
    private String openClose;

    @Label("Short Locate")
    @Column(name = "shortlocate")
    private String shortLocate;

    @Label("Last Touch Owner")
    @Column(name = "lasttouchowner")
    private String lastTouchOwner;

    @Label("Product RIC Code")
    @SearchableField(key = "reutersCode")
    @Column(name = "productriccode")
    private String productRicCode;

    @Label("Tag")
    @SearchableField(key = "tag")
    @Column(name = "tag")
    private String tag;

    @Label("Note")
    @Column(name = "note")
    private String note;

    @Label("Broker Destination Parameters")
    @Column(name = "brokerdestparams")
    private String brokerDestParams;

    @Label("Broker-Specific ATDL")
    @Column(name = "brkspecatdl")
    private String brkSpecAtdl;

    @Label("Instruction Hash Value")
    @Column(name = "inshashvalue")
    private String insHashValue;

    @Label("Exchange Order ID")
    @Column(name = "exchangeorderid")
    private String exchangeOrderId;

    @Label("Exchange Internal ID")
    @Column(name = "exchangeinternalid")
    private String exchangeInternalId;

    @Label("Creation Time")
    @SearchableField(key = "createdDate")
    @Column(name = "creationtime")
    private LocalDateTime creationTime;

    @Label("External Owner")
    @Column(name = "externalowner")
    private String externalOwner;

    @Label("Basket List ID")
    @Column(name = "balistid")
    private String balistId;

    @Label("Basket List Type")
    @Column(name = "balisttype")
    private String balistType;

    @Label("Internal Note")
    @Column(name = "internalnote")
    private String internalNote;

    @Label("Strategy")
    @Column(name = "strategy")
    private String strategy;

    @Label("MiFID Fields")
    @Column(name = "mifidfields")
    private String mifidFields;

    @Label("ATDL Description")
    @Column(name = "atdldescription")
    private String atdlDescription;

    @Label("Notional Price")
    @Column(name = "notionalprice")
    private BigDecimal notionalPrice;

    @Label("Executed Notional Value")
    @Column(name = "executednotionalvalue")
    private BigDecimal executedNotionalValue;

    @Label("Executed Quantity")
    @Column(name = "executedquantity")
    private BigDecimal executedQuantity;

    @Label("Order Quantity 2")
    @Column(name = "orderqty2")
    private BigDecimal orderQty2;

    @Label("Executed Quantity 2")
    @Column(name = "executedquantity2")
    private BigDecimal executedQuantity2;

    @Label("Limit Reject Message")
    @Column(name = "limitrejectmessage")
    private String limitRejectMessage;

    @Label("Developer Internal Details")
    @Column(name = "devinternaldetails")
    private String devInternalDetails;

    @Label("Day Order Expire Date")
    @Column(name = "dayorderexpiredate")
    private LocalDateTime dayOrderExpireDate;

    @Label("Extra Fields")
    @Column(name = "extrafields", columnDefinition = "jsonb")
    private String extraFields;
}
