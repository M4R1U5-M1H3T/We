package com.lseg.supportportal.backend.core.fields.util;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.lseg.supportportal.backend.core.fields.annotation.SearchableField;

public class SearchableFieldResolver {

    private static final Map<Class<?>, Map<String, Field>> SEARCHABLE_FIELDS_BY_ENTITY = new ConcurrentHashMap<>();

    private SearchableFieldResolver() {}

    public static Map<String, Field> resolveSearchableFieldsByKey(final Class<?> entityClass) {
        return SEARCHABLE_FIELDS_BY_ENTITY.computeIfAbsent(entityClass, SearchableFieldResolver::resolveSearchableFields);
    }

    private static Map<String, Field> resolveSearchableFields(final Class<?> entityClass) {
        return Arrays.stream(entityClass.getDeclaredFields())
                .filter(field -> field.isAnnotationPresent(SearchableField.class))
                .collect(Collectors.toUnmodifiableMap(field -> field.getAnnotation(SearchableField.class).key(), Function.identity()));
    }
}
