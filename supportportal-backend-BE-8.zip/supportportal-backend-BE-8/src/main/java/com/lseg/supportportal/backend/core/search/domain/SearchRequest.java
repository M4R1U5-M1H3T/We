package com.lseg.supportportal.backend.core.search.domain;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

public record SearchRequest(@NotNull(message = "Filters list must not be null") @Valid List<SearchCriteria> filters) {}