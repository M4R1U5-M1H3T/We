package com.lseg.supportportal.backend.core.search.domain;

import java.util.Map;
import java.util.Set;

import com.lseg.supportportal.backend.core.filters.domain.FilterType;

public enum SearchOperator {
    EQUAL,
    LIKE,
    BETWEEN;

    private static final Map<FilterType, Set<SearchOperator>> ALLOWED_BY_TYPE = Map.of(
            FilterType.TEXT, Set.of(EQUAL, LIKE),
            FilterType.DROPDOWN, Set.of(EQUAL),
            FilterType.DATE_RANGE, Set.of(BETWEEN)
    );

    public boolean isCompatibleWith(final FilterType filterType) {
        return ALLOWED_BY_TYPE.getOrDefault(filterType, Set.of()).contains(this);
    }
}
