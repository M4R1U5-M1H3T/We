package com.lseg.supportportal.backend.core.filters.domain;

public record FilterDefinition(FilterType type, String placeholder) {}
