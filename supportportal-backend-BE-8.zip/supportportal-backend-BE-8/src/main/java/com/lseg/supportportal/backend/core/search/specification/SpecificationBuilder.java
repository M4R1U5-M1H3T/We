package com.lseg.supportportal.backend.core.search.specification;

import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.data.jpa.domain.Specification;

import com.lseg.supportportal.backend.core.fields.util.SearchableFieldResolver;
import com.lseg.supportportal.backend.core.search.domain.SearchCriteria;
import com.lseg.supportportal.backend.core.search.domain.SearchRequest;

public class SpecificationBuilder<T> {

    private final Map<String, String> keyToFieldName;

    public SpecificationBuilder(Class<T> entityClass) {
        this.keyToFieldName = SearchableFieldResolver.resolveSearchableFieldsByKey(entityClass)
                .entrySet()
                .stream()
                .collect(Collectors.toMap(Map.Entry::getKey, entry -> entry.getValue().getName()));
    }

    public Specification<T> build(SearchRequest searchRequest) {
        return searchRequest.filters().stream().map(this::toSpecification).reduce(((_, _, _) -> null), Specification::and);
    }

    private Specification<T> toSpecification(SearchCriteria searchCriteria) {
        final String fieldName = keyToFieldName.get(searchCriteria.key());
        if (fieldName == null) {
            throw new IllegalArgumentException("Unknown filter key " + searchCriteria.key());
        }
        return new GenericSpecification<>(searchCriteria, fieldName);
    }
}
