package com.lseg.supportportal.backend.core.search.specification;

import com.lseg.supportportal.backend.core.search.domain.DateRangeValue;
import com.lseg.supportportal.backend.core.search.domain.FilterCriteria;
import com.lseg.supportportal.backend.core.search.domain.SearchOperator;
import jakarta.persistence.criteria.*;
import lombok.RequiredArgsConstructor;
import org.springframework.data.jpa.domain.Specification;

import java.time.LocalDateTime;
import java.util.Map;

@RequiredArgsConstructor
public class GenericSpecification<T> implements Specification<T> {
    private final FilterCriteria filterCriteria;
    private final String fieldName;

    @Override
    public Predicate toPredicate(Root<T> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {
        Object value = filterCriteria.value();
        if (value == null) {
            return null;
        }

        Expression<?> expression = root.get(fieldName);
        SearchOperator operator = filterCriteria.operator();

        return switch (operator) {
            case EQUAL -> criteriaBuilder.equal(expression, value);
            case LIKE -> criteriaBuilder.like(criteriaBuilder.lower(expression.as(String.class)),
                    toLikePattern(value)
            );
            case BETWEEN -> getBetweenPredicate(criteriaBuilder, value, expression);
        };
    }

    private static Predicate getBetweenPredicate(CriteriaBuilder criteriaBuilder, Object value, Expression<?> expression) {
        Expression<LocalDateTime> dateExpression = expression.as(LocalDateTime.class);
        if (value instanceof DateRangeValue(LocalDateTime from, LocalDateTime to)) {
            return criteriaBuilder.between(dateExpression, from, to);
        }

        if (value instanceof Map<?, ?> map && map.containsKey("from") && map.containsKey("to")) {
            LocalDateTime from = LocalDateTime.parse(map.get("from").toString().replace(" ", "T"));
            LocalDateTime to = LocalDateTime.parse(map.get("to").toString().replace(" ", "T"));
            return criteriaBuilder.between(dateExpression, from, to);
        }

        throw new IllegalArgumentException("BETWEEN operator requires an object containing from and to fields.");
    }

    private static String toLikePattern(Object value) {
        return "%" + value.toString().toLowerCase() + "%";
    }

}
