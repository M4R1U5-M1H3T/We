package com.lseg.supportportal.backend.core.search.domain;

import java.time.LocalDateTime;

public record DateRangeValue(LocalDateTime from, LocalDateTime to) {}
