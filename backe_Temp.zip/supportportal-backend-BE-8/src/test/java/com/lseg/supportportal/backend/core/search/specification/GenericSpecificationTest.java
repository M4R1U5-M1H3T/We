package com.lseg.supportportal.backend.core.search.specification;

import com.lseg.supportportal.backend.core.search.domain.FilterCriteria;
import com.lseg.supportportal.backend.core.search.domain.SearchOperator;
import com.lseg.supportportal.backend.tools.searchdatabase.orders.domain.Order;
import jakarta.persistence.criteria.*;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.Map;

import static org.mockito.Mockito.*;

class GenericSpecificationTest {

    @SuppressWarnings("unchecked")
    @Test
    void shouldInvokeEqualPredicateWhenOperatorIsEqual() {
        FilterCriteria criteria = new FilterCriteria("reutersCode", SearchOperator.EQUAL, "IBM.N");
        GenericSpecification<Order> specification = new GenericSpecification<>(criteria, "productRicCode");

        Root<Order> root = mock(Root.class);
        CriteriaQuery<?> query = mock(CriteriaQuery.class);
        CriteriaBuilder cb = mock(CriteriaBuilder.class);
        Path<Object> path = mock(Path.class);

        when(root.get("productRicCode")).thenReturn(path);

        specification.toPredicate(root, query, cb);

        verify(cb, times(1)).equal(path, "IBM.N");
    }

    @SuppressWarnings("unchecked")
    @Test
    void shouldInvokeBetweenPredicateWithParsedDatesWhenValueIsMapWithSpaces() {
        Map<String, String> dateMap = Map.of("from", "2025-05-30 00:00:00", "to", "2025-05-30 23:59:59");
        FilterCriteria criteria = new FilterCriteria("createdDate", SearchOperator.BETWEEN, dateMap);
        GenericSpecification<Order> specification = new GenericSpecification<>(criteria, "createdAt");

        Root<Order> root = mock(Root.class);
        CriteriaQuery<?> query = mock(CriteriaQuery.class);
        CriteriaBuilder cb = mock(CriteriaBuilder.class);
        Path<Object> rawPath = mock(Path.class);
        Expression<LocalDateTime> typedExpression = mock(Expression.class);

        when(root.get("createdAt")).thenReturn(rawPath);

        when(rawPath.as(LocalDateTime.class)).thenReturn(typedExpression);

        specification.toPredicate(root, query, cb);

        java.time.LocalDateTime expectedFrom = java.time.LocalDateTime.of(2025, 5, 30, 0, 0, 0);
        java.time.LocalDateTime expectedTo = java.time.LocalDateTime.of(2025, 5, 30, 23, 59, 59);

        verify(cb, times(1)).between(eq(typedExpression), eq(expectedFrom), eq(expectedTo));
    }
}
