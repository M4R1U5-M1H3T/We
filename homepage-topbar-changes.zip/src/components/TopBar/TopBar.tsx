import './index.css';

import { useLocation, useNavigate } from 'react-router-dom';

import { Avatar, Badge, Button, Icon, Logo, ShellHeader } from '@/ds-components';

const PAGE_NAMES: Record<string, string> = {
  '/tora-oems': 'OEMS Support',
  '/tora-oems/search': 'OEMS Support > Search',
  '/tora-oems/track-order': 'OEMS Support > Track Order',
  '/tora-oems/ai-chat': 'OEMS Support > AI Chat',
};

const DEFAULT_PAGE_NAME = 'OEMS Support';

export const TopBar = () => {
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const pageName = PAGE_NAMES[pathname] ?? DEFAULT_PAGE_NAME;

  return (
    <ShellHeader pageName={pageName}>
      <div slot="logo" className="topbar-logo" onClick={() => navigate('/tora-oems')}>
        <Logo size="sm" />
        <span className="topbar-title">TORA</span>
      </div>

      <div slot="contextual-actions" className="topbar-actions">
        <Button sentiment="neutral" tooltip="AI Chat" onClick={() => navigate('/tora-oems/ai-chat')}>
          <Icon slot="start" name="smart_toy" />
        </Button>
        <Badge sentiment="negative" emphasis="subtle" size="xs">
          Connected to Production
        </Badge>
      </div>

      <div slot="user-menu">
        <Avatar name="MC" size="sm" />
      </div>
    </ShellHeader>
  );
};
