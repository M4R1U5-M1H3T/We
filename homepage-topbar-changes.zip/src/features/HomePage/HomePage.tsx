import './index.css';

import { useNavigate } from 'react-router-dom';

import { Button, Card, CardContent, Icon } from '@/ds-components';

export const HomePage = () => {
  const navigate = useNavigate();

  return (
    <div className="page">
      <Card appearance="contained" className="tools-card">
        <CardContent>
          <h2 className="tools-title">Tools</h2>

          <div className="tools-list">
            <Button sentiment="primary" size="lg" onClick={() => navigate('/tora-oems/ai-chat')}>
              <Icon slot="start" name="smart_toy" />
              AI Chat
            </Button>

            <Button sentiment="secondary" size="lg" onClick={() => navigate('/tora-oems/search')}>
              <Icon slot="start" name="search" />
              Search
            </Button>

            <Button sentiment="secondary" size="lg" onClick={() => navigate('/tora-oems/track-order')}>
              <Icon slot="start" name="local_shipping" />
              Track Order
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
