package com.lseg.supportportal.backend.tools.searchdatabase.executions.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.stream.IntStream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.SliceImpl;
import org.springframework.test.util.ReflectionTestUtils;

import com.lseg.supportportal.backend.core.search.SearchProperties;
import com.lseg.supportportal.backend.tools.searchdatabase.executions.domain.Execution;
import com.lseg.supportportal.backend.tools.searchdatabase.executions.repository.ExecutionRepository;

@ExtendWith(MockitoExtension.class)
public class ExecutionServiceTest {

    @Mock
    private ExecutionRepository executionRepository;
    @Mock
    private SearchProperties searchProperties;

    @InjectMocks
    private ExecutionService executionService;

    @Captor
    private ArgumentCaptor<Pageable> pageableCaptor;

    @BeforeEach
    void setUp() {
        when(searchProperties.getHardLimit()).thenReturn(100);
    }

    @ParameterizedTest(name = "Run {index}: Testing size: {0}")
    @ValueSource(ints = {5, 100, 150})
    void returnsExpectedContentCount(int mockExecutionCount) {
        List<Execution> mockExecutions = createFakeExecutions(mockExecutionCount);
        when(executionRepository.findAllBy(any(Pageable.class))).thenReturn(new SliceImpl<>(mockExecutions));

        List<Execution> result = executionService.findAll();

        verify(executionRepository).findAllBy(pageableCaptor.capture());
        Pageable capturedPageable = pageableCaptor.getValue();

        assertThat(capturedPageable.getPageSize()).isEqualTo(searchProperties.getHardLimit());
        assertThat(capturedPageable.getPageNumber()).isZero();

        assertThat(result).hasSize(mockExecutionCount);
        assertThat(result).isEqualTo(mockExecutions);
    }

    private List<Execution> createFakeExecutions(int count) {
        return IntStream.range(0, count).mapToObj(i -> {
            Execution execution = new Execution();
            ReflectionTestUtils.setField(execution, "execId", "EXEC_" + i);
            ReflectionTestUtils.setField(execution, "ownerGroup", "mockOwnerGroup");
            ReflectionTestUtils.setField(execution, "symbol", "SYM_" + i);
            return execution;
        }).toList();
    }

    @Test
    void returnsEmptyResult() {
        when(executionRepository.findAllBy(any(Pageable.class))).thenReturn(new SliceImpl<>(List.of()));

        List<Execution> result = executionService.findAll();

        verify(executionRepository).findAllBy(pageableCaptor.capture());
        assertThat(result).isEmpty();
    }
}
