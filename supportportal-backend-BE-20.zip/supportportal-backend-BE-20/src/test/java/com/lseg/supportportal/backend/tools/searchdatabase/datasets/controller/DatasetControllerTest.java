package com.lseg.supportportal.backend.tools.searchdatabase.datasets.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.bean.override.mockito.MockitoSpyBean;
import org.springframework.test.web.servlet.MockMvc;

import com.lseg.supportportal.backend.core.security.SecurityConfig;
import com.lseg.supportportal.backend.tools.searchdatabase.datasets.domain.Dataset;
import com.lseg.supportportal.backend.tools.searchdatabase.datasets.service.DatasetService;

@WebMvcTest(DatasetController.class)
@Import({SecurityConfig.class, DatasetService.class})
class DatasetControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoSpyBean
    private DatasetService datasetService;

    @Test
    void getAvailableDatasetsReturnsOneEntryPerRegisteredDataset() throws Exception {
        List<String> allDatasetNames = Arrays.stream(Dataset.values())
                .map(Dataset::getLabel)
                .toList();
        when(datasetService.getAvailableDatasetNames()).thenReturn(allDatasetNames);

        mockMvc.perform(get("/api/database/datasets"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(Dataset.values().length));
    }

    @Test
    void getDatasetColumnsReturnsBadRequestForUnknownDataset() throws Exception {
        mockMvc.perform(get("/api/database/{dataset}/columns", "NotARealDataset"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void getDatasetColumnsSucceedsForEveryRegisteredDataset() throws Exception {
        for (Dataset dataset : Dataset.values()) {
            mockMvc.perform(get("/api/database/{dataset}/columns", dataset.getLabel()))
                    .andExpect(status().isOk());
        }
    }
}
