package com.lseg.supportportal.backend.tools.searchdatabase.executions.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lseg.supportportal.backend.core.security.SecurityConfig;
import com.lseg.supportportal.backend.tools.searchdatabase.executions.domain.Execution;
import com.lseg.supportportal.backend.tools.searchdatabase.executions.service.ExecutionService;

@WebMvcTest(ExecutionController.class)
@Import(SecurityConfig.class)
class ExecutionControllerTest {

    @Autowired
    private MockMvc mockMvc;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @MockitoBean
    private ExecutionService executionService;

    @ParameterizedTest
    @ValueSource(ints = {0, 1, 5, 100, 300})
    void shouldReturnPayloadMatchingServiceResponse(int executionCount) throws Exception {
        List<Execution> mockExecutions = IntStream.range(0, executionCount)
                .mapToObj(i -> buildExecution("EXEC_" + i, "OWNER_GROUP", "SYM_" + i))
                .toList();

        when(executionService.findAll()).thenReturn(mockExecutions);
        String expectedJson = objectMapper.writeValueAsString(mockExecutions);

        mockMvc.perform(get("/api/database/executions"))
                .andExpect(status().isOk())
                .andExpect(content().json(expectedJson, true));
    }

    @ParameterizedTest
    @MethodSource("provideSparseFieldCases")
    void shouldReturnPayloadMatchingServiceResponseForSparseFields(List<Execution> executions) throws Exception {
        when(executionService.findAll()).thenReturn(executions);
        String expectedJson = objectMapper.writeValueAsString(executions);

        mockMvc.perform(get("/api/database/executions"))
                .andExpect(status().isOk())
                .andExpect(content().json(expectedJson, true));
    }

    private static Stream<Arguments> provideSparseFieldCases() {
        return Stream.of(
                Arguments.of(List.of(
                        buildExecution("0000512FF778EE51", "MDG", "VOD.L"),
                        buildExecution("0000512FF778EE52", "EQD", "AAPL.OQ"),
                        buildExecution("0000512FF778EE53", "FI", "US10Y")
                )),
                Arguments.of(List.of(buildExecution("EX-SPARSE-1", "ALGO", "MSFT.OQ"))),
                Arguments.of(List.of(buildExecution("EX-SPARSE-2", "ALGO", null))),
                Arguments.of(List.of(buildExecution("EX-SPARSE-3", "MANUAL", "VOD.L")))
        );
    }

    private static Execution buildExecution(String execId, String ownerGroup, String symbol) {
        Execution execution = new Execution();
        ReflectionTestUtils.setField(execution, "execId", execId);
        ReflectionTestUtils.setField(execution, "ownerGroup", ownerGroup);
        ReflectionTestUtils.setField(execution, "symbol", symbol);
        return execution;
    }
}
