package com.lseg.supportportal.backend.tools.searchdatabase.orders.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lseg.supportportal.backend.core.security.SecurityConfig;
import com.lseg.supportportal.backend.tools.searchdatabase.orders.domain.Order;
import com.lseg.supportportal.backend.tools.searchdatabase.orders.service.OrderService;

@WebMvcTest(OrderController.class)
@Import(SecurityConfig.class)
class OrderControllerTest {

    @Autowired
    private MockMvc mockMvc;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @MockitoBean
    private OrderService orderService;

    @ParameterizedTest
    @ValueSource(ints = {0, 1, 5, 100, 300})
    void shouldReturnPayloadMatchingServiceResponse(int orderCount) throws Exception {
        List<Order> mockOrders = IntStream.range(0, orderCount)
                .mapToObj(i -> buildOrder("ORDER_" + i, "OWNER_GROUP", "CHILD", "CODE_" + i, new BigDecimal("100.00")))
                .toList();

        when(orderService.findAll()).thenReturn(mockOrders);
        String expectedJson = objectMapper.writeValueAsString(mockOrders);

        mockMvc.perform(get("/api/database/orders"))
                .andExpect(status().isOk())
                .andExpect(content().json(expectedJson, true));
    }

    @ParameterizedTest
    @MethodSource("provideSparseFieldCases")
    void shouldReturnPayloadMatchingServiceResponseForSparseFields(List<Order> orders) throws Exception {
        when(orderService.findAll()).thenReturn(orders);
        String expectedJson = objectMapper.writeValueAsString(orders);

        mockMvc.perform(get("/api/database/orders"))
                .andExpect(status().isOk())
                .andExpect(content().json(expectedJson, true));
    }

    private static Stream<Arguments> provideSparseFieldCases() {
        return Stream.of(
                Arguments.of(List.of(
                        buildOrder("ORDER-1", "MDG", "PARENT", "VOD.L", new BigDecimal("100.00")),
                        buildOrder("ORDER-2", "EQD", "CHILD", "AAPL.OQ", new BigDecimal("50.00")),
                        buildOrder("ORDER-3", "FI", "CHILD", "US10Y", new BigDecimal("25.00"))
                )),
                Arguments.of(List.of(buildOrder("ORD-SPARSE-1", "ALGO", null, "MSFT.OQ", null))),
                Arguments.of(List.of(buildOrder("ORD-SPARSE-2", "ALGO", null, null, null))),
                Arguments.of(List.of(buildOrder("ORD-SPARSE-3", "MANUAL", null, "VOD.L", null)))
        );
    }

    private static Order buildOrder(String clOrdId, String ownerGroup, String parentType, String productRicCode, BigDecimal orderQty) {
        Order order = new Order();
        ReflectionTestUtils.setField(order, "clOrdId", clOrdId);
        ReflectionTestUtils.setField(order, "ownerGroup", ownerGroup);
        ReflectionTestUtils.setField(order, "parentType", parentType);
        ReflectionTestUtils.setField(order, "productRicCode", productRicCode);
        ReflectionTestUtils.setField(order, "orderQty", orderQty);
        return order;
    }
}
