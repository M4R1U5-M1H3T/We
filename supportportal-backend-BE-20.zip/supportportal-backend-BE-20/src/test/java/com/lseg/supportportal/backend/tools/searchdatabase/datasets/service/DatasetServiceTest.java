package com.lseg.supportportal.backend.tools.searchdatabase.datasets.service;

import static org.assertj.core.api.Assertions.assertThat;

import java.lang.reflect.Field;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.lseg.supportportal.backend.tools.searchdatabase.datasets.domain.ColumnInfo;
import com.lseg.supportportal.backend.tools.searchdatabase.datasets.domain.Dataset;

import jakarta.persistence.Column;

class DatasetServiceTest {

    private final DatasetService datasetService = new DatasetService();

    @Test
    void getAvailableDatasetNamesReturnsExactlyEveryRegisteredDataset() {
        List<String> names = datasetService.getAvailableDatasetNames();

        assertThat(names).hasSize(Dataset.values().length);
        for (Dataset dataset : Dataset.values()) {
            assertThat(names).contains(dataset.getLabel());
        }
    }

    @Test
    void getColumnsEveryColumnHasANonBlankDisplayName() {
        for (Dataset dataset : Dataset.values()) {
            for (ColumnInfo column : datasetService.getColumns(dataset.name())) {
                assertThat(column.label())
                        .as("display name for " + dataset.getLabel() + "." + column.name())
                        .isNotBlank();
            }
        }
    }

    @Test
    void getColumnsMatchesEveryColumnAnnotatedFieldOnTheEntity() {
        for (Dataset dataset : Dataset.values()) {
            long expectedColumnCount = 0;
            for (Field field : dataset.getEntityClass().getDeclaredFields()) {
                if (field.getAnnotation(Column.class) != null) {
                    expectedColumnCount++;
                }
            }

            assertThat(datasetService.getColumns(dataset.name()))
                    .as("columns for dataset " + dataset.getLabel())
                    .hasSize((int) expectedColumnCount);
        }
    }
}

