package com.lseg.supportportal.backend.core.filters.domain;

public record Filter(String title, boolean required, String placeholder) {}