package com.lseg.supportportal.backend.tools.searchdatabase.executions.domain;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import com.lseg.supportportal.backend.core.metadata.Label;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "executions")
@IdClass(ExecutionPrimaryKey.class)
@Getter
@NoArgsConstructor
public class Execution {

    @Id
    @Label("Execution ID")
    @Column(name = "execid", nullable = false)
    private String execId;

    @Label("Execution Transaction Type")
    @Column(name = "exectranstype")
    private String execTransType;

    @Label("Symbol")
    @Column(name = "symbol")
    private String symbol;

    @Label("Last Shares")
    @Column(name = "lastshares")
    private BigDecimal lastShares;

    @Label("Last Price")
    @Column(name = "lastpx")
    private BigDecimal lastPx;

    @Label("Execution Time")
    @Column(name = "exectime")
    private LocalDateTime execTime;

    @Label("Security Exchange")
    @Column(name = "securityexchange")
    private String securityExchange;

    @Label("Side")
    @Column(name = "side")
    private String side;

    @Label("Receive Date")
    @Column(name = "recdate")
    private LocalDateTime recDate;

    @Label("Security Type")
    @Column(name = "securitytype")
    private String securityType;

    @Label("Owner")
    @Column(name = "owner")
    private String owner;

    @Id
    @Label("Owner Group")
    @Column(name = "ownergroup", nullable = false)
    private String ownerGroup;

    @Label("Trade Book")
    @Column(name = "tradebook")
    private String tradeBook;

    @Label("Deleted Flag")
    @Column(name = "deletedflag")
    private String deletedFlag;

    @Label("Suspended Flag")
    @Column(name = "suspendedflag")
    private String suspendedFlag;

    @Label("FIX Execution ID")
    @Column(name = "fixexecid")
    private String fixExecId;

    @Label("FIX Execution Reference ID")
    @Column(name = "fixexecrefid")
    private String fixExecRefId;

    @Label("Client Order ID")
    @Column(name = "clordid")
    private String clOrdId;

    @Label("Receive Date (Post-Execution)")
    @Column(name = "recdatepastexec")
    private LocalDateTime recDatePastExec;

    @Label("Update Time")
    @Column(name = "updatetime")
    private LocalDateTime updateTime;

    @Label("Manual Flag")
    @Column(name = "manualflag")
    private String manualFlag;

    @Label("Match ID")
    @Column(name = "matchid")
    private String matchId;

    @Label("Execution Local Time")
    @Column(name = "execlocaltime")
    private LocalDateTime execLocalTime;

    @Label("Business Trade Date")
    @Column(name = "businesstradedate")
    private LocalDate businessTradeDate;

    @Label("Execution Exchange")
    @Column(name = "executionexchange")
    private String executionExchange;

    @Label("Settlement Currency")
    @Column(name = "settlementccy")
    private String settlementCcy;

    @Label("Settlement FX Rate")
    @Column(name = "settlementfxrate")
    private BigDecimal settlementFxRate;

    @Label("Settlement FX Direction")
    @Column(name = "settlementfxdir")
    private String settlementFxDir;

    @Label("Execution Counterparty ID")
    @Column(name = "execcounterpartyid")
    private String execCounterpartyId;

    @Label("Fund Allocation")
    @Column(name = "fundallocation")
    private String fundAllocation;

    @Label("Total Fund Allocation")
    @Column(name = "totalfundallocation")
    private String totalFundAllocation;

    @Label("Last Capacity")
    @Column(name = "lastcapacity")
    private String lastCapacity;

    @Label("Last Liquidity Indicator")
    @Column(name = "lastliquidityind")
    private String lastLiquidityInd;

    @Label("Instruction Hash Value")
    @Column(name = "inshashvalue")
    private String insHashValue;

    @Label("Exchange Order ID")
    @Column(name = "exchangeorderid")
    private String exchangeOrderId;

    @Label("Exchange Internal ID")
    @Column(name = "exchangeinternalid")
    private String exchangeInternalId;

    @Label("Exchange Execution ID")
    @Column(name = "exchangeexecutionid")
    private String exchangeExecutionId;

    @Label("Extra Fields")
    @Column(name = "extrafields")
    private String extraFields;

    @Label("Last Shares 2")
    @Column(name = "lastshares2")
    private BigDecimal lastShares2;

    @Label("Extra Fields 2")
    @Column(name = "extrafields2", columnDefinition = "jsonb")
    private String extraFields2;
}
