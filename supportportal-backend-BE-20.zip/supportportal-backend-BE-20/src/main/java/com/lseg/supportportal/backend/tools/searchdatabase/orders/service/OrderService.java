package com.lseg.supportportal.backend.tools.searchdatabase.orders.service;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.lseg.supportportal.backend.core.search.SearchProperties;
import com.lseg.supportportal.backend.tools.searchdatabase.orders.domain.Order;
import com.lseg.supportportal.backend.tools.searchdatabase.orders.repository.OrderRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;
    private final SearchProperties searchProperties;

    public List<Order> findAll() {
        final Pageable pageable = Pageable.ofSize(searchProperties.getHardLimit());
        return orderRepository.findAllBy(pageable).getContent();
    }
}
