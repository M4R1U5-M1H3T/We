package com.lseg.supportportal.backend.core.exception;

import java.time.Instant;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record ErrorResponse(
        Instant timestamp,
        int status,
        String error,
        String message,
        String path,
        List<String> details
) {
    public static ErrorResponse of(
            final int status,
            final String error,
            final String message,
            final String path
    ) {
        return new ErrorResponse(Instant.now(), status, error, message, path, null);
    }

    public static ErrorResponse of(
            final int status,
            final String error,
            final String message,
            final String path,
            final List<String> details
    ) {
        return new ErrorResponse(Instant.now(), status, error, message, path, details);
    }
}
