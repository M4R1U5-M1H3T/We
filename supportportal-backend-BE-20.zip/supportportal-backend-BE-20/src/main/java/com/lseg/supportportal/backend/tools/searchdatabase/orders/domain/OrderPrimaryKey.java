package com.lseg.supportportal.backend.tools.searchdatabase.orders.domain;

import java.io.Serializable;

public record OrderPrimaryKey(String clOrdId, String ownerGroup) implements Serializable {}
