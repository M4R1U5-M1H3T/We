package com.lseg.supportportal.backend.tools.searchdatabase.executions.domain;

import java.io.Serializable;

public record ExecutionPrimaryKey(String execId, String ownerGroup) implements Serializable {}
