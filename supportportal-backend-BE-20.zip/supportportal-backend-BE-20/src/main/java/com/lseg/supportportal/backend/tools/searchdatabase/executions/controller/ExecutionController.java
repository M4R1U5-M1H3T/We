package com.lseg.supportportal.backend.tools.searchdatabase.executions.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lseg.supportportal.backend.tools.searchdatabase.executions.domain.Execution;
import com.lseg.supportportal.backend.tools.searchdatabase.executions.service.ExecutionService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/database/executions")
@RequiredArgsConstructor
@Tag(name = "Executions", description = "Endpoint for accessing execution data")
public class ExecutionController {

    private final ExecutionService executionService;

    @GetMapping
    @Operation(summary = "Retrieve executions", description = "Retrieves executions from the database.")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved executions.")
    public ResponseEntity<List<Execution>> findExecutions() {
        final List<Execution> executions = executionService.findAll();
        return ResponseEntity.ok().body(executions);
    }
}
