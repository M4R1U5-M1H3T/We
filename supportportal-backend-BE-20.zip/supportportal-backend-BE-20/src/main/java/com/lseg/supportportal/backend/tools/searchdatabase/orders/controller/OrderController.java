package com.lseg.supportportal.backend.tools.searchdatabase.orders.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lseg.supportportal.backend.tools.searchdatabase.orders.domain.Order;
import com.lseg.supportportal.backend.tools.searchdatabase.orders.service.OrderService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/database/orders")
@RequiredArgsConstructor
@Tag(name = "Orders", description = "Endpoint for accessing order data")
public class OrderController {

    private final OrderService orderService;

    @GetMapping
    @Operation(summary = "Retrieve orders", description = "Retrieves orders from the database.")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved orders.")
    public ResponseEntity<List<Order>> findOrders() {
        final List<Order> orders = orderService.findAll();
        return ResponseEntity.ok().body(orders);
    }
}
