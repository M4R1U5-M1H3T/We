package com.lseg.supportportal.backend.core.filters.service;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.lseg.supportportal.backend.core.filters.domain.Filter;
import com.lseg.supportportal.backend.core.filters.domain.FilterConfig;
import com.lseg.supportportal.backend.core.filters.domain.FilterDefinition;
import com.lseg.supportportal.backend.core.filters.domain.FilterOption;
import com.lseg.supportportal.backend.core.filters.domain.FilterType;
import com.lseg.supportportal.backend.core.filters.domain.PageFilters;
import com.lseg.supportportal.backend.core.filters.exception.FilterConfigurationException;
import com.lseg.supportportal.backend.tools.searchdatabase.datasets.domain.Dataset;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class FilterConfigurationService {

    private final FilterJsonReader filterJsonReader;
    private final FilterDataProvider filterDataProvider;
    private final Resource definitionsResource;
    private final Map<Dataset, Resource> pageToFilterConfigResource;
    private volatile Map<Dataset, PageFilters> pageFiltersMap;

    public FilterConfigurationService(
            final FilterJsonReader filterJsonReader, final FilterDataProvider filterDataProvider,
            @Value("classpath:filters/filter-definitions.json") final Resource definitionsResource,
            @Value("classpath:filters/search-db-order-filters.json") final Resource orderFilterResource,
            @Value("classpath:filters/search-db-execution-filters.json") final Resource executionFilterResource) {
        this.filterJsonReader = filterJsonReader;
        this.filterDataProvider = filterDataProvider;
        this.definitionsResource = definitionsResource;
        this.pageToFilterConfigResource = Map.of(Dataset.ORDERS, orderFilterResource, Dataset.EXECUTIONS, executionFilterResource);
    }

    @PostConstruct
    public void initialize() {

        final Map<String, FilterDefinition> definitions = readDefinitions();
        final Map<Dataset, PageFilters> responsesByPage = new HashMap<>();

        pageToFilterConfigResource.forEach(
                (page, filterConfigResource) -> responsesByPage.put(page, buildFilterResponse(filterConfigResource, definitions)));

        this.pageFiltersMap = Map.copyOf(responsesByPage);
    }

    private Map<String, FilterDefinition> readDefinitions() {
        return filterJsonReader.read(definitionsResource, new TypeReference<Map<String, FilterDefinition>>() {});
    }

    private FilterConfig readFilterConfig(final Resource filterConfigResource) {
        return filterJsonReader.read(filterConfigResource, new TypeReference<FilterConfig>() {});
    }

    private PageFilters buildFilterResponse(final Resource filterConfigResource, final Map<String, FilterDefinition> definitions) {

        final FilterConfig filterConfig = readFilterConfig(filterConfigResource);
        validateDefaultFilterOrder(filterConfigResource, filterConfig);

        final Map<String, PageFilters.FilterEntry> filters = new LinkedHashMap<>();

        for (final Map.Entry<String, Filter> entry : filterConfig.filters().entrySet()) {
            final String filterKey = entry.getKey();
            final Filter filter = entry.getValue();
            final FilterDefinition definition = definitions.get(filterKey);
            if (definition == null) {
                throw new FilterConfigurationException(
                        "Requested unknown filter: '" + filterKey + "' - no matching entry in filter-definitions.json");
            }

            final String title = resolveTitle(filterKey, filter);
            filters.put(title, buildFilterConfig(filterKey, filter, definition));
        }

        final List<String> defaultFilterTitles = filterConfig.defaultFilterOrder()
                .stream()
                .map(filterKey -> resolveTitle(filterKey, filterConfig.filters().get(filterKey)))
                .toList();

        return PageFilters.builder().defaultFilters(defaultFilterTitles).filters(Collections.unmodifiableMap(filters)).build();
    }

    private void validateDefaultFilterOrder(final Resource filterConfigResource, final FilterConfig filterConfig) {
        final Set<String> orderedKeys = new HashSet<>(filterConfig.defaultFilterOrder());
        final Set<String> definedKeys = filterConfig.filters().keySet();

        if (orderedKeys.size() != filterConfig.defaultFilterOrder().size()) {
            throw new FilterConfigurationException(
                    "Duplicate filter key found in defaultFilterOrder of '" + filterConfigResource.getDescription() + "'");
        }
        if (!definedKeys.containsAll(orderedKeys)) {
            throw new FilterConfigurationException(
                    "defaultFilterOrder references unknown filter keys in '" + filterConfigResource.getDescription() + "' - defaultFilterOrder: "
                            + orderedKeys + ", filters: " + definedKeys);
        }
    }

    private PageFilters.FilterEntry buildFilterConfig(final String filterKey, final Filter filter, final FilterDefinition definition) {

        final List<FilterOption> filterData = filterDataProvider.getOptions(filterKey);

        if (definition.type() == FilterType.DROPDOWN && filterData.isEmpty()) {
            log.warn("Dropdown filter '{}' has no options configured in filter-values.json", filterKey);
        }

        final PageFilters.FilterProps props = PageFilters.FilterProps.builder().placeholder(filter.placeholder()).build();

        return PageFilters.FilterEntry.builder()
                .title(resolveTitle(filterKey, filter))
                .type(definition.type())
                .required(filter.required())
                .data(filterData)
                .props(props)
                .build();
    }

    private String resolveTitle(final String filterKey, final Filter filter) {
        return filter.title() != null ? filter.title() : filterKey;
    }

    public PageFilters getPageFilters(final String page) {
        return pageFiltersMap.get(Dataset.fromName(page));
    }
}
