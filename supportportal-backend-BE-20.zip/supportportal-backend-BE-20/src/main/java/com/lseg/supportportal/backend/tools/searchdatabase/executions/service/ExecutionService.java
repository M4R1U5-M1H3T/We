package com.lseg.supportportal.backend.tools.searchdatabase.executions.service;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.lseg.supportportal.backend.core.search.SearchProperties;
import com.lseg.supportportal.backend.tools.searchdatabase.executions.domain.Execution;
import com.lseg.supportportal.backend.tools.searchdatabase.executions.repository.ExecutionRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ExecutionService {

    private final ExecutionRepository executionRepository;
    private final SearchProperties searchProperties;

    public List<Execution> findAll() {
        final Pageable pageable = Pageable.ofSize(searchProperties.getHardLimit());
        return executionRepository.findAllBy(pageable).getContent();
    }
}
