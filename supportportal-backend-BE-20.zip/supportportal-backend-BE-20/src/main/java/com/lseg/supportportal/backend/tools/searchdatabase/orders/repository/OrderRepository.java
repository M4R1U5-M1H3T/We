package com.lseg.supportportal.backend.tools.searchdatabase.orders.repository;

import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.lseg.supportportal.backend.tools.searchdatabase.orders.domain.Order;
import com.lseg.supportportal.backend.tools.searchdatabase.orders.domain.OrderPrimaryKey;

@Repository
public interface OrderRepository extends JpaRepository<Order, OrderPrimaryKey> {

    Slice<Order> findAllBy(Pageable pageable);
}
