package com.lseg.supportportal.backend.tools.searchdatabase.executions.repository;

import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.lseg.supportportal.backend.tools.searchdatabase.executions.domain.Execution;
import com.lseg.supportportal.backend.tools.searchdatabase.executions.domain.ExecutionPrimaryKey;

@Repository
public interface ExecutionRepository extends JpaRepository<Execution, ExecutionPrimaryKey> {

    Slice<Execution> findAllBy(Pageable pageable);
}
