import { createSlice } from '@reduxjs/toolkit';

import type { ChatTurn } from '@/features';
import { sendChatMessageThunk } from '@/slices/thunks';
import type { RootState } from '@/store/store';

type AIChatState = {
  turns: ChatTurn[];
};

const initialState: AIChatState = {
  turns: [],
};

export const aiChatSlice = createSlice({
  name: 'aiChat',
  initialState,
  reducers: {
    chatReset: state => {
      state.turns = [];
    },
  },
  extraReducers: builder => {
    builder
      .addCase(sendChatMessageThunk.pending, (state, action) => {
        const { turnId, message, askedAt } = action.meta.arg;

        state.turns.push({
          id: turnId,
          question: message,
          askedAt,
          status: 'pending',
        });
      })
      .addCase(sendChatMessageThunk.fulfilled, (state, action) => {
        const turn = state.turns.find(item => item.id === action.meta.arg.turnId);

        if (!turn) {
          return;
        }

        turn.status = 'success';
        turn.answer = action.payload.answer;
        turn.answeredAt = new Date().toISOString();
        turn.reasoning = action.payload.reasoning;
        turn.results = action.payload.results;
      })
      .addCase(sendChatMessageThunk.rejected, (state, action) => {
        const turn = state.turns.find(item => item.id === action.meta.arg.turnId);

        if (!turn) {
          return;
        }

        turn.status = 'failed';
        turn.answeredAt = new Date().toISOString();
        turn.error = action.payload?.message || 'Failed to get a response from the assistant.';
      });
  },
});

export const aiChatReducer = aiChatSlice.reducer;
export const { chatReset } = aiChatSlice.actions;

export const selectChatTurns = (state: RootState) => state.aiChat.turns;
export const selectIsChatResponding = (state: RootState) => state.aiChat.turns.some(turn => turn.status === 'pending');
