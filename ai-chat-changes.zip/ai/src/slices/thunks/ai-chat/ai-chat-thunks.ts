import axios from 'axios';

import type { AIChatQueryResponse, SendChatMessageArgs } from '@/features';
import { handleThunkError } from '@/slices';
import { createAppAsyncThunkWithErrorPayload } from '@/store/hooks';

export const sendChatMessageThunk = createAppAsyncThunkWithErrorPayload<AIChatQueryResponse, SendChatMessageArgs>(
  'aiChat/sendMessage',
  async ({ message, conversationId }, { rejectWithValue }) => {
    try {
      const response = await axios.post<AIChatQueryResponse>('/api/ai-chat/query', {
        message,
        conversationId,
      });

      return response.data;
    } catch (error) {
      return rejectWithValue(handleThunkError(error));
    }
  }
);
