import type { SearchResults } from '@/features/search-database-page/types';

export type ChatTurnStatus = 'pending' | 'success' | 'failed';

export type ChatReasoningStep = {
  label: string;
  description?: string;
};

export type ChatTurn = {
  id: string;
  question: string;
  askedAt: string;
  status: ChatTurnStatus;
  answer?: string;
  answeredAt?: string;
  reasoning?: ChatReasoningStep[];
  results?: SearchResults;
  error?: string;
};

export type SendChatMessageArgs = {
  turnId: string;
  message: string;
  askedAt: string;
  conversationId: string;
};

/**
 * Contract expected from the Azure OpenAI (GPT-4o) backed endpoint.
 * The backend resolves the user's natural language question, optionally
 * calling the existing "get orders from database with filters" capability
 * (same data source as /api/database/{dataset}) to ground its answer, then
 * returns a summary plus the matched rows so the UI can render them as a table.
 */
export type AIChatQueryResponse = {
  answer: string;
  reasoning?: ChatReasoningStep[];
  results?: SearchResults;
};
