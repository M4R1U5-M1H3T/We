import { configureStore } from '@reduxjs/toolkit';

import { aiChatReducer, databaseDatasetsReducer, filtersReducer, searchDatabaseReducer } from '@/slices';

export const store = configureStore({
  reducer: {
    aiChat: aiChatReducer,
    filters: filtersReducer,
    search: searchDatabaseReducer,
    datasets: databaseDatasetsReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
